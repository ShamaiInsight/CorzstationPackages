#!/usr/bin/env python3
"""
CORZStation WiFi Settings API — port 8082
Provides HTTP endpoints consumed by index.html Settings panel.

Routes (all under /api/wifi/):
  GET  /api/wifi/status        → { mode, ssid, ip, connected, wifi_enabled, internet, connectivity }
  GET  /api/wifi/scan          → { networks: [ {ssid, signal, secured} ] }
  POST /api/wifi/hotspot/on    → { ok, message }
  POST /api/wifi/hotspot/off   → { ok, message }
  POST /api/wifi/connect       ← { ssid, password }  → { ok, message }

Requires nmcli without password:
  sudo visudo -f /etc/sudoers.d/corz-wifi
  # <desktop-user> ALL=(root) NOPASSWD: /usr/bin/nmcli
"""

import json
import subprocess
import re
import time
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

PORT = 8082
HOTSPOT_CON   = "CORZStation"   # nmcli connection name for the hotspot
HOTSPOT_SSID  = "CORZStation"
HOTSPOT_PASS  = "corz1234"
HOTSPOT_IFACE = "wlan0"

# Checking reachability is independent of the Wi-Fi link (Ethernet may be online).
# Cache across dashboard/settings requests; do not enable/disable NM connectivity settings.
_connectivity_lock = threading.Lock()
_connectivity_cache = None
_connectivity_checked = 0.0


def get_connectivity():
    global _connectivity_cache, _connectivity_checked
    with _connectivity_lock:
        if _connectivity_cache is not None and time.monotonic() - _connectivity_checked < 8:
            return dict(_connectivity_cache)
        out, _, code = nmcli("networking", "connectivity", "check", timeout=4)
        state = out.strip().lower()
        if code == 0 and state in ("full", "portal", "limited", "none"):
            result = {"internet": state == "full", "connectivity": state}
        else:
            # NM checks can be disabled on Pi OS. Validate a real HTTPS 204;
            # redirects/captive-portal HTML must never be reported as online.
            online = False
            for url in ("https://connectivitycheck.gstatic.com/generate_204",
                        "https://cp.cloudflare.com/generate_204"):
                try:
                    request = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
                    with urllib.request.urlopen(request, timeout=2) as response:
                        if response.status == 204 and response.geturl() == url and response.read(1) == b"":
                            online = True
                            break
                except Exception:
                    continue
            result = {"internet": online, "connectivity": "full" if online else "unreachable"}
        _connectivity_cache = result
        _connectivity_checked = time.monotonic()
        return dict(result)

# ── Helpers ──────────────────────────────────────────────────────────────────

def nmcli(*args, sudo=False, timeout=15):
    cmd = (["sudo", "-n"] if sudo else []) + ["nmcli"] + list(args)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip(), r.stderr.strip(), r.returncode
    except subprocess.TimeoutExpired:
        return "", "timeout", 1
    except FileNotFoundError:
        return "", "nmcli not found", 1

def get_mode():
    """Return 'hotspot' if the hotspot AP connection is active, else 'client'."""
    out, _, _ = nmcli("-t", "-f", "NAME,TYPE,STATE", "con", "show", "--active", timeout=2)
    for line in out.splitlines():
        parts = line.split(":")
        # NAME:TYPE:STATE — activated hotspot connection
        if len(parts) >= 3 and parts[2] == "activated":
            if HOTSPOT_CON in parts[0]:
                return "hotspot"
    return "client"

def set_hotspot():
    """Activate the CORZStation hotspot connection (creates it if missing)."""
    out, _, _ = nmcli("-t", "-f", "NAME", "con", "show")
    exists = any(l.strip() == HOTSPOT_CON for l in out.splitlines())
    if not exists:
        nmcli("con", "add", "type", "wifi", "ifname", HOTSPOT_IFACE,
              "con-name", HOTSPOT_CON, "autoconnect", "no",
              "ssid", HOTSPOT_SSID, sudo=True)
        nmcli("con", "modify", HOTSPOT_CON,
              "802-11-wireless.mode", "ap",
              "802-11-wireless.band", "bg",
              "ipv4.method", "shared",
              "wifi-sec.key-mgmt", "wpa-psk",
              "wifi-sec.psk", HOTSPOT_PASS, sudo=True)
    out, err, code = nmcli("con", "up", HOTSPOT_CON, sudo=True, timeout=20)
    return code == 0, err or out

def set_client():
    """Bring down the hotspot, restore managed WiFi mode."""
    nmcli("con", "down", HOTSPOT_CON, sudo=True)
    nmcli("dev", "set", HOTSPOT_IFACE, "managed", "yes", sudo=True)
    return True, "Hotspot stopped"

def scan_networks():
    """
    Return visible SSIDs with signal and security.
    Works even in hotspot mode by temporarily requesting a rescan;
    NM usually keeps a cached scan result we can read.
    """
    # Best-effort rescan (may fail in AP mode — that's OK, we use cache)
    nmcli("dev", "wifi", "rescan", "ifname", HOTSPOT_IFACE, sudo=True, timeout=8)
    time.sleep(2)

    out, err, code = nmcli(
        "-t", "-f", "SSID,SIGNAL,SECURITY",
        "dev", "wifi", "list", "ifname", HOTSPOT_IFACE
    )

    seen = set()
    networks = []
    for line in out.splitlines():
        # nmcli -t escapes colons as \:; split on unescaped colons
        # Simple approach: split on ':' but keep max 3 parts from the right
        # because SSIDs can contain colons
        # Fields: SSID:SIGNAL:SECURITY — split from right to protect SSID
        rparts = line.rsplit(":", 2)
        if len(rparts) < 2:
            continue
        # If 3 parts: ssid, signal, security
        # If 2 parts: ssid+signal, security (unusual)
        if len(rparts) == 3:
            ssid, sig_str, security = rparts
        else:
            ssid = rparts[0]
            sig_str = rparts[1]
            security = ""

        ssid = ssid.strip()
        if not ssid or ssid == "--" or ssid in seen:
            continue
        seen.add(ssid)
        try:
            signal = int(sig_str.strip())
        except ValueError:
            signal = 0
        secured = bool(security.strip() and security.strip() != "--")
        networks.append({"ssid": ssid, "signal": signal, "secured": secured})

    networks.sort(key=lambda x: -x["signal"])
    return networks, (code != 0 and not networks)

def purge_profiles_by_ssid(ssid):
    """Delete every saved NM profile whose 802-11-wireless.ssid matches.

    nmcli 'con delete <name>' only works when the profile *name* == ssid.
    Old/duplicate profiles may have different names, so we check each
    wireless profile's actual ssid field and wipe all matches.
    """
    out, _, _ = nmcli("-t", "-f", "NAME,TYPE", "con", "show", sudo=True)
    for line in out.splitlines():
        parts = line.split(":", 1)
        if len(parts) == 2 and "wireless" in parts[1].lower():
            con_name = parts[0]
            val, _, _ = nmcli("-g", "802-11-wireless.ssid", "con", "show",
                              con_name, sudo=True)
            if val.strip() == ssid:
                nmcli("con", "delete", con_name, sudo=True)
    # Also try by name directly — catches the common case quickly
    nmcli("con", "delete", ssid, sudo=True)

def connect_network(ssid, password):
    """Connect to a WiFi network by SSID and optional password."""
    import time

    # 1. Teardown hotspot if active — WiFi chip can't be AP + client at once
    if get_mode() == "hotspot":
        set_client()
        time.sleep(1.5)

    # 2. Purge ALL saved profiles whose wifi.ssid matches — avoids the
    #    'key-mgmt: property is missing' error from stale/incomplete profiles.
    purge_profiles_by_ssid(ssid)

    # 3. Connect fresh — let nmcli dev wifi connect build the correct profile
    if password:
        out, err, code = nmcli("dev", "wifi", "connect", ssid,
                               "password", password, sudo=True, timeout=30)
    else:
        out, err, code = nmcli("dev", "wifi", "connect", ssid,
                               sudo=True, timeout=30)

    msg = (err or out).strip()
    return code == 0, msg

def get_status():
    """Wi-Fi radio/link state and separately verified internet reachability."""
    mode = get_mode()
    radio, _, radio_code = nmcli("radio", "wifi", timeout=2)
    if radio_code != 0 or radio not in ("enabled", "disabled"):
        raise RuntimeError("Unable to read Wi-Fi radio state")
    out, _, device_code = nmcli("-t", "-f", "DEVICE,STATE,CONNECTION", "dev", "status", timeout=2)
    if device_code != 0:
        raise RuntimeError("Unable to read network devices")
    ssid = ""
    ip   = ""
    connected = False
    for line in out.splitlines():
        parts = line.split(":", 2)
        if len(parts) >= 3 and parts[0] == HOTSPOT_IFACE:
            connected = parts[1] == "connected"
            ssid = parts[2].replace(r"\:", ":").replace(r"\\", "\\") if connected else ""
            if connected:
                ip_out, _, _ = nmcli("-g", "IP4.ADDRESS", "dev", "show", HOTSPOT_IFACE, timeout=2)
                m = re.search(r"(\d+\.\d+\.\d+\.\d+)", ip_out)
                if m:
                    ip = m.group(1)
                # CONNECTION above is the saved profile's name, not necessarily its SSID.
                if mode == "hotspot":
                    ssid = HOTSPOT_SSID
                else:
                    active, _, _ = nmcli("-t", "-f", "IN-USE,SSID", "dev", "wifi", "list",
                                         "ifname", HOTSPOT_IFACE, "--rescan", "no", timeout=2)
                    for network in active.splitlines():
                        if network.startswith("*:"):
                            ssid = network[2:].replace(r"\:", ":").replace(r"\\", "\\")
                            break
            break
    result = {"mode": mode, "connected": connected, "ssid": ssid, "ip": ip,
              "wifi_enabled": radio == "enabled"}
    result.update(get_connectivity())
    return result


# ── Request Handler ───────────────────────────────────────────────────────────

class Handler(BaseHTTPRequestHandler):

    def allowed_request(self):
        host = self.headers.get("Host", "")
        origin = self.headers.get("Origin")
        allowed = host in ("localhost:8082", "127.0.0.1:8082") and (
            origin is None or origin in ("http://localhost:7890", "http://127.0.0.1:7890")
        )
        if not allowed:
            self.send_error(403, "Use the local CORZ dashboard")
        return allowed

    def log_message(self, fmt, *args):
        pass  # quiet

    def send_json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "http://localhost:7890"))
        self.send_header("Vary", "Origin")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length))

    def do_OPTIONS(self):
        if not self.allowed_request():
            return
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin", "http://localhost:7890"))
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if not self.allowed_request():
            return
        path = urlparse(self.path).path.rstrip("/")

        if path == "/api/wifi/status":
            try:
                self.send_json(200, get_status())
            except Exception as e:
                self.send_json(500, {"error": str(e)})

        elif path == "/api/wifi/scan":
            try:
                nets, ap_mode_issue = scan_networks()
                resp = {"networks": nets}
                if ap_mode_issue:
                    resp["warning"] = "Interface may be busy (hotspot active) — showing cached results"
                self.send_json(200, resp)
            except Exception as e:
                self.send_json(500, {"networks": [], "error": str(e)})

        else:
            self.send_json(404, {"error": "not found", "path": path})

    def do_POST(self):
        if not self.allowed_request():
            return
        path = urlparse(self.path).path.rstrip("/")
        try:
            data = self.read_json()
        except Exception:
            self.send_json(400, {"error": "bad json"})
            return

        if path == "/api/wifi/hotspot/on":
            ok, msg = set_hotspot()
            self.send_json(200 if ok else 500, {"ok": ok, "message": msg})

        elif path == "/api/wifi/hotspot/off":
            ok, msg = set_client()
            self.send_json(200 if ok else 500, {"ok": ok, "message": msg})

        elif path == "/api/wifi/connect":
            ssid     = data.get("ssid", "").strip()
            password = data.get("password", "")
            if not ssid:
                self.send_json(400, {"ok": False, "message": "ssid required"})
                return
            ok, msg = connect_network(ssid, password)
            self.send_json(200 if ok else 500, {"ok": ok, "message": msg})

        else:
            self.send_json(404, {"error": "not found", "path": path})


# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"[wifi-api] Listening on port {PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("[wifi-api] Stopped.")
