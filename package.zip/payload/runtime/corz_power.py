#!/usr/bin/env python3
"""Loopback-only CORZ power menu broker. No shell or arbitrary commands."""
import argparse
import hmac
import json
import os
import secrets
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen

PORT = 8083
ORIGINS = {'http://localhost:7890', 'http://127.0.0.1:7890'}
HOSTS = {'localhost:8083', '127.0.0.1:8083'}
TOKEN_FILE = Path(__file__).resolve().parent.parent / '.corz-power-token'
COMMANDS = {'shutdown': ['/usr/bin/sudo', '-n', '/usr/bin/systemctl', 'poweroff'],
            'reboot': ['/usr/bin/sudo', '-n', '/usr/bin/systemctl', 'reboot']}


class PowerState:
    def __init__(self, clock=time.monotonic):
        self.lock, self.clock = threading.Lock(), clock
        self.sequence, self.last_request = 0, -100.0
        self.nonce, self.expires = None, 0
        self.busy, self.error = False, ''

    def request(self):
        with self.lock:
            if self.busy or self.clock() - self.last_request < 1.0:
                return
            self.sequence += 1
            self.last_request = self.clock()
            self.nonce, self.expires = secrets.token_urlsafe(32), self.clock() + 120
            self.error = ''

    def snapshot(self):
        with self.lock:
            return dict(sequence=self.sequence, nonce=self.nonce if self.clock() < self.expires else None,
                        busy=self.busy, error=self.error)

    def consume(self, nonce, action):
        with self.lock:
            if action not in (*COMMANDS, 'cancel'):
                raise ValueError('Unknown power action.')
            if not isinstance(nonce, str) or not self.nonce or not hmac.compare_digest(nonce, self.nonce) or self.clock() >= self.expires or self.busy:
                raise ValueError('Power request expired. Press the power button again.')
            self.nonce = None
            self.busy = action != 'cancel'


def execute(state, action):
    try:
        result = subprocess.run(COMMANDS[action], capture_output=True, text=True, timeout=15)
        if result.returncode:
            raise RuntimeError('Power command was denied. Re-run the one-time power setup.')
    except Exception as exc:
        with state.lock:
            state.busy, state.error = False, str(exc)


def handler_for(state, token):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def allowed(self, request=False):
            if self.headers.get('Host') not in HOSTS:
                self.reply(403, {'error': 'Invalid host.'})
                return False
            origin = self.headers.get('Origin')
            if request:
                supplied = self.headers.get('X-CORZ-Power-Token', '')
                valid = origin is None and hmac.compare_digest(supplied, token)
            else:
                valid = origin in ORIGINS
            if not valid:
                self.reply(403, {'error': 'Access denied.'})
            return valid

        def reply(self, status, data):
            body = json.dumps(data).encode()
            self.send_response(status)
            origin = self.headers.get('Origin')
            if origin in ORIGINS:
                self.send_header('Access-Control-Allow-Origin', origin)
                self.send_header('Vary', 'Origin')
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_OPTIONS(self):
            if self.allowed():
                self.reply(200, {})

        def do_GET(self):
            if self.allowed():
                self.reply(200, state.snapshot()) if self.path == '/status' else self.reply(404, {})

        def do_POST(self):
            if not self.allowed(request=self.path == '/request'):
                return
            if self.path == '/request':
                state.request()
                self.reply(200, {'ok': True})
                return
            if self.path != '/action':
                self.reply(404, {})
                return
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 1024 or self.headers.get('Content-Type') != 'application/json':
                    raise ValueError('Expected a small JSON request.')
                data = json.loads(self.rfile.read(size))
                if not isinstance(data, dict):
                    raise ValueError('Expected an object.')
                action = data.get('action')
                state.consume(data.get('nonce'), action)
            except (ValueError, TypeError) as exc:
                self.reply(400, {'error': str(exc)})
                return
            self.reply(200, {'ok': True})
            if action != 'cancel':
                timer = threading.Timer(.3, execute, args=(state, action))
                timer.daemon = True
                timer.start()
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', action='store_true', help='Called by the desktop power key')
    args = parser.parse_args()
    token = TOKEN_FILE.read_text().strip()
    if len(token) < 32 or TOKEN_FILE.stat().st_mode & 0o077:
        raise SystemExit('Missing/insecure power token. Run setup-power-menu.py first.')
    if args.request:
        req = Request(f'http://127.0.0.1:{PORT}/request', data=b'', method='POST',
                      headers={'X-CORZ-Power-Token': token})
        with urlopen(req, timeout=3) as response:
            response.read()
    else:
        ThreadingHTTPServer(('127.0.0.1', PORT), handler_for(PowerState(), token)).serve_forever()


if __name__ == '__main__':
    main()
