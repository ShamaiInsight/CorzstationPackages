#!/usr/bin/env python3
"""One-time labwc setup; run as the Pi desktop user, not with sudo.

python3 ~/corz-station/runtime/setup_power_menu.py
python3 ~/corz-station/runtime/setup_power_menu.py --undo
"""
import argparse
import hashlib
import json
import os
import pwd
import secrets
import shlex
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

STATION = Path(__file__).resolve().parent.parent
STATE = STATION / '.power-menu-setup'
SERVICE = Path('/etc/systemd/system/corz-power.service')
SUDOERS = Path('/etc/sudoers.d/corz-power')
LOGIND = Path('/etc/systemd/logind.conf.d/90-corz-power.conf')
SYSTEM_FILES = (SERVICE, SUDOERS, LOGIND)


def run(*args):
    return subprocess.run(args, check=True)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def xml_power_config(data, command):
    # Preserve comments and any existing XML namespace.
    root = ET.fromstring(data, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True)))
    namespace = root.tag.split('}')[0] + '}' if '}' in root.tag else ''
    if namespace:
        ET.register_namespace('', namespace[1:-1])
    keyboard = root.find(namespace + 'keyboard')
    if keyboard is None:
        keyboard = ET.SubElement(root, namespace + 'keyboard')
    for binding in list(keyboard):
        if binding.tag == namespace + 'keybind' and binding.get('key', '').casefold() in ('xf86poweroff', 'power'):
            keyboard.remove(binding)
    binding = ET.SubElement(keyboard, namespace + 'keybind', {'key': 'XF86PowerOff'})
    action = ET.SubElement(binding, namespace + 'action', {'name': 'Execute'})
    ET.SubElement(action, namespace + 'command').text = command
    return ET.tostring(root, encoding='utf-8', xml_declaration=True) + b'\n'


def plans(home, user):
    config = home / '.config/labwc/rc.xml'
    if config.exists():
        data = config.read_bytes()
    else:
        defaults = next((p for p in (Path('/etc/xdg/labwc/rc.xml'), Path('/usr/share/labwc/rc.xml')) if p.is_file()), None)
        if defaults is None:
            raise RuntimeError('No labwc rc.xml found. Nothing changed; confirm your desktop uses labwc.')
        data = defaults.read_bytes()
    command = shlex.join(['/usr/bin/python3', str(STATION / 'runtime/corz_power.py'), '--request'])
    xml = xml_power_config(data, command)
    service = f'''[Unit]
Description=CORZ local power menu broker
After=network.target
[Service]
User={user}
WorkingDirectory={STATION}
ExecStart=/usr/bin/python3 {STATION}/runtime/corz_power.py
Restart=on-failure
RestartSec=2
UMask=0077
PrivateTmp=true
ProtectSystem=strict
ProtectHome=read-only
[Install]
WantedBy=multi-user.target
'''.encode()
    sudoers = (f'# Managed by CORZ power-menu setup. Exact commands only.\n'
               f'{user} ALL=(root) NOPASSWD: /usr/bin/systemctl poweroff, /usr/bin/systemctl reboot\n').encode()
    logind = b'# Managed by CORZ power-menu setup. Desktop handles short power presses.\n[Login]\nHandlePowerKey=ignore\n'
    return config, {config: xml, SERVICE: service, SUDOERS: sudoers, LOGIND: logind}


def undo():
    record_file = STATE / 'record.json'
    if not record_file.exists():
        raise RuntimeError('No saved CORZ power setup to undo.')
    record = json.loads(record_file.read_text())
    run('sudo', '-v')
    # Do not clobber changes made by the user after installation.
    for item in record['files']:
        path = Path(item['path'])
        if path.exists():
            current = (subprocess.check_output(['sudo', 'sha256sum', str(path)], text=True).split()[0]
                       if item['system'] else digest(path.read_bytes()))
            if current not in (item['installed_sha256'], item.get('original_sha256')):
                raise RuntimeError(f'{path} has changed since setup. Back it up and review manually; no files removed.')
    subprocess.run(['sudo', 'systemctl', 'disable', '--now', 'corz-power.service'], check=False)
    for item in reversed(record['files']):
        path = Path(item['path'])
        if item['backup']:
            path.write_bytes((STATE / item['backup']).read_bytes())
        elif item['system']:
            run('sudo', 'rm', '-f', str(path))
        elif path.exists():
            path.unlink()
    run('sudo', 'systemctl', 'daemon-reload')
    if record.get('token_created'):
        (STATION / '.corz-power-token').unlink(missing_ok=True)
    shutil.rmtree(STATE)
    print('CORZ power setup removed; original desktop config restored. Reboot to apply.')


def setup(home, user, dry_run=False):
    if STATE.exists():
        raise RuntimeError(f'Setup state already exists at {STATE}. Use --undo before changing/reinstalling it.')
    if not (STATION / 'runtime/corz_power.py').is_file() or not (STATION / 'app/www/power-menu.js').is_file():
        raise RuntimeError('Install the dashboard.6 release first; power files are missing.')
    if not shutil.which('labwc'):
        raise RuntimeError('labwc is not installed. Nothing changed.')
    if not shutil.which('visudo') or not Path('/usr/bin/systemctl').exists():
        raise RuntimeError('This setup needs systemctl and visudo.')
    for path in SYSTEM_FILES:
        if path.exists():
            raise RuntimeError(f'{path} already exists but has no setup backup. Nothing changed; review it first.')
    config, contents = plans(home, user)
    if config.is_symlink():
        raise RuntimeError('The labwc config is a symlink. Nothing changed; review it first.')
    print('Desktop power key → CORZ popup; Cancel is selected by default.')
    for path in contents:
        print('Configure:', path)
    if dry_run:
        print('Dry run only. No settings changed.')
        return
    run('sudo', '-v')
    STATE.mkdir(mode=0o700)
    record = {'files': [], 'token_created': False}
    record_path = STATE / 'record.json'
    record_path.write_text(json.dumps(record, indent=2))
    try:
        with tempfile.TemporaryDirectory(prefix='corz-power-') as temporary:
            prepared = []
            for i, (path, data) in enumerate(contents.items()):
                source = Path(temporary) / str(i)
                source.write_bytes(data)
                if path == SUDOERS:
                    run('sudo', 'visudo', '-cf', str(source))
                prepared.append((path, data, source))
            token_file = STATION / '.corz-power-token'
            if not token_file.exists():
                with token_file.open('x') as token:
                    os.chmod(token_file, 0o600)
                    token.write(secrets.token_urlsafe(48) + '\n')
                record['token_created'] = True
                record_path.write_text(json.dumps(record, indent=2))
            elif token_file.stat().st_mode & 0o077 or len(token_file.read_text().strip()) < 32:
                raise RuntimeError('Existing token is insecure or invalid; inspect .corz-power-token.')
            for path, data, source in prepared:
                backup = None
                if path == config and path.exists():
                    backup = 'labwc-rc.xml.before'
                    (STATE / backup).write_bytes(path.read_bytes())
                item = {'path': str(path), 'backup': backup, 'system': path in SYSTEM_FILES,
                        'original_sha256': digest((STATE / backup).read_bytes()) if backup else None,
                        'installed_sha256': digest(data)}
                # Record first, so interrupted setup remains recoverable.
                record['files'].append(item)
                record_path.write_text(json.dumps(record, indent=2))
                if path in SYSTEM_FILES:
                    run('sudo', 'install', '-D', '-o', 'root', '-g', 'root', '-m',
                        '0440' if path == SUDOERS else '0644', str(source), str(path))
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(data)
            run('sudo', 'systemctl', 'daemon-reload')
            run('sudo', 'systemctl', 'enable', '--now', 'corz-power.service')
    except Exception:
        print(f'Setup did not finish. Backups are in {STATE}; run this script with --undo to recover.')
        raise
    print('Setup complete. Reboot the Pi to apply the desktop/logind changes.')
    print('Undo: python3 ' + str(Path(__file__).resolve()) + ' --undo')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--undo', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if os.geteuid() == 0:
        parser.error('Run as the desktop user WITHOUT sudo; the script requests sudo for system settings.')
    account = pwd.getpwuid(os.getuid())
    home = Path(account.pw_dir)
    if home.parent != Path('/home') or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in account.pw_name):
        parser.error('Expected a standard /home/username desktop account.')
    if STATION != home / 'corz-station':
        parser.error('Run the installed script at ~/corz-station/runtime/setup_power_menu.py, not the downloaded source copy.')
    try:
        if args.undo:
            if args.dry_run:
                parser.error('--undo and --dry-run cannot be combined.')
            undo()
        else:
            setup(home, account.pw_name, args.dry_run)
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError, ET.ParseError) as exc:
        raise SystemExit(str(exc)) from None


if __name__ == '__main__':
    main()
