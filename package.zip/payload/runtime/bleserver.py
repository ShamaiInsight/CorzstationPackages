#!/usr/bin/env python3
"""CORZ BLE ↔ WebSocket bridge. Requires the existing bleak and websockets.

Connections are explicit-only: saved selection is a remembered last choice,
never startup authorization. Each selectDevice authorizes one connection
attempt, with no automatic discovery, connection or reconnection.
"""

import asyncio
from contextlib import asynccontextmanager
import json
import logging
import os
from pathlib import Path
import struct
import tempfile
import time

from bleak import BleakScanner, BleakClient
import websockets
from bluez_guard import monitor as monitor_bluez

WS_PORT = 8765
DEVICE_NAME_PREFIX = "CORZ_"
NOTIFY_UUID = "452301ef-cdab-8967-4523-018967452301"
WRITE_UUID = "12345678-1234-1234-1234-1234567890ab"
SCAN_TIMEOUT = 5.0
BROADCAST_HZ = 30
STABILISE_DELAY = 1.0
TURNOFF_BYTE = bytes([0x45])
SLEEP_TIMEOUT = 10.0
DISCOVERY_MAX_AGE = 60.0
CONFIG_PATH = Path(__file__).with_name("ble-selection.json")
ORIENTATION_PATH = Path(__file__).with_name("ble-orientation.json")
orientation = 0


def rotate_axes(roll, pitch, degrees):
    """Clockwise screen rotation for x=roll, y=-pitch."""
    return {0: (roll, pitch), 90: (pitch, -roll),
            180: (-roll, -pitch), 270: (-pitch, roll)}[degrees]


def load_orientation():
    global orientation
    orientation = 0
    try:
        saved = json.loads(ORIENTATION_PATH.read_text())["rotation"]
        if type(saved) is not int or saved not in (0, 90, 180, 270):
            raise ValueError("invalid orientation")
        orientation = saved
    except FileNotFoundError:
        pass
    except Exception as exc:
        log.warning("Cannot load Cradle orientation; using 0 degrees: %s", exc)


def persist_orientation(degrees):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8",
                dir=ORIENTATION_PATH.parent, prefix=".ble-orientation-", delete=False) as out:
            temporary = out.name
            json.dump({"rotation": degrees}, out)
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, ORIENTATION_PATH)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
# Actual kiosk is :7890; retain the earlier local :8080 dashboard as well.
# Missing Origin permits native clients; opaque/file Origins are not trusted.
ALLOWED_ORIGINS = [None] + [
    f"http://{host}:{port}"
    for host in ("localhost", "127.0.0.1", "[::1]")
    for port in (7890, 8080)
]

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s",
                    datefmt="%H:%M:%S")
log = logging.getLogger("bridge")

ws_clients = set()
ble_connected = False
ble_ready = False
ble_device_name = None
ble_device_address = None
pending_turnoff = False
latest_packet = None
bridge_status = "disconnected"
selected_address = None
selected_name = None
selection_error = None
selection_revision = 0
selection_changed = asyncio.Event()
session_token = None
preferred_device = None
active_connection = None
active_session = None
sleep_in_progress = False
discovered = {}
discovered_at = 0.0
scan_task = None
scanner = None
scan_found = {}
guard_error = None


def authorized_bluez_address(address):
    return (session_token is not None and ble_device_address is not None
            and ble_device_address.casefold() == address.casefold()
            and active_connection is not None and not active_connection.done())


async def report_guard_error(error):
    global guard_error
    if guard_error != error:
        guard_error = error
        await broadcast_status(status_message())


def load_selection():
    global selected_address, selected_name, selection_error, bridge_status
    selected_address = selected_name = selection_error = None
    bridge_status = "disconnected"
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if (not isinstance(data, dict) or
                not isinstance(data.get("address"), str) or not data["address"].strip() or
                not isinstance(data.get("name"), str) or
                not data["name"].startswith(DEVICE_NAME_PREFIX)):
            raise ValueError("invalid selection record")
        selected_address, selected_name = data["address"], data["name"]
    except FileNotFoundError:
        pass
    except Exception as exc:
        selection_error = "Cannot load BLE selection; select a discovered device to repair it"
        log.error("%s: %s", selection_error, exc)


def persist_selection(address, name):
    """Replace only after flush+fsync; a failed write leaves live selection alone."""
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8",
                                         dir=CONFIG_PATH.parent,
                                         prefix=".ble-selection-", delete=False) as out:
            temporary = out.name
            json.dump({"address": address, "name": name}, out)
            out.write("\n")
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, CONFIG_PATH)
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def selection_fields():
    return {"selectedAddress": selected_address, "selectedName": selected_name}


def status_message():
    return {"type": "status", "status": bridge_status,
            "rotation": orientation,
            "deviceName": ble_device_name, "deviceAddress": ble_device_address,
            "ready": ble_ready, "scanning": scan_task is not None and not scan_task.done(),
            "selectionError": selection_error or guard_error, **selection_fields()}


def devices_message():
    fresh = time.monotonic() - discovered_at <= DISCOVERY_MAX_AGE
    return {"type": "devices", "devices": [entry[1] for entry in discovered.values()] if fresh else [],
            "scanning": scan_task is not None and not scan_task.done(),
            **selection_fields()}


async def broadcast_status(obj):
    if ws_clients:
        msg = json.dumps(obj)
        await asyncio.gather(*(asyncio.wait_for(c.send(msg), timeout=1.0)
                               for c in tuple(ws_clients)), return_exceptions=True)


async def set_status(status):
    global bridge_status
    bridge_status = status
    await broadcast_status(status_message())


def clear_connection():
    global ble_connected, ble_ready, latest_packet, pending_turnoff, session_token
    global ble_device_name, ble_device_address, bridge_status
    ble_connected = ble_ready = pending_turnoff = False
    latest_packet = session_token = None
    ble_device_name = ble_device_address = None
    bridge_status = "disconnected"


def on_notify(_sender, data):
    """Single overwrite slot; unchanged wire schema, no queue or backlog."""
    global latest_packet
    if len(data) < 8:
        return
    roll, pitch, bpm, battery = struct.unpack_from("<hhhh", data, 0)
    roll, pitch = rotate_axes(roll / 100.0, pitch / 100.0, orientation)
    latest_packet = {"type": "data", "roll": roll,
                     "pitch": pitch, "bpm": bpm, "battery": battery}


async def client_send_loop(websocket):
    last_sent = None
    try:
        while True:
            await asyncio.sleep(1.0 / BROADCAST_HZ)
            pkt = latest_packet
            if pkt is not None and pkt is not last_sent:
                await websocket.send(json.dumps(pkt))
                last_sent = pkt
    except Exception:
        pass


def detected(device, adv):
    name = getattr(adv, "local_name", None) or device.name
    if not isinstance(name, str) or not name.startswith(DEVICE_NAME_PREFIX):
        return
    record = {"address": device.address, "name": name}
    rssi = getattr(adv, "rssi", None)
    if isinstance(rssi, (int, float)):
        record["rssi"] = rssi
    scan_found[device.address.casefold()] = (device, record)


async def perform_scan():
    """Discovery only: one reusable scanner owned by one shared task."""
    global scanner, discovered, discovered_at, scan_found
    scan_found = {}

    if scanner is None:
        scanner = BleakScanner(detection_callback=detected)
    await broadcast_status(devices_message())
    async with scanner:
        await asyncio.sleep(SCAN_TIMEOUT)
    discovered = dict(scan_found)
    discovered_at = time.monotonic()
    await broadcast_status({**devices_message(), "scanning": False})
    return discovered


async def scan_devices():
    global scan_task
    # No await between inspection and assignment: all users share this scan.
    if scan_task is None or scan_task.done():
        scan_task = asyncio.create_task(perform_scan())
        # Consume exceptions even if the only waiting websocket disconnects.
        scan_task.add_done_callback(lambda t: None if t.cancelled() else t.exception())
    return await asyncio.shield(scan_task)


@asynccontextmanager
async def managed_client(device, disconnected_callback, session=None):
    """Never abandon BLE teardown when a switch races with context exit."""
    client = BleakClient(device, disconnected_callback=disconnected_callback)
    if session is not None:
        session["client"] = client
    try:
        await client.__aenter__()
        yield client
    finally:
        # Also clean up a partially completed/failed connection attempt. Bleak's
        # __aexit__ disconnect is safe when the device is already disconnected.
        cleanup = asyncio.create_task(client.__aexit__(None, None, None))
        try:
            await asyncio.shield(cleanup)
        except asyncio.CancelledError:
            await cleanup
            raise


async def run_connection(device, name, revision):
    global ble_connected, ble_ready, ble_device_name, ble_device_address
    global pending_turnoff, session_token, active_session
    # A newer command may arrive before this newly-created task gets CPU time.
    if revision != selection_revision:
        return
    token = object()
    session_token = token
    # Unlike clear_connection's UI flags, this record survives revocation and
    # records the transport itself. Sleep must never mistake UI clearing for
    # an observed BLE disconnect.
    session = {"client": None, "disconnected": asyncio.Event(), "sleep": None}
    active_session = session
    ble_device_name, ble_device_address = name, device.address

    def disconnected(_client):
        session["disconnected"].set()
        if session_token is token:
            clear_connection()

    def notify(sender, data):
        if session_token is token and ble_connected:
            on_notify(sender, data)

    try:
        await set_status("connecting")
        # A fresh BLEDevice object avoids BlueZ cached address/GATT lookups.
        async with managed_client(device, disconnected, session) as client:
            if session_token is not token:
                return
            ble_connected = True
            await set_status("connected")
            await client.start_notify(NOTIFY_UUID, notify)
            write_char = client.services.get_characteristic(WRITE_UUID)
            if write_char is None:
                raise RuntimeError(f"Write characteristic {WRITE_UUID} not found")
            await asyncio.sleep(STABILISE_DELAY)
            if session_token is not token or not client.is_connected:
                return
            ble_ready = True
            await set_status("connected")
            while client.is_connected and session_token is token:
                sleep_request = session["sleep"]
                if pending_turnoff or sleep_request is not None:
                    pending_turnoff = False
                    session["sleep"] = None
                    # Preserve cached characteristic, two writes, timing and timeout.
                    for attempt in range(1, 3):
                        if not client.is_connected or session_token is not token:
                            break
                        try:
                            if sleep_request is not None:
                                sleep_request["writing"] = True
                            await asyncio.wait_for(client.write_gatt_char(
                                write_char, TURNOFF_BYTE, response=False), timeout=3.0)
                            if sleep_request is not None:
                                sleep_request["sent"] = True
                            log.info("turnOff attempt %s sent", attempt)
                        except Exception as exc:
                            if sleep_request is not None and not sleep_request["sent"]:
                                sleep_request["error"] = str(exc) or type(exc).__name__
                            log.warning("turnOff attempt %s failed: %s", attempt, exc)
                            break
                        finally:
                            if sleep_request is not None:
                                sleep_request["writing"] = False
                        if attempt < 2:
                            await asyncio.sleep(0.15)
                await asyncio.sleep(0.05)
    finally:
        clear_connection()
        await set_status("disconnected")


async def ble_loop():
    """Consume explicit requests once. Completion/failure/drop returns to idle.

    The event stays set if another command arrives during cancellation/cleanup;
    the latest request wins, and no stale task can start a superseded session.
    """
    global preferred_device, active_connection
    while True:
        await selection_changed.wait()
        selection_changed.clear()
        device_entry = preferred_device
        preferred_device = None
        revision = selection_revision
        if device_entry is None:  # disconnectDevice, or superseded request
            continue
        try:
            connection = asyncio.create_task(run_connection(
                device_entry[0], device_entry[1]["name"], revision))
            active_connection = connection
            changed = asyncio.create_task(selection_changed.wait())
            try:
                await asyncio.wait((connection, changed), return_when=asyncio.FIRST_COMPLETED)
                if not connection.done():
                    connection.cancel()
                results = await asyncio.gather(connection, return_exceptions=True)
                if isinstance(results[0], Exception):
                    raise results[0]
            finally:
                connection.cancel()
                changed.cancel()
                await asyncio.gather(connection, changed, return_exceptions=True)
                if active_connection is connection:
                    active_connection = None
        except Exception as exc:
            log.exception("Explicit BLE connection attempt failed: %s", exc)
            if revision == selection_revision:
                await set_status("disconnected")
            await broadcast_status({"type": "error", "cmd": "ble", "code": "ble_error",
                                    "message": "BLE connection failed; scan/select to try again"})


async def handle_command(websocket, msg):
    global pending_turnoff, selected_address, selected_name, selection_error
    global selection_revision, preferred_device, bridge_status
    global orientation, latest_packet

    async def reply(obj):
        await websocket.send(json.dumps(obj))

    async def error(code, message):
        await reply({"type": "error", "cmd": msg.get("cmd") if isinstance(msg, dict) else None,
                     "code": code, "message": message})

    if not isinstance(msg, dict):
        await error("invalid_command", "Expected a JSON object")
        return
    cmd = msg.get("cmd")
    if cmd == "setOrientation":
        degrees = msg.get("rotation")
        if type(degrees) is not int or degrees not in (0, 90, 180, 270):
            await error("invalid_rotation", "Rotation must be 0, 90, 180 or 270 degrees")
            return
        try:
            persist_orientation(degrees)
        except Exception as exc:
            log.warning("Cannot save orientation: %s", exc)
            await error("persist_failed", "Orientation was not changed: cannot save configuration")
            return
        orientation = degrees
        latest_packet = None
        await reply({"type": "orientation", "rotation": orientation, "ok": True})
        await broadcast_status(status_message())
    elif cmd == "turnOff":
        if ble_ready:
            pending_turnoff = True
        else:
            log.warning("turnOff ignored — BLE not ready")
    elif cmd == "sleepDevice":
        await sleep_device(websocket, msg)
    elif cmd in ("getDevices", "status"):
        await reply(devices_message())
        await reply(status_message())
    elif cmd == "scanDevices":
        try:
            # Concurrent requests join the existing scan, not another BlueZ scan.
            await scan_devices()
            await reply(devices_message())
        except Exception as exc:
            log.warning("Requested scan failed: %s", exc)
            await error("scan_failed", "BLE scan failed; check adapter availability and retry")
    elif cmd == "selectDevice":
        address = msg.get("address")
        entry = discovered.get(address.casefold()) if isinstance(address, str) else None
        if entry is None or time.monotonic() - discovered_at > DISCOVERY_MAX_AGE:
            await error("not_discovered", "Select an address from a scan within the last 60 seconds")
            return
        _device, record = entry
        try:
            persist_selection(record["address"], record["name"])
        except Exception as exc:
            log.error("Cannot persist BLE selection: %s", exc)
            await error("persist_failed", "Selection was not changed: cannot save BLE config")
            return
        selected_address, selected_name = record["address"], record["name"]
        selection_error = None
        selection_revision += 1
        preferred_device = entry
        clear_connection()  # invalidate callbacks/commands before any await
        if active_connection is not None and not active_connection.done():
            bridge_status = "disconnecting"
        selection_changed.set()
        await reply({"type": "selection", "cmd": cmd, "ok": True, **selection_fields()})
        await broadcast_status(devices_message())
        await broadcast_status(status_message())
    elif cmd == "disconnectDevice":
        # Remember the last choice, but revoke all queued/current authorization.
        selection_revision += 1
        preferred_device = None
        previous = active_connection
        clear_connection()
        if previous is not None and not previous.done():
            bridge_status = "disconnecting"
        selection_changed.set()
        await broadcast_status(status_message())
        if previous is not None:
            # Acknowledge after its BLE context has exited, not just after revocation.
            results = await asyncio.shield(asyncio.gather(previous, return_exceptions=True))
            if isinstance(results[0], Exception):
                await error("disconnect_failed", "BLE session ended with an error; disconnection could not be confirmed")
                await reply(status_message())
                return
        await reply({"type": "disconnection", "cmd": cmd, "ok": True, **selection_fields()})
        await reply(status_message())
        await broadcast_status(status_message())
    else:
        await error("unknown_command", "Unknown command")


async def sleep_device(websocket, msg):
    """Confirm transport sleep, not merely that a write was queued.

    A ready session receives the same cached-characteristic command as turnOff.
    An unfinished authorized connection is instead revoked and fully torn down.
    Neither path starts discovery or authorizes any future reconnect.
    """
    global sleep_in_progress, selection_revision, preferred_device, bridge_status

    async def reply(ok, code=None, message=None):
        transport = active_session["client"] if active_session is not None else None
        connected = bool(transport.is_connected) if transport is not None else ble_connected
        status = bridge_status
        if connected and status == "disconnected":
            status = "disconnecting"
        result = {"type": "sleepResult", "cmd": "sleepDevice",
                  "requestId": msg.get("requestId"), "ok": ok,
                  "status": status, "ready": ble_ready and connected,
                  "connected": connected, **selection_fields()}
        if code is not None:
            result.update(code=code, message=message)
        await websocket.send(json.dumps(result))

    if sleep_in_progress:
        await reply(False, "busy", "A sleep request is already pending")
        return
    sleep_in_progress = True
    requested_revision = selection_revision
    confirmed_revision = requested_revision
    session = active_session
    connection = active_connection
    request = None
    try:
        async def confirm():
            nonlocal request, session, connection, confirmed_revision
            global selection_revision, preferred_device, bridge_status
            if selection_revision != requested_revision:
                return "superseded", "BLE selection changed during sleep"
            # The BLE loop may have started an already-queued explicit attempt
            # between scheduling this operation and its first execution.
            session, connection = active_session, active_connection
            client = session["client"] if session is not None else None
            running = connection is not None and not connection.done()
            pending = preferred_device is not None
            if not ble_connected and not running and not pending:
                if client is not None and client.is_connected:
                    return "disconnect_failed", "BLE transport is still connected"
                return None
            if ble_ready and ble_connected and running and client is not None:
                revision = selection_revision
                request = {"sent": False, "writing": False, "error": None}
                session["sleep"] = request
                while True:
                    if revision != selection_revision or active_session is not session:
                        return "superseded", "BLE selection changed during sleep"
                    if request["error"] is not None:
                        return "write_failed", "BLE sleep command could not be sent"
                    if connection.done() and not connection.cancelled():
                        if connection.exception() is not None:
                            return "ble_error", "BLE session failed during sleep"
                    disconnected = session["disconnected"].is_set() or not client.is_connected
                    if disconnected:
                        if request["sent"]:
                            clear_connection()
                            return None
                        if not request["writing"]:
                            return "disconnected_before_write", "BLE disconnected before the sleep command was sent"
                    await asyncio.sleep(0.02)
            # Connecting (including queued selection or GATT setup): no usable
            # characteristic is assumed. Revoke before yielding to the BLE loop.
            selection_revision += 1
            revision = selection_revision
            confirmed_revision = revision
            preferred_device = None
            clear_connection()
            if running:
                bridge_status = "disconnecting"
            selection_changed.set()
            await broadcast_status(status_message())
            if running:
                results = await asyncio.shield(asyncio.gather(connection, return_exceptions=True))
                if isinstance(results[0], Exception):
                    return "disconnect_failed", "BLE teardown failed"
            if revision != selection_revision or preferred_device is not None:
                return "superseded", "BLE selection changed during sleep"
            client = session["client"] if session is not None else None
            if client is not None and client.is_connected:
                return "disconnect_failed", "BLE transport is still connected"
            return None

        try:
            failure = await asyncio.wait_for(confirm(), timeout=SLEEP_TIMEOUT)
        except asyncio.TimeoutError:
            failure = ("sleep_timeout", "BLE sleep/disconnection was not confirmed within the deadline")
        except Exception as exc:
            log.warning("Sleep request failed: %s", exc)
            failure = ("ble_error", "BLE sleep/disconnection could not be confirmed")
        # wait_for resumes its caller on a later event-loop turn. A select or
        # disconnect may supersede even an idle confirmation during that gap.
        if failure is None and (selection_revision != confirmed_revision or
                                preferred_device is not None):
            failure = ("superseded", "BLE selection changed during sleep")
        if failure is None:
            await reply(True)
        else:
            await reply(False, *failure)
    finally:
        if session is not None and session["sleep"] is request:
            session["sleep"] = None
        sleep_in_progress = False


async def ws_handler(websocket, _path=None):
    ws_clients.add(websocket)
    sender = None
    scan_request = None
    sleep_request = None
    try:
        await websocket.send(json.dumps(status_message()))
        sender = asyncio.create_task(client_send_loop(websocket))
        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except (json.JSONDecodeError, UnicodeDecodeError, TypeError):
                await websocket.send(json.dumps({"type": "error", "cmd": None,
                    "code": "invalid_json", "message": "Expected valid JSON"}))
                continue
            if isinstance(msg, dict) and msg.get("cmd") == "sleepDevice":
                if sleep_request is not None and not sleep_request.done():
                    await websocket.send(json.dumps({"type": "sleepResult", "cmd": "sleepDevice",
                        "requestId": msg.get("requestId"), "ok": False,
                        "code": "busy", "message": "A sleep request is already pending"}))
                else:
                    sleep_request = asyncio.create_task(handle_command(websocket, msg))
                    sleep_request.add_done_callback(lambda t: None if t.cancelled() else t.exception())
                    # Capture this request before reading a later select/disconnect
                    # command, even when websocket.send completes without yielding.
                    await asyncio.sleep(0)
            elif isinstance(msg, dict) and msg.get("cmd") == "scanDevices":
                # A five-second scan must not delay turnOff/selection on this socket.
                if scan_request is not None and not scan_request.done():
                    await websocket.send(json.dumps({"type": "error", "cmd": "scanDevices",
                        "code": "busy", "message": "A scan request is already pending on this connection"}))
                else:
                    scan_request = asyncio.create_task(handle_command(websocket, msg))
                    scan_request.add_done_callback(lambda t: None if t.cancelled() else t.exception())
            else:
                await handle_command(websocket, msg)
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        if sender is not None:
            sender.cancel()
            await asyncio.gather(sender, return_exceptions=True)
        if scan_request is not None:
            scan_request.cancel()
            await asyncio.gather(scan_request, return_exceptions=True)
        if sleep_request is not None:
            sleep_request.cancel()
            await asyncio.gather(sleep_request, return_exceptions=True)
        ws_clients.discard(websocket)


async def main():
    load_selection()
    load_orientation()
    log.info("WebSocket server listening on ws://0.0.0.0:%s", WS_PORT)
    async with websockets.serve(ws_handler, "0.0.0.0", WS_PORT, origins=ALLOWED_ORIGINS):
        guard = asyncio.create_task(monitor_bluez(authorized_bluez_address, report_guard_error))
        try:
            await ble_loop()
        finally:
            guard.cancel()
            await asyncio.gather(guard, return_exceptions=True)
            if scan_task is not None and not scan_task.done():
                scan_task.cancel()
                await asyncio.gather(scan_task, return_exceptions=True)


if __name__ == "__main__":
    asyncio.run(main())
