#!/usr/bin/env python3
"""
BLE ↔ WebSocket Bridge Server
Raspberry Pi — CORZ Arduino (nRF52 BLE)

Install:  pip install bleak websockets
Run:      python3 server.py
"""

import asyncio
import json
import struct
import logging
from bleak import BleakScanner, BleakClient
import websockets

# ─── Configuration ────────────────────────────────────────────────────────────

WS_PORT            = 8765
DEVICE_NAME_PREFIX = "CORZ_"
NOTIFY_UUID        = "452301ef-cdab-8967-4523-018967452301"
WRITE_UUID         = "12345678-1234-1234-1234-1234567890ab"

SCAN_TIMEOUT       = 5.0    # seconds per scan pass
RECONNECT_DELAY    = 3      # seconds between BLE reconnect attempts
BROADCAST_HZ       = 30     # max rate to forward data to WS clients
STABILISE_DELAY    = 1.0    # seconds after connect before accepting commands
TURNOFF_BYTE       = bytes([0x45])

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("bridge")

# ─── Shared state ─────────────────────────────────────────────────────────────

ws_clients:      set              = set()
ble_connected:   bool             = False
ble_ready:       bool             = False
ble_device_name: str | None       = None
pending_turnoff: bool             = False

# Single-slot latest packet — overwritten on every BLE notification.
# Per-client send loops read it; no queue, no backlog.
latest_packet: dict | None = None

# ─── Status broadcast ─────────────────────────────────────────────────────────

async def broadcast_status(obj: dict):
    if not ws_clients:
        return
    msg = json.dumps(obj)
    await asyncio.gather(
        *(c.send(msg) for c in ws_clients),
        return_exceptions=True,
    )

# ─── BLE notification callback ────────────────────────────────────────────────

def on_notify(_sender, data: bytearray):
    """Overwrites the single latest_packet slot. No queuing."""
    global latest_packet
    if len(data) < 8:
        return
    roll, pitch, bpm, battery = struct.unpack_from("<hhhh", data, 0)
    latest_packet = {
        "type":    "data",
        "roll":    roll    / 100.0,
        "pitch":   pitch   / 100.0,
        "bpm":     bpm,
        "battery": battery,
    }

# ─── Per-client send loop ─────────────────────────────────────────────────────

async def client_send_loop(websocket):
    """
    Ticks at BROADCAST_HZ and sends latest_packet only when it has changed.
    Awaiting send() before moving on applies natural backpressure — a slow
    client slows its own loop, not others'. Because latest_packet is a single
    overwriting slot, stale frames are dropped rather than queued.
    """
    interval   = 1.0 / BROADCAST_HZ
    last_sent: dict | None = None
    try:
        while True:
            await asyncio.sleep(interval)
            pkt = latest_packet
            if pkt is not None and pkt is not last_sent:
                await websocket.send(json.dumps(pkt))
                last_sent = pkt
    except Exception:
        pass  # client disconnected or task cancelled — both are fine

# ─── BLE connection loop ──────────────────────────────────────────────────────

async def ble_loop():
    global ble_connected, ble_ready, ble_device_name
    global pending_turnoff, latest_packet

    while True:
        # ── Scan ──────────────────────────────────────────────────────────────
        log.info("Scanning for BLE device …")
        await broadcast_status({"type": "status", "status": "scanning", "deviceName": None})

        device = None
        while device is None:
            # BleakScanner.find_device_by_filter gives a fresh BLEDevice object
            # each scan — avoids BlueZ returning a stale cached device.
            device = await BleakScanner.find_device_by_filter(
                lambda d, _adv: d.name is not None and d.name.startswith(DEVICE_NAME_PREFIX),
                timeout=SCAN_TIMEOUT,
            )
            if device is None:
                log.info("Device not found, retrying …")

        ble_device_name = device.name
        log.info(f'Found device: "{ble_device_name}" ({device.address})')
        await broadcast_status({"type": "status", "status": "connecting", "deviceName": ble_device_name})

        # ── Connect ───────────────────────────────────────────────────────────
        # IMPORTANT: pass the BLEDevice *object*, not just the address string.
        # Passing the object lets bleak use fresh advertisement data and avoids
        # BlueZ serving cached/stale D-Bus GATT paths from a previous session.
        try:
            async with BleakClient(device) as client:
                ble_connected   = True
                ble_ready       = False
                latest_packet   = None   # clear stale data from last session
                pending_turnoff = False  # discard any stale command

                log.info(f'Connected to "{ble_device_name}"')
                await broadcast_status({"type": "status", "status": "connected", "deviceName": ble_device_name})

                # Subscribe to notifications
                await client.start_notify(NOTIFY_UUID, on_notify)
                log.info("Subscribed — streaming data")

                # IMPORTANT: cache the write characteristic object NOW, once,
                # from the live GATT service table. Using this object for
                # writes bypasses any UUID→handle lookup that might hit a
                # BlueZ cache from the previous connection.
                services    = client.services
                write_char  = services.get_characteristic(WRITE_UUID)
                if write_char is None:
                    log.error(f"Write characteristic {WRITE_UUID} not found — check UUID!")
                    # continue to finally / reconnect
                else:
                    log.info(f"Write char cached: handle=0x{write_char.handle:04x}")

                    # Short delay so the Arduino's GATT stack is fully settled
                    await asyncio.sleep(STABILISE_DELAY)
                    ble_ready = True
                    log.info("BLE ready — accepting commands")

                    # ── Inner keep-alive / command loop ───────────────────────
                    while client.is_connected:
                        if pending_turnoff:
                            pending_turnoff = False
                            log.info("Sending turnOff command …")

                            # Write to the cached characteristic object (not UUID string).
                            # Two writes with a gap: the Arduino's callback calls
                            # Bluefruit.disconnect() after ~70 ms. The second write
                            # is a safety-net that lands inside that 70 ms window
                            # in case the first was lost during BLE stack teardown.
                            for attempt in range(1, 3):
                                if not client.is_connected:
                                    log.info(f"  attempt {attempt}: skipped (already disconnected)")
                                    break
                                try:
                                    await asyncio.wait_for(
                                        client.write_gatt_char(write_char, TURNOFF_BYTE, response=False),
                                        timeout=3.0,
                                    )
                                    log.info(f"  attempt {attempt}: write sent OK")
                                except asyncio.TimeoutError:
                                    log.warning(f"  attempt {attempt}: write timed out")
                                    break
                                except Exception as e:
                                    log.warning(f"  attempt {attempt}: write error — {e}")
                                    break
                                if attempt < 2:
                                    await asyncio.sleep(0.15)

                        await asyncio.sleep(0.05)

        except Exception as e:
            log.error(f"BLE error: {e}")
        finally:
            ble_connected   = False
            ble_ready       = False
            latest_packet   = None
            pending_turnoff = False
            log.info("Disconnected from BLE device")
            await broadcast_status({"type": "status", "status": "disconnected", "deviceName": None})

        log.info(f"Reconnecting in {RECONNECT_DELAY} s …")
        await asyncio.sleep(RECONNECT_DELAY)

# ─── WebSocket handler ────────────────────────────────────────────────────────

async def ws_handler(websocket):
    global pending_turnoff

    ws_clients.add(websocket)
    addr = websocket.remote_address
    log.info(f"[WS] Client connected: {addr}")

    # Send current BLE state immediately to the new client
    await websocket.send(json.dumps({
        "type":       "status",
        "status":     "connected" if ble_connected else "scanning",
        "deviceName": ble_device_name,
    }))

    # Each client gets its own send loop — slow clients don't block others.
    sender = asyncio.create_task(client_send_loop(websocket))

    try:
        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                log.warning(f"[WS] Bad JSON from {addr}: {raw!r}")
                continue

            if msg.get("cmd") == "turnOff":
                if ble_ready:
                    pending_turnoff = True
                    log.info(f"[WS] turnOff queued (from {addr})")
                else:
                    log.warning(f"[WS] turnOff ignored — BLE not ready (from {addr})")
            else:
                log.warning(f"[WS] Unknown command from {addr}: {msg}")

    except websockets.exceptions.ConnectionClosedError:
        pass
    finally:
        sender.cancel()
        ws_clients.discard(websocket)
        log.info(f"[WS] Client disconnected: {addr}")

# ─── Entry point ──────────────────────────────────────────────────────────────

async def main():
    log.info(f"WebSocket server listening on ws://0.0.0.0:{WS_PORT}")
    async with websockets.serve(ws_handler, "0.0.0.0", WS_PORT):
        await ble_loop()

if __name__ == "__main__":
    asyncio.run(main())
