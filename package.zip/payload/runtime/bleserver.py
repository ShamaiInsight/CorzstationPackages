#!/usr/bin/env python3
"""CORZ BLE ↔ WebSocket bridge. Requires the existing bleak and websockets.

Selection is opt-in: absent ble-selection.json retains legacy auto-connect.
A present but unreadable/invalid selection file fails closed, never selecting a
different plate. Only devices in a recent successful scan can be selected.
"""

import asyncio
import json
import logging
import os
from pathlib import Path
import struct
import tempfile
import time

from bleak import BleakScanner, BleakClient
import websockets

WS_PORT = 8765
DEVICE_NAME_PREFIX = "CORZ_"
NOTIFY_UUID = "452301ef-cdab-8967-4523-018967452301"
WRITE_UUID = "12345678-1234-1234-1234-1234567890ab"
SCAN_TIMEOUT = 5.0
RECONNECT_DELAY = 3
BROADCAST_HZ = 30
STABILISE_DELAY = 1.0
TURNOFF_BYTE = bytes([0x45])
DISCOVERY_MAX_AGE = 60.0
CONFIG_PATH = Path(__file__).with_name("ble-selection.json")
# Actual kiosk is :7890; retain the earlier local :8080 dashboard as well.
# Missing Origin permits native clients; opaque/file Origins are not trusted.
ALLOWED_ORIGINS = [None] + [
    f"http://{host}:{port}"
    for host in ("localhost", "127.0.0.1", "[::1]")
    for port in (7890, 8080)
]

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s",
                    datefmt="%H:%M:%S")
log = logging.getLogger("bridge")

ws_clients = set()
ble_connected = False
ble_ready = False
ble_device_name = None
ble_device_address = None
pending_turnoff = False
latest_packet = None
bridge_status = "scanning"
selected_address = None
selected_name = None
selection_error = None
selection_revision = 0
selection_changed = asyncio.Event()
session_token = None
preferred_device = None
discovered = {}
discovered_at = 0.0
scan_task = None
scanner = None
scan_found = {}


def load_selection():
    global selected_address, selected_name, selection_error
    selected_address = selected_name = selection_error = None
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if (not isinstance(data, dict) or
                not isinstance(data.get("address"), str) or not data["address"].strip() or
                not isinstance(data.get("name"), str) or
                not data["name"].startswith(DEVICE_NAME_PREFIX)):
            raise ValueError("invalid selection record")
        selected_address, selected_name = data["address"], data["name"]
    except FileNotFoundError:
        pass
    except Exception as exc:
        selection_error = "Cannot load BLE selection; select a discovered device to repair it"
        log.error("%s: %s", selection_error, exc)


def persist_selection(address, name):
    """Replace only after flush+fsync; a failed write leaves live selection alone."""
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8",
                                         dir=CONFIG_PATH.parent,
                                         prefix=".ble-selection-", delete=False) as out:
            temporary = out.name
            json.dump({"address": address, "name": name}, out)
            out.write("\n")
            out.flush()
            os.fsync(out.fileno())
        os.replace(temporary, CONFIG_PATH)
    finally:
        if temporary is not None:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def selection_fields():
    return {"selectedAddress": selected_address, "selectedName": selected_name}


def status_message():
    return {"type": "status", "status": bridge_status,
            "deviceName": ble_device_name, "deviceAddress": ble_device_address,
            "ready": ble_ready, "scanning": scan_task is not None and not scan_task.done(),
            "selectionError": selection_error, **selection_fields()}


def devices_message():
    fresh = time.monotonic() - discovered_at <= DISCOVERY_MAX_AGE
    return {"type": "devices", "devices": [entry[1] for entry in discovered.values()] if fresh else [],
            "scanning": scan_task is not None and not scan_task.done(),
            **selection_fields()}


async def broadcast_status(obj):
    if ws_clients:
        msg = json.dumps(obj)
        await asyncio.gather(*(asyncio.wait_for(c.send(msg), timeout=1.0)
                               for c in tuple(ws_clients)), return_exceptions=True)


async def set_status(status):
    global bridge_status
    bridge_status = status
    await broadcast_status(status_message())


def clear_connection():
    global ble_connected, ble_ready, latest_packet, pending_turnoff, session_token
    global ble_device_name, ble_device_address, bridge_status
    ble_connected = ble_ready = pending_turnoff = False
    latest_packet = session_token = None
    ble_device_name = ble_device_address = None
    bridge_status = "disconnected"


def on_notify(_sender, data):
    """Single overwrite slot; unchanged wire schema, no queue or backlog."""
    global latest_packet
    if len(data) < 8:
        return
    roll, pitch, bpm, battery = struct.unpack_from("<hhhh", data, 0)
    latest_packet = {"type": "data", "roll": roll / 100.0,
                     "pitch": pitch / 100.0, "bpm": bpm, "battery": battery}


async def client_send_loop(websocket):
    last_sent = None
    try:
        while True:
            await asyncio.sleep(1.0 / BROADCAST_HZ)
            pkt = latest_packet
            if pkt is not None and pkt is not last_sent:
                await websocket.send(json.dumps(pkt))
                last_sent = pkt
    except Exception:
        pass


def detected(device, adv):
    name = getattr(adv, "local_name", None) or device.name
    if not isinstance(name, str) or not name.startswith(DEVICE_NAME_PREFIX):
        return
    record = {"address": device.address, "name": name}
    rssi = getattr(adv, "rssi", None)
    if isinstance(rssi, (int, float)):
        record["rssi"] = rssi
    scan_found[device.address.casefold()] = (device, record)


async def perform_scan():
    """One reusable scanner, owned by one shared task, including auto-reconnect."""
    global scanner, discovered, discovered_at, scan_found
    scan_found = {}

    if scanner is None:
        scanner = BleakScanner(detection_callback=detected)
    await broadcast_status(devices_message())
    async with scanner:
        await asyncio.sleep(SCAN_TIMEOUT)
    discovered = dict(scan_found)
    discovered_at = time.monotonic()
    await broadcast_status({**devices_message(), "scanning": False})
    return discovered


async def scan_devices():
    global scan_task
    # No await between inspection and assignment: all users share this scan.
    if scan_task is None or scan_task.done():
        scan_task = asyncio.create_task(perform_scan())
        # Consume exceptions even if the only waiting websocket disconnects.
        scan_task.add_done_callback(lambda t: None if t.cancelled() else t.exception())
    return await asyncio.shield(scan_task)


async def run_connection(device, name):
    global ble_connected, ble_ready, ble_device_name, ble_device_address
    global pending_turnoff, session_token
    token = object()
    session_token = token
    ble_device_name, ble_device_address = name, device.address
    await set_status("connecting")

    def disconnected(_client):
        if session_token is token:
            clear_connection()

    def notify(sender, data):
        if session_token is token and ble_connected:
            on_notify(sender, data)

    try:
        # A fresh BLEDevice object avoids BlueZ cached address/GATT lookups.
        async with BleakClient(device, disconnected_callback=disconnected) as client:
            if session_token is not token:
                return
            ble_connected = True
            await set_status("connected")
            await client.start_notify(NOTIFY_UUID, notify)
            write_char = client.services.get_characteristic(WRITE_UUID)
            if write_char is None:
                raise RuntimeError(f"Write characteristic {WRITE_UUID} not found")
            await asyncio.sleep(STABILISE_DELAY)
            if session_token is not token or not client.is_connected:
                return
            ble_ready = True
            await set_status("connected")
            while client.is_connected and session_token is token:
                if pending_turnoff:
                    pending_turnoff = False
                    # Preserve cached characteristic, two writes, timing and timeout.
                    for attempt in range(1, 3):
                        if not client.is_connected or session_token is not token:
                            break
                        try:
                            await asyncio.wait_for(client.write_gatt_char(
                                write_char, TURNOFF_BYTE, response=False), timeout=3.0)
                            log.info("turnOff attempt %s sent", attempt)
                        except Exception as exc:
                            log.warning("turnOff attempt %s failed: %s", attempt, exc)
                            break
                        if attempt < 2:
                            await asyncio.sleep(0.15)
                await asyncio.sleep(0.05)
    finally:
        clear_connection()
        await set_status("disconnected")


async def wait_for_selection(timeout):
    try:
        await asyncio.wait_for(selection_changed.wait(), timeout)
    except asyncio.TimeoutError:
        pass


async def ble_loop():
    global preferred_device
    while True:
        selection_changed.clear()
        revision = selection_revision
        try:
            if selection_error:
                await set_status("selectionError")
                await wait_for_selection(RECONNECT_DELAY)
                continue
            device_entry = preferred_device
            preferred_device = None
            if device_entry is None:
                if not ble_connected:
                    await set_status("scanning")
                found = await scan_devices()
                if revision != selection_revision:
                    continue
                if selected_address:
                    device_entry = found.get(selected_address.casefold())
                else:
                    device_entry = next(iter(found.values()), None)
            if device_entry is None:
                await set_status("unavailable" if selected_address else "scanning")
                await wait_for_selection(RECONNECT_DELAY)
                continue
            connection = asyncio.create_task(run_connection(device_entry[0], device_entry[1]["name"]))
            changed = asyncio.create_task(selection_changed.wait())
            try:
                await asyncio.wait((connection, changed), return_when=asyncio.FIRST_COMPLETED)
                if not connection.done():
                    connection.cancel()
                results = await asyncio.gather(connection, return_exceptions=True)
                if isinstance(results[0], Exception):
                    raise results[0]
            finally:
                connection.cancel()
                changed.cancel()
                await asyncio.gather(connection, changed, return_exceptions=True)
            if revision == selection_revision:
                await wait_for_selection(RECONNECT_DELAY)
        except Exception as exc:
            log.exception("BLE scan/connection failed: %s", exc)
            await set_status("error")
            await broadcast_status({"type": "error", "cmd": "ble", "code": "ble_error",
                                    "message": "BLE scan/connection failed; retrying"})
            await wait_for_selection(RECONNECT_DELAY)


async def handle_command(websocket, msg):
    global pending_turnoff, selected_address, selected_name, selection_error
    global selection_revision, preferred_device, bridge_status

    async def reply(obj):
        await websocket.send(json.dumps(obj))

    async def error(code, message):
        await reply({"type": "error", "cmd": msg.get("cmd") if isinstance(msg, dict) else None,
                     "code": code, "message": message})

    if not isinstance(msg, dict):
        await error("invalid_command", "Expected a JSON object")
        return
    cmd = msg.get("cmd")
    if cmd == "turnOff":
        if ble_ready:
            pending_turnoff = True
        else:
            log.warning("turnOff ignored — BLE not ready")
    elif cmd in ("getDevices", "status"):
        await reply(devices_message())
        await reply(status_message())
    elif cmd == "scanDevices":
        try:
            # Concurrent requests join the existing scan, not another BlueZ scan.
            await scan_devices()
            await reply(devices_message())
        except Exception as exc:
            log.warning("Requested scan failed: %s", exc)
            await error("scan_failed", "BLE scan failed; check adapter availability and retry")
    elif cmd == "selectDevice":
        address = msg.get("address")
        entry = discovered.get(address.casefold()) if isinstance(address, str) else None
        if entry is None or time.monotonic() - discovered_at > DISCOVERY_MAX_AGE:
            await error("not_discovered", "Select an address from a scan within the last 60 seconds")
            return
        device, record = entry
        try:
            persist_selection(record["address"], record["name"])
        except Exception as exc:
            log.error("Cannot persist BLE selection: %s", exc)
            await error("persist_failed", "Selection was not changed: cannot save BLE config")
            return
        changed = selected_address is None or selected_address.casefold() != device.address.casefold()
        selected_address, selected_name = record["address"], record["name"]
        selection_error = None
        if changed or not ble_connected:
            selection_revision += 1
            preferred_device = entry
            clear_connection()  # invalidate callbacks/commands before any await
            bridge_status = "disconnected"
            selection_changed.set()
        await reply({"type": "selection", "ok": True, **selection_fields()})
        await broadcast_status(devices_message())
        await broadcast_status(status_message())
    else:
        await error("unknown_command", "Unknown command")


async def ws_handler(websocket, _path=None):
    ws_clients.add(websocket)
    sender = None
    scan_request = None
    try:
        await websocket.send(json.dumps(status_message()))
        sender = asyncio.create_task(client_send_loop(websocket))
        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except (json.JSONDecodeError, UnicodeDecodeError, TypeError):
                await websocket.send(json.dumps({"type": "error", "cmd": None,
                    "code": "invalid_json", "message": "Expected valid JSON"}))
                continue
            if isinstance(msg, dict) and msg.get("cmd") == "scanDevices":
                # A five-second scan must not delay turnOff/selection on this socket.
                if scan_request is not None and not scan_request.done():
                    await websocket.send(json.dumps({"type": "error", "cmd": "scanDevices",
                        "code": "busy", "message": "A scan request is already pending on this connection"}))
                else:
                    scan_request = asyncio.create_task(handle_command(websocket, msg))
                    scan_request.add_done_callback(lambda t: None if t.cancelled() else t.exception())
            else:
                await handle_command(websocket, msg)
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        if sender is not None:
            sender.cancel()
            await asyncio.gather(sender, return_exceptions=True)
        if scan_request is not None:
            scan_request.cancel()
            await asyncio.gather(scan_request, return_exceptions=True)
        ws_clients.discard(websocket)


async def main():
    load_selection()
    log.info("WebSocket server listening on ws://0.0.0.0:%s", WS_PORT)
    async with websockets.serve(ws_handler, "0.0.0.0", WS_PORT, origins=ALLOWED_ORIGINS):
        try:
            await ble_loop()
        finally:
            if scan_task is not None and not scan_task.done():
                scan_task.cancel()
                await asyncio.gather(scan_task, return_exceptions=True)


if __name__ == "__main__":
    asyncio.run(main())
