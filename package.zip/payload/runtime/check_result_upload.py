#!/usr/bin/env python3
"""Read-only Pi diagnostics. Never creates a score or prints credentials."""
import argparse
import json
import os
import sys
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError

BASE='http://localhost:7890'
FIELDS=('sessionsPlayed','totalScore','bestScore','averageAccuracy','bestAccuracy','totalPlaySeconds')

def get(path):
    try:
        with urlopen(BASE+path,timeout=30) as response:
            return json.load(response)
    except HTTPError as exc:
        try:message=json.loads(exc.read()).get('error','HTTP '+str(exc.code))
        except Exception:message='HTTP '+str(exc.code)
        raise RuntimeError(message) from None
    except (URLError,TimeoutError,OSError):
        raise RuntimeError('Cannot reach the local bridge. Check ourcorz-bridge.service.') from None

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--game',default='PLANKZ · EASY',help='Exact uploaded game name')
    group=p.add_mutually_exclusive_group()
    group.add_argument('--baseline',type=Path,help='Save selected-player statistics before playing')
    group.add_argument('--compare',type=Path,help='Compare fresh statistics after playing')
    args=p.parse_args()
    try:
        status=get('/api/status')
        print('Bridge:',status.get('bridgeBuild'))
        print('Upstream:',status.get('upstream'))
        print('API key configured:',bool(status.get('configured')))
        print('Score upload supported:',bool(status.get('scoreWriteSupported')))
        print('Last local upload:',json.dumps(status.get('lastResult'),ensure_ascii=False))
        if not status.get('scoreWriteSupported'):
            raise RuntimeError('Install dashboard.8 or later before testing uploads.')
        current=get('/api/current-user')
        print('Selected profile writable:',current.get('readOnly') is False)
        profile=get('/api/profile?'+urlencode({'game':args.game}))
        snapshot={'tag':current['profile_id'],'game':args.game,'stats':{k:profile.get(k) for k in FIELDS}}
        print('Game:',args.game)
        print('Fresh server statistics:',json.dumps(snapshot['stats'],ensure_ascii=False))
        if args.baseline:
            # NFC identifiers are private: store baseline with owner-only permissions.
            fd=os.open(args.baseline,os.O_CREAT|os.O_TRUNC|os.O_WRONLY,0o600)
            os.fchmod(fd,0o600)
            with os.fdopen(fd,'w') as f:json.dump(snapshot,f,indent=2)
            print('Baseline saved. Play one real session, wait for Uploaded to OurCorz, then compare.')
        if args.compare:
            before=json.loads(args.compare.read_text())
            if before['tag']!=snapshot['tag'] or before['game']!=snapshot['game']:
                raise RuntimeError('The player or game differs from the baseline. Use the same tag and difficulty.')
            changes={k:{'before':before['stats'].get(k),'after':snapshot['stats'].get(k)} for k in FIELDS}
            print('Comparison:',json.dumps(changes,ensure_ascii=False))
            old,new=before['stats'].get('sessionsPlayed'),snapshot['stats'].get('sessionsPlayed')
            if isinstance(old,(int,float)) and isinstance(new,(int,float)) and new>old:
                print('PASS: server session count increased. Confirm the expected score in Hall of Fame too.')
            else:
                print('NOT CONFIRMED: server session count has not increased. Check the game result message and Last local upload; wait briefly and compare again. Do not resubmit the same score.')
                return 2
    except (RuntimeError,ValueError,KeyError,OSError) as exc:
        print('CHECK FAILED:',exc)
        return 1
    return 0

if __name__=='__main__':sys.exit(main())
