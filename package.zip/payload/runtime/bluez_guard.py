"""Enforce explicit CORZ ownership at the Linux Bluetooth layer.

Uses dbus-fast, already required by Bleak on Linux. Never initiates connections,
changes adapter power, removes pairing, or touches non-CORZ devices.
"""
import asyncio
import logging

log = logging.getLogger("bluez-guard")
DEVICE = "org.bluez.Device1"


def value(properties, key, default=None):
    item = properties.get(key)
    return getattr(item, "value", default)


def is_cradle(properties):
    return any(str(value(properties, key, "")).upper().startswith("CORZ_")
               for key in ("Name", "Alias"))


async def enforce(objects, authorized, call):
    for path, interfaces in objects.items():
        properties = interfaces.get(DEVICE)
        if not properties or not is_cradle(properties):
            continue
        address = str(value(properties, "Address", "")).casefold()
        # Trust is not required for explicit Bleak GATT connections. Removing
        # only this flag also removes one possible desktop reconnect policy.
        try:
            if value(properties, "Trusted", False):
                await call(path, "untrust")
                log.info("Cleared automatic trust for CORZ device %s", address)
        finally:
            # Even if changing trust is denied, still attempt disconnection.
            # Recheck live authorization after awaits: selection may have changed.
            if value(properties, "Connected", False) and not authorized(address):
                await call(path, "disconnect")
                log.warning("Disconnected CORZ link without staff authorization: %s", address)


async def monitor(authorized, report):
    async def checked(bus, message):
        reply = await asyncio.wait_for(bus.call(message), timeout=5)
        if reply.message_type == MessageType.ERROR:
            raise RuntimeError(f"{reply.error_name}: {reply.body}")
        return reply.body

    while True:
        bus = None
        try:
            from dbus_fast import BusType, Message, MessageType, Variant
            from dbus_fast.aio import MessageBus
            bus = await MessageBus(bus_type=BusType.SYSTEM).connect()

            async def call(path, action):
                if action == "untrust":
                    message = Message(destination="org.bluez", path=path,
                        interface="org.freedesktop.DBus.Properties", member="Set",
                        signature="ssv", body=[DEVICE, "Trusted", Variant("b", False)])
                else:
                    message = Message(destination="org.bluez", path=path,
                                      interface=DEVICE, member="Disconnect")
                await checked(bus, message)

            while True:
                body = await checked(bus, Message(destination="org.bluez", path="/",
                    interface="org.freedesktop.DBus.ObjectManager", member="GetManagedObjects"))
                await enforce(body[0], authorized, call)
                await report(None)
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("Cannot enforce CORZ manual connection policy: %s", exc)
            await report("Bluetooth connection guard unavailable; check service logs")
            await asyncio.sleep(3)
        finally:
            if bus is not None:
                bus.disconnect()
