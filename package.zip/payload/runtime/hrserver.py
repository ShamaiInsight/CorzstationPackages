#!/usr/bin/env python3
"""
Dedicated BLE Heart Rate -> WebSocket Server
Raspberry Pi / Linux BlueZ

This server is intentionally separate from bleserver.py.

- bleserver.py keeps handling the CORZ_* gyrometer controller on ws://localhost:8765
- hrserver.py handles ONLY standard BLE Heart Rate devices on ws://localhost:8766

Install:
    pip install bleak websockets

Run:
    python3 hrserver.py

BLE standard UUIDs:
    Heart Rate Service:        0000180d-0000-1000-8000-00805f9b34fb
    Heart Rate Measurement:   00002a37-0000-1000-8000-00805f9b34fb
"""

import asyncio
import json
import logging
from typing import Optional

from bleak import BleakClient, BleakScanner
import websockets

# ─── Configuration ────────────────────────────────────────────────────────────

WS_PORT = 8766
SCAN_TIMEOUT = 6.0
RECONNECT_DELAY = 3.0

HEART_RATE_SERVICE_UUID = "0000180d-0000-1000-8000-00805f9b34fb"
HEART_RATE_MEASUREMENT_UUID = "00002a37-0000-1000-8000-00805f9b34fb"

# Optional name hints used only as a fallback if a sensor does not advertise 180D.
# Keep this broad but safe. Add your own device names here if needed.
HR_NAME_HINTS = (
    "polar",
    "hr",
    "heart",
    "h10",
    "h9",
    "h7",
    "wahoo",
    "tickr",
    "garmin",
    "coospo",
    "magene",
)

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("hrserver")

# ─── Shared state ─────────────────────────────────────────────────────────────

ws_clients: set = set()
hr_connected: bool = False
hr_device_name: Optional[str] = None
latest_bpm: Optional[int] = None
latest_battery: Optional[int] = None


async def broadcast(obj: dict):
    """Broadcast a JSON object to all connected WebSocket clients."""
    if not ws_clients:
        return
    msg = json.dumps(obj)
    await asyncio.gather(*(c.send(msg) for c in list(ws_clients)), return_exceptions=True)


async def broadcast_status(status: str, device_name: Optional[str] = None):
    await broadcast({
        "type": "status",
        "status": status,
        "deviceName": device_name,
    })


def parse_heart_rate_measurement(data: bytearray) -> Optional[int]:
    """
    Parse BLE Heart Rate Measurement characteristic 0x2A37.

    Flags byte bit 0 selects HR format:
      0 = uint8 BPM at byte 1
      1 = uint16 BPM little-endian at bytes 1..2
    """
    if not data or len(data) < 2:
        return None

    flags = data[0]
    is_uint16 = bool(flags & 0x01)

    if is_uint16:
        if len(data) < 3:
            return None
        bpm = int.from_bytes(data[1:3], byteorder="little", signed=False)
    else:
        bpm = int(data[1])

    # Basic sanity filter. Real HR straps normally sit inside this range.
    if bpm < 25 or bpm > 240:
        return None
    return bpm


def has_hr_uuid(service_uuids) -> bool:
    if not service_uuids:
        return False
    target = HEART_RATE_SERVICE_UUID.lower()
    for uuid in service_uuids:
        u = str(uuid).lower()
        if u == target or u.startswith("0000180d") or u == "180d":
            return True
    return False


def looks_like_hr_name(name: Optional[str]) -> bool:
    if not name:
        return False
    n = name.lower()
    return any(hint in n for hint in HR_NAME_HINTS)


async def find_hr_device():
    """Find a BLE device that appears to be a standard Heart Rate sensor."""
    log.info("Scanning for Heart Rate BLE device …")
    await broadcast_status("scanning", None)

    while True:
        try:
            found = await BleakScanner.discover(timeout=SCAN_TIMEOUT, return_adv=True)

            fallback = None
            for _addr, item in found.items():
                device, adv = item
                name = device.name or getattr(adv, "local_name", None) or ""
                uuids = getattr(adv, "service_uuids", None) or []

                # A Cradle may advertise heart-rate data too, but only the staff
                # controller menu may authorize a connection to CORZ devices.
                if any(str(n or "").upper().startswith("CORZ_") for n in
                       (device.name, getattr(adv, "local_name", None))):
                    continue

                if has_hr_uuid(uuids):
                    log.info(f'Found HR service device: "{name or device.address}" ({device.address})')
                    return device

                # Fallback only. Some sensors do not advertise service UUIDs every time.
                if fallback is None and looks_like_hr_name(name):
                    fallback = device

            if fallback is not None:
                log.info(f'Found possible HR device by name: "{fallback.name or fallback.address}" ({fallback.address})')
                return fallback

            log.info("No HR sensor found, retrying …")
        except Exception as e:
            log.warning(f"Scan error: {e}")

        await asyncio.sleep(RECONNECT_DELAY)


async def hr_loop():
    global hr_connected, hr_device_name, latest_bpm, latest_battery

    while True:
        device = await find_hr_device()
        hr_device_name = device.name or device.address
        latest_bpm = None
        latest_battery = None

        await broadcast_status("connecting", hr_device_name)

        def on_hr_notify(_sender, data: bytearray):
            global latest_bpm
            bpm = parse_heart_rate_measurement(data)
            if bpm is None:
                return
            latest_bpm = bpm
            payload = {
                "type": "heart_rate",
                "bpm": bpm,
                "deviceName": hr_device_name,
            }
            # Notification callbacks are sync; schedule async broadcast safely.
            asyncio.get_running_loop().create_task(broadcast(payload))

        try:
            async with BleakClient(device) as client:
                hr_connected = True
                log.info(f'Connected to HR device: "{hr_device_name}"')
                await broadcast_status("connected", hr_device_name)

                services = client.services
                hr_char = services.get_characteristic(HEART_RATE_MEASUREMENT_UUID)
                if hr_char is None:
                    log.warning("Device connected but Heart Rate Measurement 0x2A37 was not found")
                    await broadcast_status("not_heart_rate_device", hr_device_name)
                    await asyncio.sleep(RECONNECT_DELAY)
                    continue

                await client.start_notify(hr_char, on_hr_notify)
                log.info("Subscribed to Heart Rate Measurement — waiting for BPM")
                await broadcast_status("subscribed", hr_device_name)

                while client.is_connected:
                    await asyncio.sleep(1.0)

        except Exception as e:
            log.warning(f"HR BLE error: {e}")
        finally:
            hr_connected = False
            log.info("Disconnected from HR device")
            await broadcast_status("disconnected", None)
            latest_bpm = None

        log.info(f"Reconnecting in {RECONNECT_DELAY:.0f} s …")
        await asyncio.sleep(RECONNECT_DELAY)


async def ws_handler(websocket):
    ws_clients.add(websocket)
    addr = websocket.remote_address
    log.info(f"[WS] Client connected: {addr}")

    try:
        await websocket.send(json.dumps({
            "type": "status",
            "status": "connected" if hr_connected else "scanning",
            "deviceName": hr_device_name if hr_connected else None,
        }))

        if latest_bpm is not None:
            await websocket.send(json.dumps({
                "type": "heart_rate",
                "bpm": latest_bpm,
                "deviceName": hr_device_name,
            }))

        # This server is mostly broadcast-only, but keep the socket open and
        # accept simple commands for future extension/debugging.
        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue

            if msg.get("cmd") == "ping":
                await websocket.send(json.dumps({"type": "pong"}))

    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        ws_clients.discard(websocket)
        log.info(f"[WS] Client disconnected: {addr}")


async def main():
    log.info(f"Heart Rate WebSocket listening on ws://0.0.0.0:{WS_PORT}")
    async with websockets.serve(ws_handler, "0.0.0.0", WS_PORT):
        await hr_loop()


if __name__ == "__main__":
    asyncio.run(main())
