#!/usr/bin/env python3
"""CORZ station updater. Python standard library only; no hard-coded account.

Install targets are always relative to this station, never supplied home paths.
Use --check, --apply package.zip, or run without arguments for the status service.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import io
import json
import os
import re
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import urljoin, urlsplit

STATION = Path(os.environ.get('CORZ_STATION_DIR', str(Path(__file__).resolve().parent.parent))).resolve()
STATE = STATION / '.updates'
CONFIG = STATION / 'updater.json'
DEFAULT_URL = 'https://raw.githubusercontent.com/ShamaiInsight/CorzstationPackages/main/update.json'
VERSION_FILE = STATION / '.corz_version'
MANIFEST_CACHE = STATION / 'corz-manifest.json'
MAX_DOWNLOAD = 512 * 1024 * 1024
MAX_EXPANDED = 2 * 1024 * 1024 * 1024
MAX_ENTRIES = 30000
MAX_MEMBER = 128 * 1024 * 1024
SERVICES = {
    'app/ourcorz_bridge.py': 'ourcorz-bridge.service',
    'runtime/bleserver.py': 'corz-ble.service',
    'runtime/hrserver.py': 'corz-hr.service',
    'runtime/wifi-api.py': 'corz-wifi.service',
    'runtime/updater.py': 'corz-updater.service',
}
ALLOWED_SERVICES = set(SERVICES.values())
_state = dict(status='BOOT', message='Initializing system…', progress=0,
              version='LOCAL', error='', warning='', install_base=str(STATION))
_lock = threading.Lock()
_procs = {}


def set_state(status, message, *, progress=None, version=None, error=None, warning=None):
    with _lock:
        _state.update(status=status, message=message)
        for key, value in dict(progress=progress, version=version, error=error, warning=warning).items():
            if value is not None:
                _state[key] = value
    print(f'[corz-updater] [{status}] {message}', flush=True)


def get_state():
    with _lock:
        return dict(_state)


def settings():
    result = {'manifest_url': DEFAULT_URL, 'port': 8081}
    if CONFIG.exists():
        value = json.loads(CONFIG.read_text())
        if not isinstance(value, dict):
            raise ValueError('updater.json must be a JSON object')
        result.update(value)
    return result


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def durable_unlink(path):
    path.unlink(missing_ok=True)
    if path.parent.exists():
        sync_dir(path.parent)


def atomic_write(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.corz-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
            os.fchmod(stream.fileno(), mode)
        os.replace(name, path)
        for parent in path.parents:
            sync_dir(parent)
            if parent == STATION:
                break
    finally:
        if os.path.exists(name):
            os.unlink(name)


def relative(value):
    if not isinstance(value, str) or not value or '\\' in value or '\x00' in value:
        raise ValueError(f'Invalid relative path: {value!r}')
    path = PurePosixPath(value)
    if path.is_absolute() or any(p in ('', '.', '..') for p in value.split('/')):
        raise ValueError(f'Paths must be station-relative (no /home paths): {value}')
    return path.as_posix()


def destination(value):
    name = relative(value)
    parts = PurePosixPath(name).parts
    # Local configuration, environments, data and updater state never come from a release.
    if any(p.startswith('.') or p.lower() in ('venv', '__pycache__', 'node_modules',
            'data', 'logs', 'backups') for p in parts):
        raise ValueError(f'Protected local path: {name}')
    if parts[0] not in ('app', 'runtime', 'kiosk.sh') or (parts[0] == 'kiosk.sh' and len(parts) != 1):
        raise ValueError(f'Target must be app/, runtime/, or kiosk.sh: {name}')
    if Path(name).suffix.lower() in ('.db', '.sqlite', '.sqlite3', '.log'):
        raise ValueError(f'Protected local data file: {name}')
    if name == 'app/requirements.txt':
        raise ValueError('Dependency changes require maintenance; requirements.txt is not an OTA target')
    out = STATION / name
    # Check ancestors individually: even an inward-pointing symlink is not an update target.
    for item in (out, *out.parents):
        if item == STATION.parent:
            break
        if item.is_symlink():
            raise ValueError(f'Symlink target refused: {name}')
    if out.exists() and not out.is_file():
        raise ValueError(f'Target is not a regular file: {name}')
    if not out.resolve().is_relative_to(STATION):
        raise ValueError(f'Target escapes station: {name}')
    return out


def archive_index(zf):
    entries = {}
    total = 0
    for info in zf.infolist():
        name = info.filename.rstrip('/')
        relative(name)
        if stat.S_ISLNK(info.external_attr >> 16):
            raise ValueError(f'Archive symlink refused: {name}')
        if info.is_dir():
            continue
        if name in entries:
            raise ValueError(f'Duplicate archive entry: {name}')
        entries[name] = info
        total += info.file_size
        if info.file_size > MAX_MEMBER:
            raise ValueError('Single ZIP member exceeds 128 MiB memory limit')
    if total > MAX_EXPANDED or len(entries) > MAX_ENTRIES:
        raise ValueError('Archive exceeds safety limits')
    return entries


def manifest_in(zf, entries):
    candidates = [n for n in entries if n == 'manifest.json' or n.endswith('/manifest.json')]
    if 'manifest.json' in entries:
        key = 'manifest.json'
    elif len(candidates) == 1:
        key = candidates[0]
    else:
        raise ValueError('Package must contain one unambiguous manifest.json')
    if entries[key].file_size > 1024 * 1024:
        raise ValueError('manifest.json too large')
    value = json.loads(zf.read(key))
    return value, key[:-len('manifest.json')]


def version_of(manifest):
    version = manifest.get('version') if isinstance(manifest, dict) else None
    if not isinstance(version, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._+-]{0,99}', version):
        raise ValueError('A nonempty version string is required')
    return version


def current_version():
    return VERSION_FILE.read_text().strip() if VERSION_FILE.exists() else 'NONE'


def check_url(url):
    parsed = urlsplit(url)
    # HTTP is deliberately restricted to local test servers.
    if parsed.username or parsed.password or not parsed.hostname:
        raise ValueError('Invalid update URL')
    if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in ('127.0.0.1', 'localhost', '::1')):
        raise ValueError('Remote update sources must use HTTPS')
    return url


def read_url(url, limit):
    req = urllib.request.Request(check_url(url), headers={'User-Agent': 'CORZ-Updater/2.0', 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=30) as response:
        check_url(response.geturl())
        body = response.read(limit + 1)
    if len(body) > limit:
        raise ValueError('Download exceeds limit')
    return body


def remote_release(url):
    release = json.loads(read_url(url, 1024 * 1024))
    version_of(release)
    if not re.fullmatch(r'[0-9a-fA-F]{64}', str(release.get('sha256', ''))):
        raise ValueError('update.json needs the SHA-256 of package.zip')
    if not isinstance(release.get('package_url'), str):
        raise ValueError('update.json needs package_url')
    release['package_url'] = check_url(urljoin(url, release['package_url']))
    return release


def download(release, output):
    sha = hashlib.sha256()
    size = 0
    req = urllib.request.Request(release['package_url'], headers={'User-Agent': 'CORZ-Updater/2.0'})
    with urllib.request.urlopen(req, timeout=60) as response, output.open('wb') as stream:
        check_url(response.geturl())
        while chunk := response.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_DOWNLOAD:
                raise ValueError('Package exceeds 512 MiB download limit')
            stream.write(chunk)
            sha.update(chunk)
    if sha.hexdigest() != release['sha256'].lower():
        raise ValueError('SHA-256 mismatch: package was not installed')
    if 'size' in release and release['size'] != size:
        raise ValueError('Package size mismatch')


def prepare(package, staging, expected_version=None):
    """Fully validate and stage before changing live files. No shell hooks."""
    staged = {}
    removed = []
    expanded = 0

    def add(name, data, mode=0o644):
        nonlocal expanded
        destination(name)
        if name in staged or name in removed:
            raise ValueError(f'Duplicate target: {name}')
        if mode not in (0o644, 0o755):
            raise ValueError('Only 0644 and 0755 file modes are allowed')
        expanded += len(data)
        if expanded > MAX_EXPANDED or len(staged) >= MAX_ENTRIES:
            raise ValueError('Expanded release exceeds safety limits')
        if name.endswith('.py'):
            compile(data, name, 'exec')
        out = staging / name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        out.chmod(mode)
        staged[name] = mode

    with zipfile.ZipFile(package) as outer:
        index = archive_index(outer)
        manifest, prefix = manifest_in(outer, index)
        version = version_of(manifest)
        if expected_version is not None and version != expected_version:
            raise ValueError('update.json and manifest.json versions disagree')
        if manifest.get('schema') != 2 or 'install_base' in manifest:
            raise ValueError('Use schema 2 and station-relative destinations; remove install_base')
        for field in ('files', 'bundles', 'delete', 'restart_services', 'servers'):
            if not isinstance(manifest.get(field, []), list):
                raise ValueError(f'{field} must be a list')
        for entry in manifest.get('files', []):
            source = prefix + relative(entry['src'])
            if source not in index:
                raise ValueError(f'Required source missing: {source}')
            mode = int(str(entry.get('mode', '0644')), 8)
            add(relative(entry.get('dest', entry['src'])), outer.read(source), mode)
        for entry in manifest.get('bundles', []):
            if entry.get('replace') or entry.get('type') == 'unity-webgl':
                raise ValueError('Use an ordinary complete game ZIP; no replace/scaffold operation')
            dest = relative(entry['dest'])
            source = prefix + relative(entry['src'])
            if source not in index:
                raise ValueError(f'Required bundle missing: {source}')
            # Normal bundle layout is preserved; strip_prefix must be explicit.
            strip = entry.get('strip_prefix', '')
            if strip:
                strip = relative(strip.rstrip('/')) + '/'
            with zipfile.ZipFile(io.BytesIO(outer.read(source))) as inner:
                for name in archive_index(inner):
                    if strip and not name.startswith(strip):
                        raise ValueError(f'Bundle member outside strip_prefix: {name}')
                    rel = name[len(strip):] if strip else name
                    add(dest + '/' + relative(rel), inner.read(name))
        for name in manifest.get('delete', []):
            name = relative(name)
            destination(name)
            if name in staged or name in removed:
                raise ValueError(f'Duplicate target: {name}')
            if name in SERVICES or name == 'runtime/splash.html':
                raise ValueError(f'Cannot delete a core server: {name}')
            removed.append(name)
        if not staged and not removed:
            raise ValueError('Empty release')
        # A file may not also be an ancestor of a target.
        targets = set(staged) | set(removed)
        for name in targets:
            if any(p.as_posix() in targets for p in PurePosixPath(name).parents):
                raise ValueError(f'Overlapping targets: {name}')
        for unit in manifest.get('restart_services', []):
            if unit not in ALLOWED_SERVICES:
                raise ValueError(f'Service not allowed: {unit}')
        for srv in manifest.get('servers', []):
            path = relative(srv['path'])
            if not path.startswith('app/www/'):
                raise ValueError('Game server paths must be under app/www/')
            destination(path + '/index.html')
            if srv.get('type', 'webgl') != 'webgl' or not 1024 <= int(srv['port']) <= 65535:
                raise ValueError('Invalid game server type/port')
    return manifest, staged, removed


def run_service(unit, self_restart=False):
    if unit not in ALLOWED_SERVICES:
        raise ValueError(f'Service not allowed: {unit}')
    command = ['/usr/bin/sudo', '-n', '/usr/bin/systemctl']
    if self_restart:
        command.append('--no-block')
    command.extend(['restart', unit])
    subprocess.run(command, check=True, timeout=40, capture_output=True, text=True)
    if not self_restart:
        time.sleep(1)
        subprocess.run(['/usr/bin/systemctl', 'is-active', '--quiet', unit],
                       check=True, timeout=10, capture_output=True, text=True)


def affected_services(names, manifest):
    units = set(manifest.get('restart_services', []))
    for name in names:
        if name in SERVICES:
            units.add(SERVICES[name])
        # New/updated Python helpers in the app may be imported by the bridge.
        if name.startswith('app/') and name.endswith('.py'):
            units.add('ourcorz-bridge.service')
    return sorted(units)


def restore(journal):
    backup = STATE / 'backups' / journal['backup']
    for entry in reversed(journal['entries']):
        dst = destination(entry['name'])
        if entry['existed']:
            src = backup / entry['name']
            atomic_write(dst, src.read_bytes(), entry['mode'])
        else:
            durable_unlink(dst)
    for name in ('.corz_version', 'corz-manifest.json'):
        old = backup / name
        if old.exists():
            atomic_write(STATION / name, old.read_bytes())
        else:
            durable_unlink(STATION / name)


def recover():
    path = STATE / 'pending.json'
    if path.exists():
        journal = json.loads(path.read_text())
        set_state('RECOVERING', 'Restoring files after an interrupted update…')
        restore(journal)
        # Recovery runs at boot/service start; ensure already-running processes reload restored code.
        for unit in journal.get('services', []):
            if unit != 'corz-updater.service':
                run_service(unit)
        durable_unlink(path)
        if 'corz-updater.service' in journal.get('services', []):
            # Direct CLI recovery (the service's stable launcher normally handles this).
            os.execv(sys.executable, [sys.executable, str(STATION / 'runtime/updater.py'), *sys.argv[1:]])


def install_package(package, *, expected_version=None, restart=True):
    STATE.mkdir(parents=True, exist_ok=True)
    if (STATE / 'pending.json').exists():
        raise RuntimeError('Unfinished transaction: restart the updater to recover first')
    with tempfile.TemporaryDirectory(prefix='stage-', dir=STATE) as folder:
        staging = Path(folder)
        manifest, staged, removed = prepare(package, staging, expected_version)
        version = version_of(manifest)
        if version == current_version():
            return version, False
        changed = [n for n, mode in staged.items() if not (STATION / n).exists()
                   or (STATION / n).read_bytes() != (staging / n).read_bytes()
                   or stat.S_IMODE((STATION / n).stat().st_mode) != mode]
        changed += [n for n in removed if (STATION / n).exists()]
        needed = sum((STATION / n).stat().st_size for n in changed if (STATION / n).exists())
        needed += max(((staging / n).stat().st_size for n in staged), default=0) + 16 * 1024 * 1024
        if shutil.disk_usage(STATE).free < needed:
            raise OSError('Not enough free space for backups and atomic file replacement')
        units = affected_services(changed, manifest)
        stamp = time.strftime('%Y%m%d-%H%M%S') + '-' + str(time.time_ns())
        backup = STATE / 'backups' / stamp
        backup.mkdir(parents=True)
        journal = {'backup': stamp, 'version': version, 'entries': [], 'services': units}
        for name in changed:
            dst = destination(name)
            existed = dst.exists()
            mode = stat.S_IMODE(dst.stat().st_mode) if existed else 0o644
            journal['entries'].append({'name': name, 'existed': existed, 'mode': mode})
            if existed:
                target = backup / name
                target.parent.mkdir(parents=True, exist_ok=True)
                atomic_write(target, dst.read_bytes(), mode)
        for path in (VERSION_FILE, MANIFEST_CACHE):
            if path.exists():
                atomic_write(backup / path.name, path.read_bytes())
        atomic_write(backup / 'transaction.json', json.dumps(journal, indent=2).encode())
        # Persist backup-directory links before making the recovery journal visible.
        for directory in sorted((p for p in backup.rglob('*') if p.is_dir()),
                                key=lambda p: len(p.parts), reverse=True):
            sync_dir(directory)
        for directory in (backup, backup.parent, STATE, STATION):
            sync_dir(directory)
        pending = STATE / 'pending.json'
        atomic_write(pending, json.dumps(journal).encode())
        try:
            for i, name in enumerate(changed):
                dst = destination(name)
                if name in staged:
                    atomic_write(dst, (staging / name).read_bytes(), staged[name])
                else:
                    durable_unlink(dst)
                set_state('INSTALLING', f'Installing {name}', progress=30 + int(55 * (i + 1) / max(len(changed), 1)))
            if restart:
                for unit in units:
                    if unit != 'corz-updater.service':
                        set_state('STARTING', f'Restarting {unit}…', progress=90)
                        run_service(unit)
            atomic_write(MANIFEST_CACHE, json.dumps(manifest, indent=2).encode())
            atomic_write(VERSION_FILE, version.encode())
        except Exception as exc:
            restore(journal)
            failures = []
            if restart:
                for unit in units:
                    if unit != 'corz-updater.service':
                        try:
                            run_service(unit)
                        except Exception:
                            failures.append(unit)
            if not failures:
                durable_unlink(pending)
            detail = f'; could not restart restored services: {failures}' if failures else ''
            raise RuntimeError(f'Update failed; previous files restored: {exc}{detail}') from exc
        self_restart = restart and 'corz-updater.service' in units
        if self_restart:
            # The non-updated launcher restores this backup if the new updater
            # cannot reach READY on its trial startup.
            atomic_write(STATE / 'trial.json', json.dumps(journal).encode())
        durable_unlink(pending)
        if self_restart:
            # Commit first. The restarted updater sees this version and does not loop.
            try:
                run_service('corz-updater.service', self_restart=True)
            except Exception as exc:
                durable_unlink(STATE / 'trial.json')
                set_state('STARTING', 'Files installed; restart corz-updater manually.',
                          warning=f'Updater self-restart failed: {exc}')
                self_restart = False
        return version, self_restart


def local_manifest():
    try:
        return json.loads(MANIFEST_CACHE.read_text())
    except (OSError, ValueError):
        return {}


def start_game_servers(manifest):
    for srv in manifest.get('servers', []):
        path = STATION / relative(srv['path'])
        port = int(srv['port'])
        if not path.resolve().is_relative_to(STATION / 'app' / 'www') or not path.is_dir():
            continue
        with socket.socket() as sock:
            sock.settimeout(0.3)
            if sock.connect_ex(('127.0.0.1', port)) == 0:
                continue
        _procs[port] = subprocess.Popen([sys.executable, '-m', 'http.server', str(port),
            '--bind', '127.0.0.1', '--directory', str(path)], stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL)


def update_worker():
    try:
        recover()
        current = current_version()
        config = settings()
        if (STATE / 'trial.json').exists():
            start_game_servers(local_manifest())
            set_state('READY', 'Updater self-update confirmed.', progress=100, version=current)
            durable_unlink(STATE / 'trial.json')
            return
        if os.environ.get('CORZ_SKIP_UPDATE_ONCE') == '1':
            set_state('NO_UPDATE', 'Recovered previous release; skipping update check this start.',
                      version=current, progress=95, warning='A failed updater self-update was rolled back.')
        elif not config['manifest_url']:
            set_state('NO_UPDATE', 'Update checks disabled.', version=current, progress=95)
        else:
            set_state('CHECKING', 'Checking update.json…', version=current, progress=5)
            release = remote_release(config['manifest_url'])
            if release['version'] == current:
                set_state('NO_UPDATE', 'Already up to date.', progress=95)
            else:
                with tempfile.TemporaryDirectory(prefix='download-', dir=STATE) as folder:
                    package = Path(folder) / 'package.zip'
                    set_state('DOWNLOADING', 'Downloading and verifying package.zip…', progress=10)
                    download(release, package)
                    version, restarting = install_package(package, expected_version=release['version'])
                    set_state('STARTING', f'Installed {version}', version=version, progress=95)
                    if restarting:
                        return
        start_game_servers(local_manifest())
        set_state('READY', 'System ready.', progress=100, version=current_version())
    except Exception as exc:
        # Keep local station usable offline but retain the actual error for diagnostics.
        print(f'[corz-updater] ERROR: {exc}', file=sys.stderr, flush=True)
        if (STATE / 'pending.json').exists():
            set_state('ERROR', 'Recovery required; inspect updater logs.', progress=100, error=str(exc))
            return
        try:
            start_game_servers(local_manifest())
        except Exception:
            pass
        set_state('READY', 'Using local files; update unavailable or failed.',
                  progress=100, version=current_version(), error=str(exc), warning='Update not installed. See error.')


class ApiHandler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def do_GET(self):
        if self.path.rstrip('/') != '/api/status':
            self.send_error(404)
            return
        body = json.dumps(get_state()).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Check update.json without installing')
    parser.add_argument('--apply', type=Path, help='Apply a local package (stops if same version)')
    parser.add_argument('--no-restart', action='store_true', help='Local test only: do not restart services')
    args = parser.parse_args()
    STATION.mkdir(parents=True, exist_ok=True)
    STATE.mkdir(parents=True, exist_ok=True)
    with (STATE / 'lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.exit(2, 'Another updater is running. Stop corz-updater before using --apply/--check.\n')
        if args.check:
            config = settings()
            if not config['manifest_url']:
                print('Update checks disabled')
                return
            release = remote_release(config['manifest_url'])
            print(json.dumps(dict(current=current_version(), available=release['version'],
                                 update_available=current_version() != release['version']), indent=2))
            return
        if args.apply:
            recover()
            version, _ = install_package(args.apply, restart=not args.no_restart)
            print('Installed version:', version)
            return
        config = settings()
        server = ThreadingHTTPServer(('127.0.0.1', int(config['port'])), ApiHandler)

        def shutdown(*_):
            for proc in _procs.values():
                proc.terminate()
            # serve_forever must be shut down from another thread.
            threading.Thread(target=server.shutdown, daemon=True).start()

        signal.signal(signal.SIGTERM, shutdown)
        signal.signal(signal.SIGINT, shutdown)
        threading.Thread(target=update_worker, daemon=True).start()
        print(f'[corz-updater] Install base: {STATION}', flush=True)
        try:
            server.serve_forever()
        finally:
            server.server_close()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'[corz-updater] {exc}', file=sys.stderr)
        sys.exit(1)
