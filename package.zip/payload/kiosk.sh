#!/bin/bash
set -u
# Started by the actual desktop session so Wayland/D-Bus variables are correct.
exec 9>"${XDG_RUNTIME_DIR:?Desktop session required}/corz-kiosk.lock"
flock -n 9 || exit 0
browser=$(command -v chromium || command -v chromium-browser) || exit 1
until curl -fsS --max-time 3 http://localhost:7890/splash.html >/dev/null; do
  sleep 2
done
while true; do
  "$browser" --kiosk --password-store=basic --no-first-run --noerrdialogs \
    --autoplay-policy=no-user-gesture-required \
    --user-data-dir="$HOME/.config/corz-chromium" \
    http://localhost:7890/splash.html
  sleep 3
done
