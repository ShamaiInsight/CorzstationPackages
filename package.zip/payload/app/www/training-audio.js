/* Shared training cues. No queued countdowns: paused/abandoned timers stay silent. */
(() => {
  'use strict';
  let context;
  const timers = new Map();
  const enabled = () => !document.hidden;
  function unlock() {
    try {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) return;
      context ||= new Audio();
      if (context.state === 'suspended') context.resume().catch(() => {});
    } catch {}
  }
  function tone(frequency, duration, delay = 0) {
    if (!enabled()) return;
    unlock();
    if (!context || context.state !== 'running') return;
    try {
      const time = context.currentTime + delay;
      const oscillator = context.createOscillator(), gain = context.createGain();
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0, time);
      gain.gain.linearRampToValueAtTime(.12, time + .012);
      gain.gain.setValueAtTime(.12, time + duration - .04);
      gain.gain.linearRampToValueAtTime(0, time + duration);
      oscillator.connect(gain); gain.connect(context.destination);
      oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
      oscillator.start(time); oscillator.stop(time + duration);
    } catch {}
  }
  function cue(kind, allowed = true) {
    if (!allowed) return;
    if (kind === 'start') tone(1046, .38);
    else if (kind === 'end') { tone(784, .24); tone(523, .42, .28); }
    else tone(740, .14);
  }
  function tick(key, remaining, allowed = true) {
    const seconds = Math.max(0, Math.ceil(remaining - 1e-8));
    if (timers.get(key) === seconds) return;
    timers.set(key, seconds);
    if (seconds >= 1 && seconds <= 3) cue('tick', allowed);
  }
  function reset(key) { if (key === undefined) timers.clear(); else timers.delete(key); }
  for (const event of ['keydown', 'pointerdown', 'touchstart'])
    window.addEventListener(event, unlock, {passive: true});
  window.CorzTrainingAudio = {cue, tick, reset};
})();
