/* Station inactivity: sleep only after the BLE service confirms disconnection. */
(() => {
  'use strict';
  let settings={minutes:5,type:'orbit'}, lastActivity=performance.now(), phase='awake';
  let send=null, request=0, waiting=null, deadline=0, sample=null, blockedKey=false;
  let nfcSequence=null,suppressClickUntil=0;
  const panel=document.createElement('section');
  panel.id='corzScreensaver';panel.hidden=true;panel.setAttribute('role','status');
  panel.innerHTML='<div class="saver-art" aria-hidden="true"><i></i><i></i><i></i></div><div class="saver-content"><div class="saver-brand">CORZ<span>STATION</span></div><h1 id="saverTitle"></h1><p id="saverMessage"></p><div class="saver-clock"></div></div>';
  document.body.append(panel);
  const title=panel.querySelector('h1'), message=panel.querySelector('p');
  function show(state,text,detail){phase=state;panel.hidden=false;panel.dataset.phase=state;panel.dataset.type=settings.type;title.textContent=text;message.textContent=detail;}
  function reset(){lastActivity=performance.now();}
  function dismiss(){waiting=null;deadline=0;phase='awake';panel.hidden=true;suppressClickUntil=performance.now()+500;reset();try{window.focus();}catch{}}
  function activity(){if(phase==='awake')reset();}
  // Called by the early kiosk guard in parent and game documents. The wake
  // press and its key repeat/release are consumed, never activating a menu.
  function input(e){
    if(e.type==='click')return performance.now()<suppressClickUntil;
    if(blockedKey){if(e.type==='keyup')blockedKey=false;return true;}
    if(phase!=='awake'){
      if(e.type==='keydown'||e.type==='pointerdown'||e.type==='mousedown'){
        blockedKey=e.type==='keydown';dismiss();return true;
      }
      return true;
    }
    if(e.type==='keydown'||e.type==='pointerdown'||e.type==='mousedown'||e.type==='touchstart')activity();
    return false;
  }
  function fail(detail){waiting=null;deadline=0;show('error','Screen saver could not start',detail+' Press a button to return.');}
  function start(){
    if(phase!=='awake'||!settings.minutes)return;
    request++;waiting='saver-'+request;deadline=performance.now()+14000;
    show('preparing','Putting the Cradle to sleep…','Sending shutdown command. Waiting for disconnection. Press a button to cancel.');
    window.CorzStation?.lockForIdle();
    // Pause without unloading: unfinished scores and upload state stay intact.
    try{document.getElementById('gameFrame')?.contentWindow?.postMessage({type:'CORZ_STATION_IDLE'},location.origin);}catch{}
    if(!send?.({cmd:'sleepDevice',requestId:waiting}))fail('The Bluetooth service is unavailable. Device shutdown could not be confirmed.');
  }
  function receive(d){
    if(d.type==='data'&&Number.isFinite(d.roll)&&Number.isFinite(d.pitch)){
      if(!sample){sample={roll:d.roll,pitch:d.pitch};return;}
      const delta=(a,b)=>Math.abs(((a-b+540)%360)-180);
      if(delta(d.roll,sample.roll)>.75||delta(d.pitch,sample.pitch)>.75){sample={roll:d.roll,pitch:d.pitch};activity();}
    }
    if(d.type==='status'&&d.status!=='connected')sample=null;
    if(d.type!=='sleepResult'||phase!=='preparing'||d.requestId!==waiting)return;
    if(d.ok===true){waiting=null;deadline=0;show('sleeping','READY WHEN YOU ARE','Press any remote button or scan your NFC tag to wake the screen.');}
    else fail(d.message||'The Cradle did not confirm disconnection.');
  }
  function check(){
    panel.querySelector('.saver-clock').textContent=new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
    if(phase==='preparing'&&performance.now()>=deadline)fail('No disconnection acknowledgement was received.');
    if(phase==='awake'&&settings.minutes&&performance.now()-lastActivity>=settings.minutes*60000&&!window.CorzPowerUi?.isOpen())start();
  }
  function capture(e){if(input(e)){e.preventDefault();e.stopImmediatePropagation();}}
  for(const type of ['keydown','keyup','pointerdown','mousedown','touchstart','click'])window.addEventListener(type,capture,true);
  // Pointer movement counts only while awake, and cannot wake the display.
  window.addEventListener('pointermove',activity,{passive:true});
  const frame=document.getElementById('gameFrame');
  frame?.addEventListener('load',()=>{try{const w=frame.contentWindow;for(const type of ['keydown','keyup','pointerdown','touchstart','click'])w.addEventListener(type,capture,true);w.addEventListener('pointermove',activity,{passive:true});}catch{}});
  window.CorzScreensaver={
    configure(value,sender){settings={...value};send=sender;reset();},receive,input,activity,
    nfc(sequence){if(sequence==null)return;if(nfcSequence!==null&&sequence!==nfcSequence){if(phase==='awake')activity();else dismiss();}nfcSequence=sequence;},
    get state(){return phase;},get settings(){return {...settings};}
  };
  setInterval(check,250);
})();
