/* CORZ power popup. Optional loopback broker is installed separately on the Pi. */
(() => {
  'use strict';
  const API = 'http://127.0.0.1:8083';
  let root, buttons, message, selected = 2, nonce = null, visible = false;
  let seen = 0, busy = false, savedFocus = null, pending = false, lastKeyAt = -1000;
  const actions = ['shutdown', 'reboot', 'cancel'];
  function paint() {
    buttons.forEach((button, i) => {
      button.classList.toggle('selected', i === selected);
      button.disabled = busy;
    });
  }
  function close() {
    visible = false;
    root.hidden = true;
    if (savedFocus?.isConnected) { try { savedFocus.focus({preventScroll: true}); } catch (_) {} }
  }
  async function choose() {
    if (!nonce || busy) return;
    const action = actions[selected];
    busy = true; paint();
    message.textContent = action === 'cancel' ? 'Closing…' : action === 'shutdown' ? 'Shutting down safely…' : 'Rebooting…';
    try {
      const response = await fetch(API + '/action', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({nonce, action}), signal: AbortSignal.timeout(4000)
      });
      const data = await response.json();
      if (!response.ok) throw Error(data.error || 'Power request failed.');
      nonce = null;
      if (action === 'cancel') { busy = false; close(); }
    } catch (error) {
      busy = false;
      message.textContent = error.message + ' Press HOME/Back to close, then press Power to retry.';
      paint();
    }
  }
  function key(key, repeat = false) {
    if (!visible) return false;
    if (repeat) return true;
    const now = performance.now();
    if (now - lastKeyAt < 180) return true;
    lastKeyAt = now;
    if (['Home','BrowserHome','HomePage','LaunchApplication1','Backspace','Escape','BrowserBack','BrowserPrevious','GoBack'].includes(key)) {
      if (!busy) { selected = 2; nonce ? choose() : close(); }
    } else if (!busy) {
      if (key === 'ArrowLeft' || key === 'ArrowUp') selected = (selected + 2) % 3;
      if (key === 'ArrowRight' || key === 'ArrowDown') selected = (selected + 1) % 3;
      if (key === 'Enter') choose();
      paint();
    }
    return true;
  }
  window.CorzPowerUi = {isOpen: () => visible, key};
  async function poll() {
    if (pending) return;
    pending = true;
    try {
      const response = await fetch(API + '/status', {cache: 'no-store', signal: AbortSignal.timeout(2000)});
      if (!response.ok) return;
      const state = await response.json();
      if (state.sequence !== seen && state.nonce) {
        seen = state.sequence;
        nonce = state.nonce; selected = 2; busy = false;
        if (!visible) savedFocus = document.activeElement;
        visible = true; root.hidden = false;
        if (document.fullscreenElement && document.fullscreenElement !== document.documentElement) {
          document.exitFullscreen().catch(() => {});
        }
        message.textContent = 'Choose an option · OK to confirm · HOME/Back to cancel';
        paint();
        // Parent handlers and the shared iframe guard route keys to this menu.
        // Do not steal focus from games that continuously reclaim it.
      } else if (visible && state.error) {
        busy = false; nonce = null;
        message.textContent = state.error + ' Press HOME/Back to close.';
        paint();
      } else if (visible && !busy && !state.nonce) {
        nonce = null;
        message.textContent = 'Power request expired. Press HOME/Back to close, then Power to retry.';
      }
    } catch (_) {
      // Older installations have no broker; keep their dashboard working.
    } finally { pending = false; }
  }
  function init() {
    root = document.createElement('div');
    root.id = 'corzPowerOverlay'; root.hidden = true;
    root.innerHTML = '<section role="dialog" aria-modal="true" aria-labelledby="corzPowerTitle"><h2 id="corzPowerTitle">CORZ POWER</h2><p id="corzPowerMessage"></p><div class="corz-power-actions"><button type="button">⏻<span>SHUTDOWN</span></button><button type="button">↻<span>REBOOT</span></button><button type="button">✕<span>CANCEL</span></button></div></section>';
    document.body.append(root);
    buttons = [...root.querySelectorAll('button')];
    message = root.querySelector('p');
    buttons.forEach((button, i) => button.addEventListener('click', () => {if (!busy) {selected = i; choose();}}));
    setInterval(poll, 400); poll();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
