/* Capture browser navigation keys in EVERY kiosk document, including focused games. */
(() => {
  'use strict';
  if (window.corzNavigationGuardInstalled) return;
  window.corzNavigationGuardInstalled = true;
  const aliases = new Set(['BrowserHome', 'HomePage', 'LaunchApplication1', 'Home',
    'BrowserBack', 'BrowserPrevious', 'GoBack', 'BrowserForward', 'GoForward']);
  function navigationKey(e) {
    return aliases.has(e.key) || aliases.has(e.code)
      || (e.altKey && ['ArrowLeft', 'ArrowRight', 'Home'].includes(e.key));
  }
  function swallow(e) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }
  function home() {
    if (typeof window.corzRequestHome === 'function') { window.corzRequestHome(); return; }
    if (window.parent !== window) {
      window.parent.postMessage({type: 'CORZ_KIOSK_HOME'}, location.origin === 'null' ? '*' : location.origin);
    } else if (typeof window.sendArcadeInput === 'function') {
      window.sendArcadeInput('Backspace');
    } else {
      // Standalone game pages retain their own Backspace/pause/exit rules.
      document.dispatchEvent(new KeyboardEvent('keydown', {key: 'Backspace', code: 'Backspace', bubbles: true, cancelable: true}));
    }
  }
  function saverInput(e){try{const ui=(window.parent!==window?window.parent:window).CorzScreensaver;if(ui?.input(e)){swallow(e);return true;}}catch{}return false;}
  function powerMenu(e) {
    let ui;
    try { ui = (window.parent !== window ? window.parent : window).CorzPowerUi; } catch (_) {}
    if (!ui?.isOpen()) return false;
    swallow(e);
    if (e.type === 'keydown') ui.key(e.key || e.code, e.repeat);
    return true;
  }
  window.addEventListener('keydown', e => {
    if (saverInput(e) || powerMenu(e)) return;
    if (!navigationKey(e)) return;
    swallow(e);
    if (!e.repeat) home();
  }, true);
  // Some remotes trigger browser actions on release rather than press.
  window.addEventListener('keyup', e => { if (saverInput(e) || powerMenu(e)) return; if (navigationKey(e)) swallow(e); }, true);
  window.addEventListener('mousedown', e => {
    if(saverInput(e))return;
    try {
      const ui = (window.parent !== window ? window.parent : window).CorzPowerUi;
      if (ui?.isOpen() && (e.button === 3 || e.button === 4)) { swallow(e); ui.key('Backspace'); return; }
    } catch (_) {}
    if (e.button !== 3 && e.button !== 4) return;
    swallow(e); home();
  }, true);
  window.addEventListener('mouseup', e => { if (e.button === 3 || e.button === 4) swallow(e); }, true);
})();
