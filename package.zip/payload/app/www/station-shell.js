/* CORZ Station — package-managed UI. Keeps existing game/NFC/API/power services. */
(() => {
  'use strict';
  const KEY='corz_station_config_v1', STYLES=['performance','console','tron','rebel'];
  const EDGE_HOLD_TIMES=[1,1.5,2,2.5,3,4,5,6,8,10];
  let config={style:'performance',games:{}}, storageError='';
  try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))config={...config,...saved,games:saved.games&&typeof saved.games==='object'?saved.games:{}};}catch{storageError='Saved configuration could not be read. Changes will need to be saved again.';}
  if(!STYLES.includes(config.style))config.style='performance';
  config.navigation={edgeHoldSeconds:EDGE_HOLD_TIMES.includes(config.navigation?.edgeHoldSeconds)?config.navigation.edgeHoldSeconds:2};
  const SAVER_TIMES=[0,1,2,5,10,15,30,60],SAVER_TYPES=['orbit','grid'];
  config.screensaver={minutes:SAVER_TIMES.includes(config.screensaver?.minutes)?config.screensaver.minutes:5,type:SAVER_TYPES.includes(config.screensaver?.type)?config.screensaver.type:'orbit'};
  let page='programs',focusIndex=0,items=[],notice=storageError,noticeError=!!storageError,editGame=null,revision=0;
  let staffUnlocked=false,pinMode='unlock',pinEntry='',pinFirst='',pinBusy=false,pinRequest=0,pinFailures=0,pinBlockedUntil=0,pinTarget=null;
  const hasPin=()=>!!config.pin;
  const pinDigits={ArrowUp:'1',ArrowRight:'2',ArrowDown:'3',ArrowLeft:'4'};
  function beginPin(mode,target=null){pinRequest++;pinMode=mode;pinTarget=target;pinEntry='';pinFirst='';pinBusy=false;page='pin-entry';focusIndex=0;notice='';noticeError=false;revision++;render();}
  function cancelPin(){pinRequest++;pinEntry='';pinFirst='';pinBusy=false;const unlock=pinMode==='unlock';pinTarget=null;go(unlock?'home':'pinSettings',0);}
  async function pinHash(sequence,salt){
    if(!globalThis.crypto?.subtle)throw Error('PIN protection needs the local station browser. Open the dashboard on this Pi.');
    const raw=await crypto.subtle.importKey('raw',new TextEncoder().encode(sequence),'PBKDF2',false,['deriveBits']);
    const bytes=Uint8Array.from(salt.match(/../g)||[],x=>parseInt(x,16));
    const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytes,iterations:120000,hash:'SHA-256'},raw,256);
    return [...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,'0')).join('');
  }
  async function submitPin(){
    if(pinBusy)return;
    if(Date.now()<pinBlockedUntil){notice='Too many attempts. Wait a moment before trying again.';noticeError=true;render();return;}
    if(pinEntry.length!==4){notice='Enter four arrow presses, then press OK.';noticeError=true;render();return;}
    if(pinMode==='new'){pinFirst=pinEntry;pinEntry='';pinMode='confirm';notice='Repeat the same arrow sequence, then press OK.';noticeError=false;render();return;}
    if(pinMode==='confirm'&&pinEntry!==pinFirst){pinEntry='';pinFirst='';pinMode='new';notice='The sequences did not match. Create your PIN again.';noticeError=true;render();return;}
    const token=++pinRequest,sequence=pinEntry,mode=pinMode;pinBusy=true;notice='Checking…';noticeError=false;render();
    try{
      if(mode==='confirm'){
        const salt=[...crypto.getRandomValues(new Uint8Array(16))].map(x=>x.toString(16).padStart(2,'0')).join('');
        const hash=await pinHash(sequence,salt);if(token!==pinRequest)return;
        const old=config.pin;config.pin={salt,hash};
        if(!save()){if(old===undefined)delete config.pin;else config.pin=old;pinBusy=false;render();return;}
        pinEntry='';pinFirst='';pinBusy=false;staffUnlocked=false;go('home',0);notice='PIN saved. Configuration is now locked.';render();return;
      }
      const valid=typeof config.pin?.salt==='string'&&typeof config.pin?.hash==='string'&&await pinHash(sequence,config.pin.salt)===config.pin.hash;
      if(token!==pinRequest)return;
      pinBusy=false;pinEntry='';
      if(!valid){pinFailures++;if(pinFailures>=5){pinBlockedUntil=Date.now()+30000;pinFailures=0;}notice='Incorrect PIN. Try again.';noticeError=true;render();return;}
      pinFailures=0;pinBlockedUntil=0;
      if(mode==='remove'){
        const old=config.pin;delete config.pin;if(!save()){config.pin=old;render();return;}
        go('pinSettings');notice='PIN removed. Configuration is no longer protected.';render();return;
      }
      staffUnlocked=true;const target=pinTarget;pinTarget=null;if(target)target();else go('config');
    }catch(e){if(token!==pinRequest)return;pinBusy=false;pinEntry='';notice=e.message||'PIN could not be checked.';noticeError=true;render();}
  }
  let bridgeStatus=null,release=null,updater=null,bleSocket=null,bleTimer=null,bleOnline=false,bleState='unavailable',bleName='',selectedName='',selectedAddress=null,devices=[],scanning=false,scanTimer=null,bleError='',requestId=0;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let cradleRotation=0,rotationPending=false,previewSample=null,previewCentre=null,previewTime=0;
  let neutralMeasurement=null;
  function rotationView(){return '<section class="cradle-preview" aria-label="Live Cradle movement preview"><div class="cradle-preview-board"><span class="cradle-preview-up">FORWARD / UP</span><span id="cradlePreviewDot"></span></div><div><strong>Movement preview · '+cradleRotation+'°</strong><p id="cradlePreviewStatus" role="status">Connect a Cradle, then tilt it to check direction.</p><p>Use Rotate +90° until movement matches the screen. Optional neutral calibration is shared by all games on this Pi; sensitivities stay unchanged.</p></div></section>';}
  function updatePreview(){const dot=$('cradlePreviewDot'),status=$('cradlePreviewStatus');if(!dot||!status)return;const live=bleOnline&&bleState==='connected'&&previewSample&&performance.now()-previewTime<600;dot.style.opacity=live?'1':'.25';if(!live){status.textContent='No live movement data. Select and connect a Cradle.';return;}const neutral=CorzCalibration.get(),delta=CorzCalibration.delta;const x=Math.max(-1,Math.min(1,delta(previewSample.roll,neutral.roll)/20)),y=Math.max(-1,Math.min(1,-delta(previewSample.pitch,neutral.pitch)/20));dot.style.left=(50+x*40)+'%';dot.style.top=(50+y*40)+'%';status.textContent=neutralMeasurement?'Measuring neutral · leave the Cradle sensor alone · '+Math.max(0,5-(performance.now()-neutralMeasurement.start)/1000).toFixed(1)+'s':'Live · '+cradleRotation+'° · saved neutral shared with all games.';}
  function cancelNeutral(reason='Calibration cancelled. Previous neutral and all sensitivities are unchanged.') {neutralMeasurement=null;notice=reason;noticeError=true;if(page==='controller')render();}
  function startNeutral() {
    if(neutralMeasurement){cancelNeutral();return;}
    if(!bleOnline||bleState!=='connected'||!previewSample||performance.now()-previewTime>=600){cancelNeutral('Connect a Cradle and wait for fresh readings before calibrating.');return;}
    neutralMeasurement={start:performance.now(),revision:CorzCalibration.revision,samples:[]};
    notice='Measuring for five seconds: leave the Cradle sensor alone, empty, untouched and still. No positioning countdown follows.';noticeError=false;render();
  }
  function sampleNeutral() {
    if(!neutralMeasurement)return;
    if(page!=='controller'||document.hidden||!bleOnline||bleState!=='connected'){cancelNeutral();return;}
    const c=neutralMeasurement;c.samples.push({...previewSample,t:previewTime});
    if(previewTime-c.start<5000)return;
    try {CorzCalibration.save(c.samples,c.revision);neutralMeasurement=null;notice='Neutral calibrated and saved on this Pi for all games. Sensitivities are unchanged. Ready to play.';noticeError=false;render();}
    catch(e){cancelNeutral('Calibration not saved: '+e.message);}
  }
  function rotateCradle(){if(rotationPending||!bleOnline)return;rotationPending=true;if(!sendBle({cmd:'setOrientation',rotation:(cradleRotation+90)%360})){rotationPending=false;notice='Could not reach the sensor service.';noticeError=true;}render();}
  const title=s=>s.charAt(0).toUpperCase()+s.slice(1);
  const defs={
    plankz:{name:'PLANKZ',fields:[['difficulty','Default difficulty',['easy','medium','hard'],'easy','Players can change this before starting.'],['theme','Game theme',STYLES,'performance','Appearance only; balance scoring is unchanged.']]},
    beepz:{name:'BEEPZ',fields:[['cycles','Cycles',Array.from({length:20},(_,i)=>i+1),3],['reps','Repetitions',Array.from({length:50},(_,i)=>i+1),4],['breakSeconds','Rest between cycles (seconds)',Array.from({length:61},(_,i)=>i*5),30],['hold','Target hold (seconds)',[5,10,15],5],['theme','Game theme',STYLES,'performance']]},
    tenz:{name:'TENZ',fields:[['range','Sensor range (degrees)',Array.from({length:43},(_,i)=>i+3),12],['theme','Game theme',STYLES,'performance']]},
    timez:{name:'Workout TimeZ',fields:[['work','Work duration (seconds)',[30,60,90,120,150,180],90],['rest','Rest duration (seconds)',[5,10,15,20,25,30,60],10],['rounds','Rounds',[3,6,9,12,18,21,24],12],['theme','Game theme',STYLES,'performance']]}
  };
  const rangeOptions=Array.from({length:43},(_,i)=>i+3);
  const rangeHelp='Tilt sensitivity, not Bluetooth distance. Lower = smaller movements; higher = more tilt. Independent for this game. Applies after reopening the game.';
  for(const [id,d] of Object.entries(defs)){
    d.fields=d.fields.filter(f=>f[0]!=='range');
    const help=rangeHelp+(id==='timez'?' Controls only the Cradle navigation cursor; workout times are unchanged.':'');
    d.fields.splice(id==='plankz'?1:0,0,['rangeX','Horizontal sensor range (degrees)',rangeOptions,id==='timez'?18:12,'Left / right. '+help],['rangeY','Vertical sensor range (degrees)',rangeOptions,id==='timez'?18:12,'Forward / back (up / down on screen). '+help]);
  }
  function getValue(id,f){const x=config.games[id]?.[f[0]];if(f[2].includes(x))return x;if(['rangeX','rangeY'].includes(f[0])){const old=config.games[id]?.range;if(f[2].includes(old))return old;if(['plankz','beepz'].includes(id)){try{const legacy=JSON.parse(localStorage.getItem(id+'_settings')||'{}').range;if(f[2].includes(legacy))return legacy;}catch{}}}return f[0]==='theme'?config.style:f[3];}
  function save(){try{localStorage.setItem(KEY,JSON.stringify(config));notice='Saved on this Pi. Applies the next time the game opens.';noticeError=false;return true;}catch{notice='Could not save configuration. Check available browser storage.';noticeError=true;return false;}}

  const COLOR_VARS={background:'--station-bg',panel:'--station-panel',text:'--station-text',muted:'--station-muted',accent:'--station-accent'};
  const PALETTE=['#0a0a0b','#101323','#030b10','#171310','#ffffff','#c7d1df','#65f4ff','#a4a5ff','#d7ff38','#ff8453','#ef5fa7','#285778'];
  let colorRole='accent',gymDraft='',gymLower=false,gymKeyboardRows=[],updateBusy=false,updatePoll=null;
  let linkCode='',linkBusy=false,linkMessage='Not linked from this screen yet.';
  async function submitDeviceLink(){
    if(linkBusy)return;if(!/^[0-9]{6}$/.test(linkCode)){notice='Enter all six digits from the gym owner’s dashboard.';noticeError=true;render();return;}
    const code=linkCode;linkBusy=true;linkMessage='Link request in progress…';notice=linkMessage;noticeError=false;render();
    try{const r=await fetch(PROFILE_API+'/device/link',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code}),signal:AbortSignal.timeout(45000)});const d=await r.json();if(!r.ok||d.ok!==true)throw Error(d.error||'The code was not accepted. Request a new code from the gym owner’s dashboard.');if(typeof d.gym!=='string'||typeof d.ip!=='string')throw Error('Could not confirm the link. Check the gym owner’s dashboard before retrying.');linkMessage='Linked to gym: '+d.gym+' · Registered IP: '+d.ip;linkCode='';linkBusy=false;if(page==='deviceLink')go('api');if(page==='api'){notice=linkMessage;noticeError=false;render();}}
    catch(e){linkMessage=e.name==='TimeoutError'?'Link response timed out. Check the gym owner’s dashboard before trying again.':e.message||'Could not confirm the link. Check the gym owner’s dashboard before retrying.';linkCode='';linkBusy=false;if(page==='deviceLink'||page==='api'){notice=linkMessage;noticeError=true;render();}}
  }
  let gymLogo={logoUrl:'/corzlogoicon.png',custom:false,sourceFilename:'',width:405,height:402},logoBusy=false,lastLogoScan=-15000,logoMessage='Plug in a USB drive with a LOGO_TheGym.png file, up to 1024 × 1024 pixels.';
  async function readGymLogo(scan=false){
    if(logoBusy)return;logoBusy=true;if(scan)lastLogoScan=performance.now();
    try{const r=await fetch('/api/gym-logo'+(scan?'/scan':''),scan?{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(7000)}:{cache:'no-store',signal:AbortSignal.timeout(7000)});const d=await r.json();if(!r.ok)throw Error(d.error||'Logo service unavailable.');const u=new URL(d.logoUrl||'/corzlogoicon.png',location.origin);if(u.origin!==location.origin)throw Error('Logo must be stored on this station.');gymLogo={...d,logoUrl:u.pathname+u.search};if(d.scan?.message)logoMessage=d.scan.message;else logoMessage=d.custom?'Saved gym logo is loaded. USB drive can be removed.':'Using the supplied CORZ logo. Plug in USB to import your own logo.';}
    catch(e){logoMessage=e.message||'Could not read the USB logo. The previous logo is unchanged.';}
    finally{logoBusy=false;if(page==='gym')render();else style();}
  }
  config.colors=config.colors&&typeof config.colors==='object'&&!Array.isArray(config.colors)?config.colors:{};
  config.gym={name:typeof config.gym?.name==='string'?config.gym.name.slice(0,32):'',station:Number.isInteger(config.gym?.station)&&config.gym.station>=1&&config.gym.station<=99?config.gym.station:1};
  function readColor(role){const c=getComputedStyle(document.body).getPropertyValue(COLOR_VARS[role]).trim();if(/^#[0-9a-f]{6}$/i.test(c))return [1,3,5].map(i=>parseInt(c.slice(i,i+2),16));return [255,255,255];}
  function colorHex(c){return '#'+c.map(v=>v.toString(16).padStart(2,'0')).join('');}
  function applyColor(rgb){const old=structuredClone(config.colors);config.colors[config.style]={...config.colors[config.style],[colorRole]:colorHex(rgb)};if(!save())config.colors=old;else notice='Colour saved for '+title(config.style)+' on this Pi.';render();}
  function cycleColorRole(d){const roles=Object.keys(COLOR_VARS);colorRole=roles[(roles.indexOf(colorRole)+d+roles.length)%roles.length];render();}
  function changeColorChannel(i,d){const c=readColor(colorRole);c[i]=Math.min(255,Math.max(0,c[i]+d*5));applyColor(c);}
  function cyclePalette(d){const hex=colorHex(readColor(colorRole)),i=PALETTE.indexOf(hex),next=PALETTE[(i+d+PALETTE.length)%PALETTE.length];applyColor([1,3,5].map(j=>parseInt(next.slice(j,j+2),16)));}
  function resetColors(){const old=structuredClone(config.colors);delete config.colors[config.style];if(!save())config.colors=old;render();}
  function colorContrastNote(){const lum=c=>c.map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4;}).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0);const a=lum(readColor('text')),b=lum(readColor('background')),ratio=(Math.max(a,b)+.05)/(Math.min(a,b)+.05);return ratio<4.5?'Warning: text/background contrast is low. Increase the difference for readability.':'Text/background contrast: '+ratio.toFixed(1)+':1';}
  function changeGymStation(d){const old=config.gym.station;config.gym.station=(old-1+d+99)%99+1;if(!save())config.gym.station=old;render();}
  async function runSoftwareUpdate(){
    if(updateBusy)return;updateBusy=true;notice='Checking and installing software from the configured GitHub release. Please wait.';noticeError=false;render();
    try{const r=await fetch('http://localhost:8081/api/update',{method:'POST',headers:{'Content-Type':'application/json','X-CORZ-Update':'1'},body:'{}',signal:AbortSignal.timeout(7000)});if(!r.ok&&r.status!==409)throw Error('Update request failed (HTTP '+r.status+').');clearInterval(updatePoll);updatePoll=setInterval(pollSoftwareUpdate,1500);await pollSoftwareUpdate();}
    catch(e){updateBusy=false;notice=e.message||'Updater unavailable. Retry in Setup Check.';noticeError=true;render();}
  }
  async function pollSoftwareUpdate(){try{updater=await json('http://localhost:8081/api/status');if(!updater.busy&&['READY','ERROR'].includes(updater.status)){clearInterval(updatePoll);updateBusy=false;notice=updater.error?'Update failed: '+updater.error:'Update finished. '+(updater.message||'')+' Reboot after an installed update.';noticeError=!!updater.error;await json('update-release.json').then(v=>release=v).catch(()=>{});}if(page==='setup')render();}catch{if(page==='setup'){notice='Updater is restarting or temporarily unavailable. Waiting for status…';render();}}}

  function style(){document.body.dataset.stationStyle=config.style;for(const [role,v] of Object.entries(COLOR_VARS)){document.body.style.removeProperty(v);const c=config.colors?.[config.style]?.[role];if(/^#[0-9a-f]{6}$/i.test(c||''))document.body.style.setProperty(v,c);}const name=config.gym.name||'CORZ STATION',brand=root?.querySelector('.station-brand');if(brand){brand.textContent='';const img=document.createElement('img');img.src=gymLogo.logoUrl;img.alt='Gym logo';brand.append(img,document.createTextNode(name));const label=document.createElement('span');label.textContent=' · '+config.gym.station;brand.append(label);}window.CorzScreensaver?.setBrand(name,gymLogo.logoUrl);}
  const root=document.createElement('main');root.id='stationRoot';
  root.innerHTML='<header class="station-top"><div class="station-brand">CORZ<span>STATION</span></div></header><div class="station-titlebar"><div><div id="stationEyebrow" class="station-eyebrow"></div><h1 id="stationTitle"></h1><p id="stationSubtitle"></p></div><button class="station-back" id="stationBack" tabindex="-1">← Back</button></div><section id="stationBody"></section><div id="stationNotice" role="status" aria-live="polite"></div><footer class="station-footer"><div id="stationHints"></div><div class="station-footer-actions" id="stationActions"></div></footer>';
  document.body.append(root);
  const head=root.querySelector('.station-top');for(const id of ['connectivityBar','currentProfileBadge','clock']){const e=document.getElementById(id);if(e)head.append(e);}
  const cradleBadge=document.createElement('span');cradleBadge.id='stationCradle';cradleBadge.textContent='Cradle: checking…';cradleBadge.setAttribute('aria-label','Cradle connection');head.insertBefore(cradleBadge,document.getElementById('currentProfileBadge'));
  const $=id=>document.getElementById(id);
  $('currentProfileBadge').tabIndex=-1;
  $('stationBack').onclick=back;
  function card(label,description,status,symbol,action,extra={}){return{label,description,status,symbol,action,...extra};}
  function go(next,index=0){if(next==='home')next='programs';if(neutralMeasurement&&next!=='controller')cancelNeutral();if(!['home','programs'].includes(next)&&hasPin()&&!staffUnlocked){beginPin('unlock',()=>go(next,index));return;}if(['home','programs'].includes(next))staffUnlocked=false;page=next;focusIndex=index;notice='';noticeError=false;revision++;render();if(['api','diagnostics','updates','setup'].includes(next))refreshStatus();if(next==='controller')sendBle({cmd:'getDevices'});}
  function back(){if(page==='pin-entry'){cancelPin();return;}if(page==='programs')return;if(page==='game'){go('programAdmin');return;}if(page==='gymName'){go('gym');return;}if(page==='deviceLink'){linkCode='';go('api');return;}if(['config','programs'].includes(page)){go('programs');return;}go('config');}
  function profile(){openProfileHub();}
  function launch(g){selected=GAMES.indexOf(g);update();launchGame(g);}
  const gameCards=()=>GAMES.filter(g=>g.available&&!['halloffame','calibration'].includes(g.id.toLowerCase())).map(g=>card(g.id==='TimeZ'?'TIMEZ':g.title.replace(' Balance',''),g.desc.replace(' BLE plate or mouse simulation.',''),'Ready to play',({plankz:'▱',beepz:'⌁',tenz:'◎',TimeZ:'◷'})[g.id]||'◇',()=>launch(g),{icon:g.icon}));
  function render(){
    style();items=[];let heading='',sub='',eyebrow='CORZ Station',layout='station-grid',note='';
    const controllerSummary=bleOnline?(bleState==='connected'?'Connected · '+(bleName||'CORZ Cradle'):bleState==='connecting'?'Connecting · '+(bleName||selectedName):bleState==='disconnecting'?'Disconnecting Cradle…':'Not connected · select a Cradle'):'Bridge unavailable';
    if(page==='programs'){
      eyebrow='Select a program';heading='PROGRAMZ';sub='Choose a game, or open CONFIGZ for staff settings.';layout+=' programs';items=gameCards();items.push(card('CONFIGZ','Wi-Fi, controller, programs, colour and station setup.',hasPin()?'PIN PROTECTED':'STAFF ONLY',hasPin()?'🔒':'⚙',()=>go('config')));
    }else if(page==='config'){
      eyebrow='Staff configuration';heading='CONFIGZ';sub='Settings for this station. No desktop or display configuration required.';
      items=[card('Setup check','Live station readiness and selected Cradle.','CHECK STATUS','☑',()=>go('setup')),card('Wi-Fi','Use the existing station network controls.','NETWORK','⌁',()=>{openSettings();}),card('Controller','Choose the numbered CORZ Cradle belonging to this station.',controllerSummary,'♧',()=>go('controller')),card('Program admin','Starting values and a theme for each game.','4 PROGRAMS','☷',()=>go('programAdmin')),card('API connector','OurCorz connection and result-upload status.','EXISTING CONNECTION','↗',()=>go('api')),card('GYM Profile','Local gym name and station identity.','THIS STATION','⌂',()=>go('gym')),card('Player profile','View the selected NFC player and server statistics.',currentProfile?.display_name||'TAP NFC TAG','○',profile),card('COLOR','Custom background, text, panels and highlight colours.',title(config.style),'◐',()=>go('color')),card('Style','Choose the dashboard design direction.',title(config.style),'◐',()=>go('style'))];
    }else if(page==='screensaver'){
      eyebrow='Configuration';heading='Screen saver';sub='Left / Right or OK changes a value. Saved automatically. A remote button or NFC scan wakes the screen without reconnecting the Cradle.';layout='station-list';
      note='Inactivity includes remote buttons, pointer input, NFC tag scans and meaningful Cradle movement. At timeout, the station sends 0x45 and waits for the Cradle to disconnect. Games pause without losing their in-memory session. Wake the Cradle and select it manually before continuing.';
      items=[card('Idle timeout','Time without activity before the screen saver. The Cradle stays on; its battery panel moves between corners.',config.screensaver.minutes?config.screensaver.minutes+' minutes':'OFF',null,()=>changeSaver('minutes',1),{change:delta=>changeSaver('minutes',delta)}),card('Screen saver style','Two lightweight animated styles following the station theme.',config.screensaver.type==='orbit'?'Orbit · floating CORZ rings':'Grid · neon horizon',null,()=>changeSaver('type',1),{change:delta=>changeSaver('type',delta)})];
    }else if(page==='pinSettings'){
      eyebrow='Configuration';heading='Configuration PIN';sub='Optional four-arrow staff PIN. Up = 1, Right = 2, Down = 3, Left = 4. Entry is always masked.';
      note=hasPin()?'PIN protection is enabled. Returning to the dashboard locks Configuration again. This is a local staff-access lock, not encryption of the Pi or its files.':'No PIN is set. Configuration remains open until you create and confirm an arrow sequence.';
      items=[card(hasPin()?'Change PIN':'Create PIN','Enter four arrows, then repeat them to confirm.',hasPin()?'CHANGE':'SET PIN','🔒',()=>beginPin('new'))];
      if(hasPin())items.push(card('Remove PIN','Confirm the current arrow PIN to remove protection.','REMOVE','○',()=>beginPin('remove')),card('Lock Configuration now','Return to the dashboard. The PIN will be required to enter again.','LOCK','🔒',()=>go('home',0)));
    }else if(page==='pin-entry'){
      eyebrow='Staff access';heading=pinMode==='unlock'?'Unlock Configuration':pinMode==='new'?'Create your arrow PIN':pinMode==='confirm'?'Confirm your arrow PIN':'Remove PIN protection';
      sub='Enter four arrow presses. OK confirms. HOME / BACK cancels. Only stars are shown.';layout='station-list';
      items=[card(pinBusy?'Please wait…':'Confirm','Press OK after entering the sequence.',pinBusy?'CHECKING':'OK',null,submitPin,{disabled:pinBusy}),card('Clear entry','Start this entry again.','CLEAR',null,()=>{pinEntry='';notice='';render();},{disabled:pinBusy}),card('Cancel','Do not change or unlock anything.','BACK',null,cancelPin)];
    }else if(page==='programAdmin'){
      eyebrow='Configuration';heading='Program admin';sub='Set the starting values for the next session. Players can still adjust supported settings before a run.';
      items=Object.entries(defs).map(([id,d])=>card(d.name,d.fields.filter(f=>f[0]!=='theme').map(f=>f[1]+': '+getValue(id,f)).join(' · '),title(getValue(id,d.fields.find(f=>f[0]==='theme'))),'◇',()=>{editGame=id;go('game');}));
    }else if(page==='navigation'){
      eyebrow='Configuration';heading='Game navigation';sub='Set how long to hold the Cradle cursor at an edge. Left / Right or OK changes the value. Saved automatically for the next game launch.';layout='station-list';
      items=[card('Edge hold time','Applies to all four edges in PLANKZ, BEEPZ, TENZ and Workout TimeZ. The glowing countdown follows this duration.',config.navigation.edgeHoldSeconds+' seconds',null,()=>changeEdgeHold(1),{change:delta=>changeEdgeHold(delta)})];
    }else if(page==='game'){
      const d=defs[editGame];eyebrow='Program admin';heading=d.name;sub='Left / Right changes a value. OK advances it. Saved automatically on this Pi.';layout='station-list';
      items=d.fields.map(f=>card(f[1],f[4]||'Default for new sessions.',String(getValue(editGame,f)),null,()=>changeField(f,1),{change:delta=>changeField(f,delta)}));
    }else if(page==='style'){
      eyebrow='Configuration';heading='Station style';sub='Choose a design direction. Existing game themes stay as configured in Program admin.';
      const desc={performance:'High-contrast dark panels with lime highlights.',console:'Soft violet, clear panels and clean type.',tron:'Cyan light, fine grid and technical typography.',rebel:'Warm orange highlights with bold dark panels.'};
      items=STYLES.map(s=>card(title(s),desc[s],config.style===s?'ACTIVE':'PREVIEW & APPLY','◐',()=>{const old=config.style;config.style=s;if(!save())config.style=old;render();}));
    }else if(page==='color'){
      eyebrow='CONFIGZ';heading='COLOR';sub='Choose a colour role, then adjust Red / Green / Blue with Left / Right or OK. Saved per station style.';layout='station-list';
      const rgb=readColor(colorRole),labels={background:'Background',panel:'Panels',text:'Text',muted:'Secondary text',accent:'Highlight'};
      note='Editing '+title(config.style)+' · '+labels[colorRole]+' · '+colorHex(rgb)+'\n'+colorContrastNote();
      items=[card('Colour role','Choose which part of this style to customise.',labels[colorRole],null,()=>cycleColorRole(1),{change:cycleColorRole}),...['Red','Green','Blue'].map((name,i)=>card(name,'0–255 · changes in steps of 5. Hold Left / Right to adjust.',String(rgb[i]),null,()=>changeColorChannel(i,1),{change:d=>changeColorChannel(i,d)})),card('Palette colour','Cycle useful starting colours, then fine-tune the channels.',colorHex(rgb),'◐',()=>cyclePalette(1),{change:cyclePalette}),card('Reset this style’s colours','Restore the original colours for this design only.','RESET',null,resetColors)];
    }else if(page==='gym'){
      eyebrow='CONFIGZ';heading='GYM Profile';sub='Your station name and logo appear on PROGRAMZ and the screen saver. No changes are sent to OurCorz.';layout='station-list';
      note='Name: '+(config.gym.name||'CORZ STATION')+'\nStation: '+config.gym.station+'\nLogo: '+(gymLogo.custom?gymLogo.sourceFilename+' · '+gymLogo.width+' × '+gymLogo.height:'Supplied CORZ logo')+'\n'+logoMessage+'\nUSB logos are detected automatically. Use any name starting LOGO_ and ending .png, for example LOGO_TheGym.png. Maximum 1024 × 1024 pixels. A successfully imported logo stays saved after unplugging.\nStation branding is local only; server gym details and rankings are not changed.';
      items=[card('Station name','Open the on-screen keyboard to enter your own station name.',config.gym.name||'SET NAME',null,()=>{gymDraft=config.gym.name;gymLower=false;go('gymName');}),card('Station number','Identify this screen when several stations are in the same gym.',String(config.gym.station),null,()=>changeGymStation(1),{change:changeGymStation}),card(logoBusy?'Checking USB logo…':'Check USB logo','Import a PNG whose name starts LOGO_, for example LOGO_TheGym.png, from a mounted USB drive. Keep the drive inserted until import completes.',gymLogo.custom?'CUSTOM LOGO':'DEFAULT LOGO','◐',()=>readGymLogo(true),{disabled:logoBusy})];
    }else if(page==='gymName'){
      eyebrow='GYM Profile';heading='Station name';sub='Use the arrows to move around the keyboard. Press OK to enter a letter. Save applies the name; Back cancels.';
      gymKeyboardRows=['1234567890','QWERTYUIOP','ASDFGHJKL',"ZXCVBNM-.&'"].map(row=>[...row].map(c=>({label:gymLower?c.toLowerCase():c,action:()=>{if(gymDraft.length<32){gymDraft+=gymLower?c.toLowerCase():c;notice='';}else notice='Maximum 32 characters.';render();}})));
      gymKeyboardRows.push([{label:gymLower?'ABC':'abc',action:()=>{gymLower=!gymLower;render();}},{label:'Space',action:()=>{if(gymDraft.length<32)gymDraft+=' ';render();}},{label:'⌫ Delete',action:()=>{gymDraft=gymDraft.slice(0,-1);notice='';render();}},{label:'Clear',action:()=>{gymDraft='';notice='';render();}},{label:'Save name',action:()=>{const old=config.gym.name;config.gym.name=gymDraft.trim();if(!save()){config.gym.name=old;render();}else go('gym');}},{label:'Cancel',action:()=>go('gym')}]);
      items=gymKeyboardRows.flat().map(c=>card(c.label,'','',null,c.action));
    }else if(page==='deviceLink'){
      eyebrow='API Connector';heading='Link device to gym';sub='Ask the gym owner to choose Link device on their dashboard. Enter the six-digit code here within ten minutes, then select Link device.';
      gymKeyboardRows=['123','456','789'].map(row=>[...row].map(c=>({label:c,action:()=>{if(!linkBusy&&linkCode.length<6){linkCode+=c;notice='';noticeError=false;render();}}})));
      gymKeyboardRows.push([{label:'Clear',action:()=>{if(!linkBusy){linkCode='';render();}}},{label:'0',action:()=>{if(!linkBusy&&linkCode.length<6){linkCode+='0';render();}}},{label:'⌫ Delete',action:()=>{if(!linkBusy){linkCode=linkCode.slice(0,-1);render();}}}]);
      gymKeyboardRows.push([{label:linkBusy?'Linking…':'Link device',action:submitDeviceLink},{label:'Cancel',action:()=>{linkCode='';go('api');}}]);
      items=gymKeyboardRows.flat().map(c=>card(c.label,'','',null,c.action,{disabled:linkBusy}));
    }else if(page==='controller'){
      eyebrow='Configuration';heading='Connect your Cradle';sub='Turn on your CORZ device, then scan. Select the exact device number for this station.';layout='station-list';
      note='Connection: '+controllerSummary+'\nLast selected: '+(selectedName||selectedAddress||'None')+'\nManual connection only. Scanning never connects a Cradle. After a restart or disconnection, scan and select a device again. You can switch devices without turning the old one off.';
      items=[card(scanning?'Scanning for CORZ devices…':'Find CORZ devices','Lists nearby devices only. Choose the exact number, then press OK to connect.',scanning?'SCANNING':'SCAN',null,scan,{disabled:scanning||!bleOnline})];
      items.push(card('Rotate +90°','Clockwise movement rotation. Saved for PLANKZ, BEEPZ, TENZ and TimeZ.',rotationPending?'SAVING…':cradleRotation+'°',null,rotateCradle,{disabled:rotationPending||!bleOnline}));
      items.push(card(neutralMeasurement?'Cancel neutral calibration':'Calibrate neutral','Leave the Cradle sensor alone, empty and still for five seconds. Shared by all games on this Pi; sensitivity is retained.',neutralMeasurement?'CANCEL':'CALIBRATE',null,startNeutral,{disabled:!bleOnline||bleState!=='connected'}));
      if(bleState==='connected'||bleState==='connecting')items.push(card('Disconnect Cradle','Release the current Cradle without turning it off. No automatic reconnection.','DISCONNECT',null,disconnectDevice,{disabled:!bleOnline}));
      for(const d of devices)items.push(card(d.name,d.address,d.address===selectedAddress&&bleState==='connected'?'CONNECTED':d.address===selectedAddress?'LAST SELECTED · CONNECT':'SELECT & CONNECT',null,()=>selectDevice(d),{disabled:scanning}));
      if(!devices.length)note+='\n'+(scanning?'Looking for nearby CORZ_ devices…':'No scan results yet. Press Find CORZ devices.');
      if(bleError)note+='\n'+bleError;
    }else if(page==='api'){
      eyebrow='Configuration';heading='API connector';sub='Uses the existing configured API key. Keys and server endpoints are not changed here.';layout='station-list';
      note='Server: '+(bridgeStatus?.upstream||'Waiting for the local API bridge…')+'\nAPI key: '+(bridgeStatus?bridgeStatus.configured?'Configured':'Not configured':'Checking…')+'\nResult upload support: '+(bridgeStatus?bridgeStatus.scoreWriteSupported?'Available for PLANKZ, BEEPZ and TENZ':'Unavailable':'Checking…')+'\nPlayer: '+(currentProfile?.display_name||'No player selected — tap a registered NFC tag')+'\nLast upload: '+lastUpload();
      note+='\nDevice linking: '+linkMessage;
      items=[card('Link device to gym','Enter the six-digit, ten-minute code from the gym owner’s dashboard using the on-screen keypad.',linkBusy?'LINKING…':'ENTER CODE','↗',()=>{linkCode='';go('deviceLink');},{disabled:linkBusy}),card('Refresh connection status','Reads local bridge status; does not create a score.','READ ONLY',null,refreshStatus),card('Player statistics','Read the current profile and game history.','OPEN',null,profile)];
    }else if(page==='updates'){
      eyebrow='Configuration';heading='Software update';sub='Keep publishing the matching package.zip and update.json to your existing GitHub location.';layout='station-list';
      note='Installed dashboard: '+(release?.version||bridgeStatus?.bridgeBuild||'Checking…')+'\nUpdater: '+(updater?.status||updater?.state||'Status unavailable')+'\n'+(updater?.message||'Updates are checked by your existing updater during station startup.')+(updater?.error?'\nLast updater error: '+updater.error:'')+'\nNo new setup script, desktop setting or service installation is required.';
      items=[card('Refresh status','Read the installed release and updater status.','REFRESH',null,refreshStatus)];
    }else if(page==='diagnostics'||page==='setup'){
      eyebrow='Configuration';heading=page==='setup'?'Station readiness':'Diagnostics';sub='Live connection checks. No calibration, API write or hardware configuration is performed here.';layout='station-list';
      note='BLE bridge: '+(bleOnline?'Online':'Unavailable')+'\nCradle: '+controllerSummary+'\nLast selected Cradle: '+(selectedName||'None')+'\nConnection mode: Manual only (no auto-connect or auto-reconnect)'+'\nNFC reader: '+(bridgeStatus?.nfc?.readerStatus|| (bridgeStatus?.serialConnected?'Connected':'Not available'))+'\nNFC API lookup: '+(bridgeStatus?.nfc?.lookupRunning?'Running':'Idle')+'\nAPI key: '+(bridgeStatus?bridgeStatus.configured?'Configured':'Missing':'Checking…')+'\nScore upload support: '+(bridgeStatus?.scoreWriteSupported?'Available':'Not available')+'\nInstalled build: '+(release?.version||bridgeStatus?.bridgeBuild||'Checking…')+'\nUpdater: '+(updater?.status||'Checking…')+' · '+(updater?.message||'')+(updater?.error?'\nUpdate error: '+updater.error:'');
      items=[card('Refresh checks','Read current station status.','REFRESH',null,refreshStatus),card('Select Cradle','Assign the CORZ device for this station.','CONTROLLER',null,()=>go('controller'))];
    }
    if(page==='setup')items.push(card(updateBusy?'Updating software…':'Run software update','Check the existing GitHub release and install it if newer. The station may reload; wait for completion.',updateBusy?'PLEASE WAIT':'CHECK & INSTALL','↓',runSoftwareUpdate,{disabled:updateBusy}));
    if(page==='config')items.splice(4,0,card('Game navigation','Cradle edge activation time for every game.',config.navigation.edgeHoldSeconds+' SECOND HOLD','◷',()=>go('navigation')));
    if(page==='config')items.push(card('Configuration PIN','Optional arrow-sequence protection for staff settings.',hasPin()?'ENABLED':'NO PIN','🔒',()=>go('pinSettings')));
    if(page==='config')items.push(card('Screen saver','Idle timeout and two animated styles. Keeps the Cradle on with a moving battery panel.',config.screensaver.minutes?config.screensaver.minutes+' MINUTES':'OFF','◐',()=>go('screensaver')));
    $('stationEyebrow').textContent=eyebrow;$('stationTitle').textContent=heading;$('stationSubtitle').textContent=sub;
    $('stationBack').hidden=page==='programs'||page==='home';
    $('stationBody').innerHTML=(note?'<div class="station-note">'+esc(note)+'</div>':'')+'<div class="'+layout+'">'+items.map((c,i)=>'<button type="button" class="station-card" data-item="'+i+'" tabindex="-1" '+(c.disabled?'disabled':'')+'>'+(c.icon?'<img class="station-game-icon" src="'+esc(c.icon)+'" alt="">':c.symbol?'<span class="symbol" aria-hidden="true">'+esc(c.symbol)+'</span>':'')+'<strong>'+esc(c.label)+'</strong><span class="description">'+esc(c.description)+'</span><span class="status">'+esc(c.status)+'</span></button>').join('')+'</div>';
    if(page==='gymName'||page==='deviceLink'){const linking=page==='deviceLink';let offset=0;$('stationBody').innerHTML='<section class="gym-keyboard '+(linking?'device-link-keypad':'')+'" aria-label="'+(linking?'Device link code keypad':'Station name on-screen keyboard')+'"><div class="gym-name-preview" aria-live="polite"><span>'+(linking?esc(linkCode.padEnd(6,'_')):esc(gymDraft||'Enter station name'))+'</span><small>'+(linking?linkCode.length+' / 6':gymDraft.length+' / 32')+'</small></div>'+gymKeyboardRows.map((row,r)=>'<div class="gym-keyboard-row" data-keyrow="'+r+'">'+row.map(c=>'<button type="button" class="gym-key" data-item="'+offset+++'" tabindex="-1" '+(linking&&linkBusy?'disabled':'')+'>'+esc(c.label)+'</button>').join('')+'</div>').join('')+'<p class="gym-keyboard-note">'+(linking?'The code is supplied by the gym owner. The server checks its ten-minute expiry. Your API key is not displayed or changed.':'Leave the name empty to use CORZ STATION. Changes are saved on this Pi only.')+'</p></section>';}
    if(page==='pin-entry')$('stationBody').insertAdjacentHTML('afterbegin','<div class="station-pin-mask" role="status" aria-label="Masked PIN entry">'+Array.from({length:4},(_,i)=>'<span>'+(i<pinEntry.length?'*':'·')+'</span>').join('')+'</div>');
    $('stationActions').innerHTML=page==='programs'?'<button data-extra="hall" tabindex="-1">Hall of Fame</button><button data-extra="profile" tabindex="-1">Player profile</button>':page==='home'?'<button data-extra="profile" tabindex="-1">Player profile</button>':'';
    root.querySelector('.cradle-preview')?.remove();
    if(page==='controller'){$('stationBody').insertAdjacentHTML('beforebegin',rotationView());updatePreview();}
    root.querySelectorAll('[data-item]').forEach(b=>{b.onclick=()=>{focusIndex=Number(b.dataset.item);activate();};});
    root.querySelectorAll('[data-extra]').forEach(b=>{b.onclick=()=>{if(b.dataset.extra==='hall')launch(GAMES.find(g=>g.id==='halloffame'));else profile();};});
    $('stationHints').innerHTML=['game','navigation','screensaver','color','gym'].includes(page)?'<b>↑ ↓</b> Select setting &nbsp; <b>← → / OK</b> Change &nbsp; <b>HOME / BACK</b> Return':'<b>← → ↑ ↓</b> Navigate &nbsp; <b>OK</b> Select &nbsp; <b>HOME / BACK</b> Return';
    if(page==='pin-entry')$('stationHints').innerHTML='<b>↑ → ↓ ←</b> Enter PIN &nbsp; <b>OK</b> Confirm &nbsp; <b>HOME / BACK</b> Cancel';
    if(page==='gymName'||page==='deviceLink')$('stationHints').innerHTML='<b>↑ ↓ ← →</b> Select key &nbsp; <b>OK</b> Type &nbsp; <b>HOME / BACK</b> Cancel';
    if(!bleOnline&&page==='controller'&&!notice){notice='BLE bridge unavailable. Waiting to reconnect…';noticeError=true;}
    $('stationNotice').textContent=notice;$('stationNotice').classList.toggle('error',noticeError);highlight(false);
  }
  function buttons(){return[...$('stationBody').querySelectorAll('[data-item]'),...$('stationActions').querySelectorAll('button')];}
  function highlight(scroll=true){const bs=buttons();focusIndex=Math.max(0,Math.min(focusIndex,bs.length-1));bs.forEach((b,i)=>{b.classList.toggle('selected',i===focusIndex);b.setAttribute('aria-current',i===focusIndex?'true':'false');});if(scroll)bs[focusIndex]?.scrollIntoView({block:'nearest',inline:'nearest'});}
  function activate(){const bs=buttons(),b=bs[focusIndex];if(!b||b.disabled)return;if(b.dataset.item!==undefined)items[Number(b.dataset.item)]?.action();else b.click();}
  function changeField(f,delta){const old=structuredClone(config),arr=f[2],v=getValue(editGame,f);config.games[editGame]={...config.games[editGame],[f[0]]:arr[(arr.indexOf(v)+delta+arr.length)%arr.length]};if(!save())config=old;render();}
  function changeEdgeHold(delta){const old=config.navigation.edgeHoldSeconds;config.navigation.edgeHoldSeconds=EDGE_HOLD_TIMES[(EDGE_HOLD_TIMES.indexOf(old)+delta+EDGE_HOLD_TIMES.length)%EDGE_HOLD_TIMES.length];if(!save())config.navigation.edgeHoldSeconds=old;render();}
  function changeSaver(field,delta){const values=field==='minutes'?SAVER_TIMES:SAVER_TYPES,old=config.screensaver[field];config.screensaver[field]=values[(values.indexOf(old)+delta+values.length)%values.length];if(!save())config.screensaver[field]=old;else notice='Saved on this Pi. Screen saver settings apply immediately.';window.CorzScreensaver?.configure(config.screensaver,sendBle);render();}
  function key(k){if(page==='pin-entry'){if(['Backspace','Escape','Home','BrowserHome','BrowserBack'].includes(k)){cancelPin();return;}if(pinBusy)return;if(k==='Enter'){submitPin();return;}if(pinDigits[k]){if(Date.now()<pinBlockedUntil){notice='Too many attempts. Wait a moment before trying again.';noticeError=true;}else if(pinEntry.length<4){pinEntry+=pinDigits[k];notice='';noticeError=false;}render();}return;}if(k==='Backspace'){back();return;}if(k==='Enter'){activate();return;}if(!k.startsWith('Arrow'))return;
    if(page==='gymName'||page==='deviceLink'){let row=0,col=focusIndex;while(row<gymKeyboardRows.length-1&&col>=gymKeyboardRows[row].length)col-=gymKeyboardRows[row++].length;if(k==='ArrowLeft'||k==='ArrowRight')col=(col+(k==='ArrowRight'?1:-1)+gymKeyboardRows[row].length)%gymKeyboardRows[row].length;else{row=(row+(k==='ArrowDown'?1:-1)+gymKeyboardRows.length)%gymKeyboardRows.length;col=Math.min(col,gymKeyboardRows[row].length-1);}focusIndex=gymKeyboardRows.slice(0,row).reduce((n,r)=>n+r.length,0)+col;highlight();return;}
    if(['game','navigation','screensaver','color','gym'].includes(page)&&(k==='ArrowLeft'||k==='ArrowRight')){items[focusIndex]?.change?.(k==='ArrowRight'?1:-1);return;}
    const n=buttons().length;if(!n)return;let step=1;if(k==='ArrowUp'||k==='ArrowDown'){const grid=$('stationBody').querySelector('.station-grid');step=grid?getComputedStyle(grid).gridTemplateColumns.split(' ').length:1;}
    if(k==='ArrowLeft'||k==='ArrowUp')step=-step;
    focusIndex=(focusIndex+step+n)%n;highlight();
  }
  const oldInput=handleArcadeInput;
  handleArcadeInput=function(k){if(window.CorzPowerUi?.isOpen()||profileOpen||stgOpen||overlay.style.display==='block'){oldInput(k);return;}key(k);};
  // Existing Wi-Fi remains functional and returns to Configuration, not the old carousel.
  const oldClose=closeSettings;closeSettings=function(){oldClose();go('config',1);};
  const oldOpenSettings=openSettings;openSettings=function(){if(hasPin()&&!staffUnlocked){beginPin('unlock',()=>oldOpenSettings());return;}oldOpenSettings();};
  const oldOpenGame=openGame;openGame=function(url){document.body.classList.add('station-game-open');oldOpenGame(url);};
  const oldCloseGame=closeGame;closeGame=function(){oldCloseGame();document.body.classList.remove('station-game-open');};
  // Only the currently visible, same-origin game can request its own settings.
  // Games finish/save first; closing here cannot resume an old scored attempt.
  window.addEventListener('message',event=>{
    if(event.source!==frame.contentWindow||event.origin!==location.origin||event.data?.type!=='corz-open-program-settings'||overlay.style.display!=='block')return;
    const routes={plankz:['plankz','plankz.html'],beepz:['beepz','beepz.html'],tenz:['tenz','tenz.html'],workout:['timez','workout-timer.html']};
    const route=Object.hasOwn(routes,event.data.game)?routes[event.data.game]:null;
    if(!route||new URL(frame.src,location.href).pathname.split('/').pop()!==route[1])return;
    closeGame();editGame=route[0];go('game');
  });
  function lastUpload(){const r=bridgeStatus?.lastResult;if(!r)return'None reported';return r.status||r.message||(r.error?'Error: '+r.error:'See game result screen');}
  async function json(url){const r=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(7000)});if(!r.ok)throw Error('HTTP '+r.status);return r.json();}
  let refreshRunning=false;
  async function refreshStatus(){if(refreshRunning)return;refreshRunning=true;const p=page,rev=revision;let failed=false;
    await Promise.all([json(PROFILE_API+'/status').then(x=>bridgeStatus=x).catch(()=>{bridgeStatus=null;failed=true;}),json('update-release.json').then(x=>release=x).catch(()=>{}),json('http://localhost:8081/api/status').then(x=>updater=x).catch(()=>updater=null)]);
    refreshRunning=false;if(page===p&&revision===rev){notice=failed?'Local API bridge unavailable. Check Setup Check and the station services.':'Status refreshed. No scores were submitted.';noticeError=failed;render();}
  }
  function sendBle(obj){if(bleSocket?.readyState!==WebSocket.OPEN){bleError='BLE bridge is not connected.';return false;}bleSocket.send(JSON.stringify(obj));return true;}
  function scan(){if(scanning||!bleOnline)return;scanning=true;bleError='';devices=[];notice='Looking for nearby CORZ devices…';noticeError=false;sendBle({cmd:'scanDevices',requestId:++requestId});clearTimeout(scanTimer);scanTimer=setTimeout(()=>{if(scanning){scanning=false;bleError='Scan timed out. Try again or check the BLE service.';if(page==='controller')render();}},20000);render();}
  function selectDevice(d){if(!confirmSelection(d))return;notice='Connecting to '+d.name+'…';noticeError=false;bleError='';sendBle({cmd:'selectDevice',address:d.address,requestId:++requestId});render();}
  function disconnectDevice(){notice='Disconnecting Cradle…';noticeError=false;bleError='';sendBle({cmd:'disconnectDevice',requestId:++requestId});render();}
  // OK on an explicit numbered device is the confirmation; no mouse-only dialog.
  function confirmSelection(d){return typeof d.address==='string'&&devices.some(x=>x.address===d.address);}
  function bleConnect(){clearTimeout(bleTimer);try{
    bleSocket=new WebSocket('ws://localhost:8765');
    bleSocket.onopen=()=>{bleOnline=true;bleError='';sendBle({cmd:'getDevices'});if(page==='controller')render();};
    bleSocket.onmessage=e=>{try{const d=JSON.parse(e.data);if(CorzCalibration.observe(d)&&neutralMeasurement)cancelNeutral('Calibration cancelled: orientation or device changed. Retry with the sensor untouched.');if(d.type==='status'&&d.status!=='connected'&&neutralMeasurement)cancelNeutral('Calibration cancelled: Cradle disconnected.');window.CorzScreensaver?.receive(d);if(d.type==='data'){if(Number.isFinite(d.roll)&&Number.isFinite(d.pitch)){previewSample={roll:d.roll,pitch:d.pitch};previewTime=performance.now();sampleNeutral();if(page==='controller')updatePreview();}const b=Number(d.battery);cradleBadge.textContent=(bleName||'Cradle')+(Number.isFinite(b)?' · '+Math.max(0,Math.min(100,Math.round(b)))+'%':'');return;}
      if(d.type==='status'||d.type==='orientation'){if([0,90,180,270].includes(d.rotation)){if(cradleRotation!==d.rotation){previewCentre=null;previewSample=null;previewTime=0;}cradleRotation=d.rotation;}if(d.type==='orientation'){rotationPending=false;notice='Orientation saved: '+cradleRotation+'°. Applies to all balance games.';noticeError=false;}}
      if(d.type==='status'){if(d.status!=='connected'||bleName!==(d.deviceName||'')){previewSample=null;previewCentre=null;previewTime=0;}bleState=d.status;bleName=d.deviceName||'';if(d.selectedAddress!==undefined)selectedAddress=d.selectedAddress;if(d.selectedName!==undefined)selectedName=d.selectedName||'';cradleBadge.textContent=bleState==='connected'?(bleName||'Cradle connected'):'Cradle: '+bleState;if(d.selectionError)bleError=d.selectionError;}
      if(d.type==='devices'){devices=Array.isArray(d.devices)?d.devices.filter(x=>typeof x.name==='string'&&x.name.startsWith('CORZ_')&&typeof x.address==='string'):[];if(d.selectedAddress!==undefined)selectedAddress=d.selectedAddress;if(d.selectedName!==undefined)selectedName=d.selectedName||'';if(d.scanning!==undefined)scanning=!!d.scanning;else scanning=false;if(!scanning){clearTimeout(scanTimer);notice=devices.length?'Choose the exact numbered Cradle for this station.':'No advertising CORZ devices found. Wake the device and scan again.';noticeError=false;}}
      if(d.type==='selection'){selectedAddress=d.selectedAddress??d.address??selectedAddress;selectedName=d.selectedName||d.deviceName||d.name||selectedName;notice='Connection requested for '+(selectedName||selectedAddress)+'. Wait for Connected before starting a game.';noticeError=false;}
      if(d.type==='disconnection'){notice='Cradle disconnected. Scan and select a device when you want to connect.';noticeError=false;}
      if(d.type==='error'){rotationPending=false;scanning=false;clearTimeout(scanTimer);bleError=d.message||d.error||'BLE operation failed.';notice=bleError;noticeError=true;}
      if(['controller','config','diagnostics','setup'].includes(page))render();
    }catch{}};
    bleSocket.onclose=()=>{if(neutralMeasurement)cancelNeutral();rotationPending=false;previewSample=null;previewCentre=null;bleOnline=false;bleState='unavailable';cradleBadge.textContent='Cradle: bridge offline';scanning=false;clearTimeout(scanTimer);if(['controller','config','diagnostics','setup'].includes(page))render();bleTimer=setTimeout(bleConnect,3000);};bleSocket.onerror=()=>{};
  }catch{bleOnline=false;bleTimer=setTimeout(bleConnect,3000);}}
  // Read-only introspection for diagnostics and automated regression checks.
  window.CorzStation={get page(){return page;},get config(){return structuredClone(config);},get selection(){return{selectedName,selectedAddress,bleState,bleOnline};},open:go,key,lockForIdle(){pinRequest++;pinEntry='';pinFirst='';pinBusy=false;pinTarget=null;staffUnlocked=false;page='programs';focusIndex=0;notice='';revision++;if(profileOpen)closeProfileOverlay();if(stgOpen)closeSettings();staffUnlocked=false;page='programs';render();}};
  window.CorzScreensaver?.configure(config.screensaver,sendBle);
  style();render();bleConnect();
  readGymLogo();setInterval(()=>{if(document.visibilityState==='visible'&&(page==='gym'||performance.now()-lastLogoScan>=15000))readGymLogo(true);},4000);
  setInterval(()=>{if(neutralMeasurement&&(page!=='controller'||document.hidden||!bleOnline||bleState!=='connected'||performance.now()-previewTime>=600))cancelNeutral('Calibration cancelled: readings stopped or screen was left. Previous neutral is unchanged.');if(page==='controller')updatePreview();},100);
})();
