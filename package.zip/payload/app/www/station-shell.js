/* CORZ Station — package-managed UI. Keeps existing game/NFC/API/power services. */
(() => {
  'use strict';
  const KEY='corz_station_config_v1', STYLES=['performance','console','tron','rebel'];
  const EDGE_HOLD_TIMES=[1,1.5,2,2.5,3,4,5,6,8,10];
  let config={style:'performance',games:{}}, storageError='';
  try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))config={...config,...saved,games:saved.games&&typeof saved.games==='object'?saved.games:{}};}catch{storageError='Saved configuration could not be read. Changes will need to be saved again.';}
  if(!STYLES.includes(config.style))config.style='performance';
  config.navigation={edgeHoldSeconds:EDGE_HOLD_TIMES.includes(config.navigation?.edgeHoldSeconds)?config.navigation.edgeHoldSeconds:2};
  let page='home',focusIndex=1,items=[],notice=storageError,noticeError=!!storageError,editGame=null,revision=0;
  let staffUnlocked=false,pinMode='unlock',pinEntry='',pinFirst='',pinBusy=false,pinRequest=0,pinFailures=0,pinBlockedUntil=0,pinTarget=null;
  const hasPin=()=>!!config.pin;
  const pinDigits={ArrowUp:'1',ArrowRight:'2',ArrowDown:'3',ArrowLeft:'4'};
  function beginPin(mode,target=null){pinRequest++;pinMode=mode;pinTarget=target;pinEntry='';pinFirst='';pinBusy=false;page='pin-entry';focusIndex=0;notice='';noticeError=false;revision++;render();}
  function cancelPin(){pinRequest++;pinEntry='';pinFirst='';pinBusy=false;const unlock=pinMode==='unlock';pinTarget=null;go(unlock?'home':'pinSettings',0);}
  async function pinHash(sequence,salt){
    if(!globalThis.crypto?.subtle)throw Error('PIN protection needs the local station browser. Open the dashboard on this Pi.');
    const raw=await crypto.subtle.importKey('raw',new TextEncoder().encode(sequence),'PBKDF2',false,['deriveBits']);
    const bytes=Uint8Array.from(salt.match(/../g)||[],x=>parseInt(x,16));
    const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytes,iterations:120000,hash:'SHA-256'},raw,256);
    return [...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,'0')).join('');
  }
  async function submitPin(){
    if(pinBusy)return;
    if(Date.now()<pinBlockedUntil){notice='Too many attempts. Wait a moment before trying again.';noticeError=true;render();return;}
    if(pinEntry.length!==4){notice='Enter four arrow presses, then press OK.';noticeError=true;render();return;}
    if(pinMode==='new'){pinFirst=pinEntry;pinEntry='';pinMode='confirm';notice='Repeat the same arrow sequence, then press OK.';noticeError=false;render();return;}
    if(pinMode==='confirm'&&pinEntry!==pinFirst){pinEntry='';pinFirst='';pinMode='new';notice='The sequences did not match. Create your PIN again.';noticeError=true;render();return;}
    const token=++pinRequest,sequence=pinEntry,mode=pinMode;pinBusy=true;notice='Checking…';noticeError=false;render();
    try{
      if(mode==='confirm'){
        const salt=[...crypto.getRandomValues(new Uint8Array(16))].map(x=>x.toString(16).padStart(2,'0')).join('');
        const hash=await pinHash(sequence,salt);if(token!==pinRequest)return;
        const old=config.pin;config.pin={salt,hash};
        if(!save()){if(old===undefined)delete config.pin;else config.pin=old;pinBusy=false;render();return;}
        pinEntry='';pinFirst='';pinBusy=false;staffUnlocked=false;go('home',0);notice='PIN saved. Configuration is now locked.';render();return;
      }
      const valid=typeof config.pin?.salt==='string'&&typeof config.pin?.hash==='string'&&await pinHash(sequence,config.pin.salt)===config.pin.hash;
      if(token!==pinRequest)return;
      pinBusy=false;pinEntry='';
      if(!valid){pinFailures++;if(pinFailures>=5){pinBlockedUntil=Date.now()+30000;pinFailures=0;}notice='Incorrect PIN. Try again.';noticeError=true;render();return;}
      pinFailures=0;pinBlockedUntil=0;
      if(mode==='remove'){
        const old=config.pin;delete config.pin;if(!save()){config.pin=old;render();return;}
        go('pinSettings');notice='PIN removed. Configuration is no longer protected.';render();return;
      }
      staffUnlocked=true;const target=pinTarget;pinTarget=null;if(target)target();else go('config');
    }catch(e){if(token!==pinRequest)return;pinBusy=false;pinEntry='';notice=e.message||'PIN could not be checked.';noticeError=true;render();}
  }
  let bridgeStatus=null,release=null,updater=null,bleSocket=null,bleTimer=null,bleOnline=false,bleState='unavailable',bleName='',selectedName='',selectedAddress=null,devices=[],scanning=false,scanTimer=null,bleError='',requestId=0;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let cradleRotation=0,rotationPending=false,previewSample=null,previewCentre=null,previewTime=0;
  function rotationView(){return '<section class="cradle-preview" aria-label="Live Cradle movement preview"><div class="cradle-preview-board"><span class="cradle-preview-up">FORWARD / UP</span><span id="cradlePreviewDot"></span></div><div><strong>Movement preview · '+cradleRotation+'°</strong><p id="cradlePreviewStatus" role="status">Connect a Cradle, then tilt it to check direction.</p><p>Use Rotate +90° until movement matches the screen. Centre preview while the Cradle is level. Games still run their normal calibration.</p></div></section>';}
  function updatePreview(){const dot=$('cradlePreviewDot'),status=$('cradlePreviewStatus');if(!dot||!status)return;const live=bleOnline&&bleState==='connected'&&previewSample&&performance.now()-previewTime<1500;dot.style.opacity=live?'1':'.25';if(!live){status.textContent='No live movement data. Select and connect a Cradle.';return;}if(!previewCentre)previewCentre={...previewSample};const delta=(a,b)=>((a-b+540)%360)-180;const x=Math.max(-1,Math.min(1,delta(previewSample.roll,previewCentre.roll)/20)),y=Math.max(-1,Math.min(1,-delta(previewSample.pitch,previewCentre.pitch)/20));dot.style.left=(50+x*40)+'%';dot.style.top=(50+y*40)+'%';status.textContent='Live · '+cradleRotation+'° · tilt left/right and forward/back to check.';}
  function rotateCradle(){if(rotationPending||!bleOnline)return;rotationPending=true;if(!sendBle({cmd:'setOrientation',rotation:(cradleRotation+90)%360})){rotationPending=false;notice='Could not reach the sensor service.';noticeError=true;}render();}
  const title=s=>s.charAt(0).toUpperCase()+s.slice(1);
  const defs={
    plankz:{name:'PLANKZ',fields:[['difficulty','Default difficulty',['easy','medium','hard'],'easy','Players can change this before starting.'],['theme','Game theme',STYLES,'performance','Appearance only; balance scoring is unchanged.']]},
    beepz:{name:'BEEPZ',fields:[['cycles','Cycles',Array.from({length:20},(_,i)=>i+1),3],['reps','Repetitions',Array.from({length:50},(_,i)=>i+1),4],['breakSeconds','Rest between cycles (seconds)',Array.from({length:61},(_,i)=>i*5),30],['hold','Target hold (seconds)',[5,10,15],5],['theme','Game theme',STYLES,'performance']]},
    tenz:{name:'TENZ',fields:[['range','Sensor range (degrees)',Array.from({length:43},(_,i)=>i+3),12],['theme','Game theme',STYLES,'performance']]},
    timez:{name:'Workout TimeZ',fields:[['work','Work duration (seconds)',[30,60,90,120,150,180],90],['rest','Rest duration (seconds)',[5,10,15,20,25,30,60],10],['rounds','Rounds',[3,6,9,12,18,21,24],12],['theme','Game theme',STYLES,'performance']]}
  };
  const rangeOptions=Array.from({length:43},(_,i)=>i+3);
  const rangeHelp='Tilt sensitivity, not Bluetooth distance. Lower = smaller movements; higher = more tilt. Independent for this game. Applies after reopening the game.';
  for(const [id,d] of Object.entries(defs)){
    d.fields=d.fields.filter(f=>f[0]!=='range');
    const help=rangeHelp+(id==='timez'?' Controls only the Cradle navigation cursor; workout times are unchanged.':'');
    d.fields.splice(id==='plankz'?1:0,0,['rangeX','Horizontal sensor range (degrees)',rangeOptions,id==='timez'?18:12,'Left / right. '+help],['rangeY','Vertical sensor range (degrees)',rangeOptions,id==='timez'?18:12,'Forward / back (up / down on screen). '+help]);
  }
  function getValue(id,f){const x=config.games[id]?.[f[0]];if(f[2].includes(x))return x;if(['rangeX','rangeY'].includes(f[0])){const old=config.games[id]?.range;if(f[2].includes(old))return old;if(['plankz','beepz'].includes(id)){try{const legacy=JSON.parse(localStorage.getItem(id+'_settings')||'{}').range;if(f[2].includes(legacy))return legacy;}catch{}}}return f[0]==='theme'?config.style:f[3];}
  function save(){try{localStorage.setItem(KEY,JSON.stringify(config));notice='Saved on this Pi. Applies the next time the game opens.';noticeError=false;return true;}catch{notice='Could not save configuration. Check available browser storage.';noticeError=true;return false;}}
  function style(){document.body.dataset.stationStyle=config.style;}
  const root=document.createElement('main');root.id='stationRoot';
  root.innerHTML='<header class="station-top"><div class="station-brand">CORZ<span>STATION</span></div></header><div class="station-titlebar"><div><div id="stationEyebrow" class="station-eyebrow"></div><h1 id="stationTitle"></h1><p id="stationSubtitle"></p></div><button class="station-back" id="stationBack" tabindex="-1">← Back</button></div><section id="stationBody"></section><div id="stationNotice" role="status" aria-live="polite"></div><footer class="station-footer"><div id="stationHints"></div><div class="station-footer-actions" id="stationActions"></div></footer>';
  document.body.append(root);
  const head=root.querySelector('.station-top');for(const id of ['connectivityBar','currentProfileBadge','clock']){const e=document.getElementById(id);if(e)head.append(e);}
  const cradleBadge=document.createElement('span');cradleBadge.id='stationCradle';cradleBadge.textContent='Cradle: checking…';cradleBadge.setAttribute('aria-label','Cradle connection');head.insertBefore(cradleBadge,document.getElementById('currentProfileBadge'));
  const $=id=>document.getElementById(id);
  $('currentProfileBadge').tabIndex=-1;
  $('stationBack').onclick=back;
  function card(label,description,status,symbol,action,extra={}){return{label,description,status,symbol,action,...extra};}
  function go(next,index=0){if(!['home','programs'].includes(next)&&hasPin()&&!staffUnlocked){beginPin('unlock',()=>go(next,index));return;}if(['home','programs'].includes(next))staffUnlocked=false;page=next;focusIndex=index;notice='';noticeError=false;revision++;render();if(['api','diagnostics','updates','setup'].includes(next))refreshStatus();if(next==='controller')sendBle({cmd:'getDevices'});}
  function back(){if(page==='pin-entry'){cancelPin();return;}if(page==='home')return;if(page==='game'){go('programAdmin');return;}if(['config','programs'].includes(page)){go('home',page==='programs'?1:0);return;}go('config');}
  function profile(){openProfileHub();}
  function launch(g){selected=GAMES.indexOf(g);update();launchGame(g);}
  const gameCards=()=>GAMES.filter(g=>g.available&&!['halloffame','calibration'].includes(g.id.toLowerCase())).map(g=>card(g.id==='TimeZ'?'TIMEZ':g.title.replace(' Balance',''),g.desc.replace(' BLE plate or mouse simulation.',''),'Ready to play',({plankz:'▱',beepz:'⌁',tenz:'◎',TimeZ:'◷'})[g.id]||'◇',()=>launch(g),{icon:g.icon}));
  function render(){
    style();items=[];let heading='',sub='',eyebrow='CORZ Station',layout='station-grid',note='';
    const controllerSummary=bleOnline?(bleState==='connected'?'Connected · '+(bleName||'CORZ Cradle'):bleState==='connecting'?'Connecting · '+(bleName||selectedName):bleState==='disconnecting'?'Disconnecting Cradle…':'Not connected · select a Cradle'):'Bridge unavailable';
    if(page==='home'){
      heading='Your station. Your session.';sub='Select a program to get moving, or open staff configuration.';layout+=' landing';
      items=[card('Configuration','Station connections, game defaults and appearance.',hasPin()?'PIN PROTECTED':'STAFF SETTINGS',hasPin()?'🔒':'⚙',()=>go('config')),card('Select program','Choose your next challenge. Scan your NFC tag for your player profile.','LET’S MOVE','▶',()=>go('programs'))];
    }else if(page==='programs'){
      eyebrow='Select a program';heading='Play programs';sub='Use the remote: Left / Right to choose. Press OK to start.';layout+=' programs';items=gameCards();
    }else if(page==='config'){
      eyebrow='Staff configuration';heading='Configuration';sub='Settings for this station. No desktop or display configuration required.';
      items=[card('Setup check','Live station readiness and selected Cradle.','CHECK STATUS','☑',()=>go('setup')),card('Wi-Fi','Use the existing station network controls.','NETWORK','⌁',()=>{openSettings();}),card('Controller','Choose the numbered CORZ Cradle belonging to this station.',controllerSummary,'♧',()=>go('controller')),card('Program admin','Starting values and a theme for each game.','4 PROGRAMS','☷',()=>go('programAdmin')),card('API connector','OurCorz connection and result-upload status.','EXISTING CONNECTION','↗',()=>go('api')),card('Software update','Installed release and the existing GitHub updater status.','PACKAGE UPDATES','↓',()=>go('updates')),card('Player profile','View the selected NFC player and server statistics.',currentProfile?.display_name||'TAP NFC TAG','○',profile),card('Diagnostics','Cradle bridge, NFC reader and API readiness.','LIVE STATUS','⌕',()=>go('diagnostics')),card('Style','Choose the dashboard design direction.',title(config.style),'◐',()=>go('style'))];
    }else if(page==='pinSettings'){
      eyebrow='Configuration';heading='Configuration PIN';sub='Optional four-arrow staff PIN. Up = 1, Right = 2, Down = 3, Left = 4. Entry is always masked.';
      note=hasPin()?'PIN protection is enabled. Returning to the dashboard locks Configuration again. This is a local staff-access lock, not encryption of the Pi or its files.':'No PIN is set. Configuration remains open until you create and confirm an arrow sequence.';
      items=[card(hasPin()?'Change PIN':'Create PIN','Enter four arrows, then repeat them to confirm.',hasPin()?'CHANGE':'SET PIN','🔒',()=>beginPin('new'))];
      if(hasPin())items.push(card('Remove PIN','Confirm the current arrow PIN to remove protection.','REMOVE','○',()=>beginPin('remove')),card('Lock Configuration now','Return to the dashboard. The PIN will be required to enter again.','LOCK','🔒',()=>go('home',0)));
    }else if(page==='pin-entry'){
      eyebrow='Staff access';heading=pinMode==='unlock'?'Unlock Configuration':pinMode==='new'?'Create your arrow PIN':pinMode==='confirm'?'Confirm your arrow PIN':'Remove PIN protection';
      sub='Enter four arrow presses. OK confirms. HOME / BACK cancels. Only stars are shown.';layout='station-list';
      items=[card(pinBusy?'Please wait…':'Confirm','Press OK after entering the sequence.',pinBusy?'CHECKING':'OK',null,submitPin,{disabled:pinBusy}),card('Clear entry','Start this entry again.','CLEAR',null,()=>{pinEntry='';notice='';render();},{disabled:pinBusy}),card('Cancel','Do not change or unlock anything.','BACK',null,cancelPin)];
    }else if(page==='programAdmin'){
      eyebrow='Configuration';heading='Program admin';sub='Set the starting values for the next session. Players can still adjust supported settings before a run.';
      items=Object.entries(defs).map(([id,d])=>card(d.name,d.fields.filter(f=>f[0]!=='theme').map(f=>f[1]+': '+getValue(id,f)).join(' · '),title(getValue(id,d.fields.find(f=>f[0]==='theme'))),'◇',()=>{editGame=id;go('game');}));
    }else if(page==='navigation'){
      eyebrow='Configuration';heading='Game navigation';sub='Set how long to hold the Cradle cursor at an edge. Left / Right or OK changes the value. Saved automatically for the next game launch.';layout='station-list';
      items=[card('Edge hold time','Applies to all four edges in PLANKZ, BEEPZ, TENZ and Workout TimeZ. The glowing countdown follows this duration.',config.navigation.edgeHoldSeconds+' seconds',null,()=>changeEdgeHold(1),{change:delta=>changeEdgeHold(delta)})];
    }else if(page==='game'){
      const d=defs[editGame];eyebrow='Program admin';heading=d.name;sub='Left / Right changes a value. OK advances it. Saved automatically on this Pi.';layout='station-list';
      items=d.fields.map(f=>card(f[1],f[4]||'Default for new sessions.',String(getValue(editGame,f)),null,()=>changeField(f,1),{change:delta=>changeField(f,delta)}));
    }else if(page==='style'){
      eyebrow='Configuration';heading='Station style';sub='Choose a design direction. Existing game themes stay as configured in Program admin.';
      const desc={performance:'High-contrast dark panels with lime highlights.',console:'Soft violet, clear panels and clean type.',tron:'Cyan light, fine grid and technical typography.',rebel:'Warm orange highlights with bold dark panels.'};
      items=STYLES.map(s=>card(title(s),desc[s],config.style===s?'ACTIVE':'PREVIEW & APPLY','◐',()=>{const old=config.style;config.style=s;if(!save())config.style=old;render();}));
    }else if(page==='controller'){
      eyebrow='Configuration';heading='Connect your Cradle';sub='Turn on your CORZ device, then scan. Select the exact device number for this station.';layout='station-list';
      note='Connection: '+controllerSummary+'\nLast selected: '+(selectedName||selectedAddress||'None')+'\nManual connection only. Scanning never connects a Cradle. After a restart or disconnection, scan and select a device again. You can switch devices without turning the old one off.';
      items=[card(scanning?'Scanning for CORZ devices…':'Find CORZ devices','Lists nearby devices only. Choose the exact number, then press OK to connect.',scanning?'SCANNING':'SCAN',null,scan,{disabled:scanning||!bleOnline})];
      items.push(card('Rotate +90°','Clockwise movement rotation. Saved for PLANKZ, BEEPZ and TENZ.',rotationPending?'SAVING…':cradleRotation+'°',null,rotateCradle,{disabled:rotationPending||!bleOnline}));
      items.push(card('Centre preview','Leave the Cradle level, then press OK. This centres only this preview; gameplay calibration is unchanged.','CENTRE',null,()=>{previewCentre=previewSample?{...previewSample}:null;updatePreview();},{disabled:!bleOnline||bleState!=='connected'}));
      if(bleState==='connected'||bleState==='connecting')items.push(card('Disconnect Cradle','Release the current Cradle without turning it off. No automatic reconnection.','DISCONNECT',null,disconnectDevice,{disabled:!bleOnline}));
      for(const d of devices)items.push(card(d.name,d.address,d.address===selectedAddress&&bleState==='connected'?'CONNECTED':d.address===selectedAddress?'LAST SELECTED · CONNECT':'SELECT & CONNECT',null,()=>selectDevice(d),{disabled:scanning}));
      if(!devices.length)note+='\n'+(scanning?'Looking for nearby CORZ_ devices…':'No scan results yet. Press Find CORZ devices.');
      if(bleError)note+='\n'+bleError;
    }else if(page==='api'){
      eyebrow='Configuration';heading='API connector';sub='Uses the existing configured API key. Keys and server endpoints are not changed here.';layout='station-list';
      note='Server: '+(bridgeStatus?.upstream||'Waiting for the local API bridge…')+'\nAPI key: '+(bridgeStatus?bridgeStatus.configured?'Configured':'Not configured':'Checking…')+'\nResult upload support: '+(bridgeStatus?bridgeStatus.scoreWriteSupported?'Available for PLANKZ, BEEPZ and TENZ':'Unavailable':'Checking…')+'\nPlayer: '+(currentProfile?.display_name||'No player selected — tap a registered NFC tag')+'\nLast upload: '+lastUpload();
      items=[card('Refresh connection status','Reads local bridge status; does not create a score.','READ ONLY',null,refreshStatus),card('Player statistics','Read the current profile and game history.','OPEN',null,profile)];
    }else if(page==='updates'){
      eyebrow='Configuration';heading='Software update';sub='Keep publishing the matching package.zip and update.json to your existing GitHub location.';layout='station-list';
      note='Installed dashboard: '+(release?.version||bridgeStatus?.bridgeBuild||'Checking…')+'\nUpdater: '+(updater?.status||updater?.state||'Status unavailable')+'\n'+(updater?.message||'Updates are checked by your existing updater during station startup.')+(updater?.error?'\nLast updater error: '+updater.error:'')+'\nNo new setup script, desktop setting or service installation is required.';
      items=[card('Refresh status','Read the installed release and updater status.','REFRESH',null,refreshStatus)];
    }else if(page==='diagnostics'||page==='setup'){
      eyebrow='Configuration';heading=page==='setup'?'Station readiness':'Diagnostics';sub='Live connection checks. No calibration, API write or hardware configuration is performed here.';layout='station-list';
      note='BLE bridge: '+(bleOnline?'Online':'Unavailable')+'\nCradle: '+controllerSummary+'\nLast selected Cradle: '+(selectedName||'None')+'\nConnection mode: Manual only (no auto-connect or auto-reconnect)'+'\nNFC reader: '+(bridgeStatus?.nfc?.readerStatus|| (bridgeStatus?.serialConnected?'Connected':'Not available'))+'\nNFC API lookup: '+(bridgeStatus?.nfc?.lookupRunning?'Running':'Idle')+'\nAPI key: '+(bridgeStatus?bridgeStatus.configured?'Configured':'Missing':'Checking…')+'\nScore upload support: '+(bridgeStatus?.scoreWriteSupported?'Available':'Not available')+'\nInstalled build: '+(release?.version||bridgeStatus?.bridgeBuild||'Checking…');
      items=[card('Refresh checks','Read current station status.','REFRESH',null,refreshStatus),card('Select Cradle','Assign the CORZ device for this station.','CONTROLLER',null,()=>go('controller'))];
    }
    if(page==='config')items.splice(4,0,card('Game navigation','Cradle edge activation time for every game.',config.navigation.edgeHoldSeconds+' SECOND HOLD','◷',()=>go('navigation')));
    if(page==='config')items.push(card('Configuration PIN','Optional arrow-sequence protection for staff settings.',hasPin()?'ENABLED':'NO PIN','🔒',()=>go('pinSettings')));
    $('stationEyebrow').textContent=eyebrow;$('stationTitle').textContent=heading;$('stationSubtitle').textContent=sub;
    $('stationBack').hidden=page==='home';
    $('stationBody').innerHTML=(note?'<div class="station-note">'+esc(note)+'</div>':'')+'<div class="'+layout+'">'+items.map((c,i)=>'<button type="button" class="station-card" data-item="'+i+'" tabindex="-1" '+(c.disabled?'disabled':'')+'>'+(c.icon?'<img class="station-game-icon" src="'+esc(c.icon)+'" alt="">':c.symbol?'<span class="symbol" aria-hidden="true">'+esc(c.symbol)+'</span>':'')+'<strong>'+esc(c.label)+'</strong><span class="description">'+esc(c.description)+'</span><span class="status">'+esc(c.status)+'</span></button>').join('')+'</div>';
    if(page==='pin-entry')$('stationBody').insertAdjacentHTML('afterbegin','<div class="station-pin-mask" role="status" aria-label="Masked PIN entry">'+Array.from({length:4},(_,i)=>'<span>'+(i<pinEntry.length?'*':'·')+'</span>').join('')+'</div>');
    $('stationActions').innerHTML=page==='programs'?'<button data-extra="hall" tabindex="-1">Hall of Fame</button><button data-extra="profile" tabindex="-1">Player profile</button>':page==='home'?'<button data-extra="profile" tabindex="-1">Player profile</button>':'';
    root.querySelector('.cradle-preview')?.remove();
    if(page==='controller'){$('stationBody').insertAdjacentHTML('beforebegin',rotationView());updatePreview();}
    root.querySelectorAll('[data-item]').forEach(b=>{b.onclick=()=>{focusIndex=Number(b.dataset.item);activate();};});
    root.querySelectorAll('[data-extra]').forEach(b=>{b.onclick=()=>{if(b.dataset.extra==='hall')launch(GAMES.find(g=>g.id==='halloffame'));else profile();};});
    $('stationHints').innerHTML=['game','navigation'].includes(page)?'<b>↑ ↓</b> Select setting &nbsp; <b>← → / OK</b> Change &nbsp; <b>HOME / BACK</b> Return':'<b>← → ↑ ↓</b> Navigate &nbsp; <b>OK</b> Select &nbsp; <b>HOME / BACK</b> Return';
    if(page==='pin-entry')$('stationHints').innerHTML='<b>↑ → ↓ ←</b> Enter PIN &nbsp; <b>OK</b> Confirm &nbsp; <b>HOME / BACK</b> Cancel';
    if(!bleOnline&&page==='controller'&&!notice){notice='BLE bridge unavailable. Waiting to reconnect…';noticeError=true;}
    $('stationNotice').textContent=notice;$('stationNotice').classList.toggle('error',noticeError);highlight(false);
  }
  function buttons(){return[...$('stationBody').querySelectorAll('[data-item]'),...$('stationActions').querySelectorAll('button')];}
  function highlight(scroll=true){const bs=buttons();focusIndex=Math.max(0,Math.min(focusIndex,bs.length-1));bs.forEach((b,i)=>{b.classList.toggle('selected',i===focusIndex);b.setAttribute('aria-current',i===focusIndex?'true':'false');});if(scroll)bs[focusIndex]?.scrollIntoView({block:'nearest',inline:'nearest'});}
  function activate(){const bs=buttons(),b=bs[focusIndex];if(!b||b.disabled)return;if(b.dataset.item!==undefined)items[Number(b.dataset.item)]?.action();else b.click();}
  function changeField(f,delta){const old=structuredClone(config),arr=f[2],v=getValue(editGame,f);config.games[editGame]={...config.games[editGame],[f[0]]:arr[(arr.indexOf(v)+delta+arr.length)%arr.length]};if(!save())config=old;render();}
  function changeEdgeHold(delta){const old=config.navigation.edgeHoldSeconds;config.navigation.edgeHoldSeconds=EDGE_HOLD_TIMES[(EDGE_HOLD_TIMES.indexOf(old)+delta+EDGE_HOLD_TIMES.length)%EDGE_HOLD_TIMES.length];if(!save())config.navigation.edgeHoldSeconds=old;render();}
  function key(k){if(page==='pin-entry'){if(['Backspace','Escape','Home','BrowserHome','BrowserBack'].includes(k)){cancelPin();return;}if(pinBusy)return;if(k==='Enter'){submitPin();return;}if(pinDigits[k]){if(Date.now()<pinBlockedUntil){notice='Too many attempts. Wait a moment before trying again.';noticeError=true;}else if(pinEntry.length<4){pinEntry+=pinDigits[k];notice='';noticeError=false;}render();}return;}if(k==='Backspace'){back();return;}if(k==='Enter'){activate();return;}if(!k.startsWith('Arrow'))return;
    if(['game','navigation'].includes(page)&&(k==='ArrowLeft'||k==='ArrowRight')){items[focusIndex]?.change?.(k==='ArrowRight'?1:-1);return;}
    const n=buttons().length;if(!n)return;let step=1;if(k==='ArrowUp'||k==='ArrowDown'){const grid=$('stationBody').querySelector('.station-grid');step=grid?getComputedStyle(grid).gridTemplateColumns.split(' ').length:1;}
    if(k==='ArrowLeft'||k==='ArrowUp')step=-step;
    focusIndex=(focusIndex+step+n)%n;highlight();
  }
  const oldInput=handleArcadeInput;
  handleArcadeInput=function(k){if(window.CorzPowerUi?.isOpen()||profileOpen||stgOpen||overlay.style.display==='block'){oldInput(k);return;}key(k);};
  // Existing Wi-Fi remains functional and returns to Configuration, not the old carousel.
  const oldClose=closeSettings;closeSettings=function(){oldClose();go('config',1);};
  const oldOpenSettings=openSettings;openSettings=function(){if(hasPin()&&!staffUnlocked){beginPin('unlock',()=>oldOpenSettings());return;}oldOpenSettings();};
  const oldOpenGame=openGame;openGame=function(url){document.body.classList.add('station-game-open');oldOpenGame(url);};
  const oldCloseGame=closeGame;closeGame=function(){oldCloseGame();document.body.classList.remove('station-game-open');};
  function lastUpload(){const r=bridgeStatus?.lastResult;if(!r)return'None reported';return r.status||r.message||(r.error?'Error: '+r.error:'See game result screen');}
  async function json(url){const r=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(7000)});if(!r.ok)throw Error('HTTP '+r.status);return r.json();}
  let refreshRunning=false;
  async function refreshStatus(){if(refreshRunning)return;refreshRunning=true;const p=page,rev=revision;let failed=false;
    await Promise.all([json(PROFILE_API+'/status').then(x=>bridgeStatus=x).catch(()=>{bridgeStatus=null;failed=true;}),json('update-release.json').then(x=>release=x).catch(()=>{}),json('http://localhost:8081/api/status').then(x=>updater=x).catch(()=>updater=null)]);
    refreshRunning=false;if(page===p&&revision===rev){notice=failed?'Local API bridge unavailable. Check Diagnostics and the station services.':'Status refreshed. No scores were submitted.';noticeError=failed;render();}
  }
  function sendBle(obj){if(bleSocket?.readyState!==WebSocket.OPEN){bleError='BLE bridge is not connected.';return false;}bleSocket.send(JSON.stringify(obj));return true;}
  function scan(){if(scanning||!bleOnline)return;scanning=true;bleError='';devices=[];notice='Looking for nearby CORZ devices…';noticeError=false;sendBle({cmd:'scanDevices',requestId:++requestId});clearTimeout(scanTimer);scanTimer=setTimeout(()=>{if(scanning){scanning=false;bleError='Scan timed out. Try again or check the BLE service.';if(page==='controller')render();}},20000);render();}
  function selectDevice(d){if(!confirmSelection(d))return;notice='Connecting to '+d.name+'…';noticeError=false;bleError='';sendBle({cmd:'selectDevice',address:d.address,requestId:++requestId});render();}
  function disconnectDevice(){notice='Disconnecting Cradle…';noticeError=false;bleError='';sendBle({cmd:'disconnectDevice',requestId:++requestId});render();}
  // OK on an explicit numbered device is the confirmation; no mouse-only dialog.
  function confirmSelection(d){return typeof d.address==='string'&&devices.some(x=>x.address===d.address);}
  function bleConnect(){clearTimeout(bleTimer);try{
    bleSocket=new WebSocket('ws://localhost:8765');
    bleSocket.onopen=()=>{bleOnline=true;bleError='';sendBle({cmd:'getDevices'});if(page==='controller')render();};
    bleSocket.onmessage=e=>{try{const d=JSON.parse(e.data);if(d.type==='data'){if(Number.isFinite(d.roll)&&Number.isFinite(d.pitch)){previewSample={roll:d.roll,pitch:d.pitch};previewTime=performance.now();if(page==='controller')updatePreview();}const b=Number(d.battery);cradleBadge.textContent=(bleName||'Cradle')+(Number.isFinite(b)?' · '+Math.max(0,Math.min(100,Math.round(b)))+'%':'');return;}
      if(d.type==='status'||d.type==='orientation'){if([0,90,180,270].includes(d.rotation)){if(cradleRotation!==d.rotation){previewCentre=null;previewSample=null;previewTime=0;}cradleRotation=d.rotation;}if(d.type==='orientation'){rotationPending=false;notice='Orientation saved: '+cradleRotation+'°. Applies to all balance games.';noticeError=false;}}
      if(d.type==='status'){if(d.status!=='connected'||bleName!==(d.deviceName||'')){previewSample=null;previewCentre=null;previewTime=0;}bleState=d.status;bleName=d.deviceName||'';if(d.selectedAddress!==undefined)selectedAddress=d.selectedAddress;if(d.selectedName!==undefined)selectedName=d.selectedName||'';cradleBadge.textContent=bleState==='connected'?(bleName||'Cradle connected'):'Cradle: '+bleState;if(d.selectionError)bleError=d.selectionError;}
      if(d.type==='devices'){devices=Array.isArray(d.devices)?d.devices.filter(x=>typeof x.name==='string'&&x.name.startsWith('CORZ_')&&typeof x.address==='string'):[];if(d.selectedAddress!==undefined)selectedAddress=d.selectedAddress;if(d.selectedName!==undefined)selectedName=d.selectedName||'';if(d.scanning!==undefined)scanning=!!d.scanning;else scanning=false;if(!scanning){clearTimeout(scanTimer);notice=devices.length?'Choose the exact numbered Cradle for this station.':'No advertising CORZ devices found. Wake the device and scan again.';noticeError=false;}}
      if(d.type==='selection'){selectedAddress=d.selectedAddress??d.address??selectedAddress;selectedName=d.selectedName||d.deviceName||d.name||selectedName;notice='Connection requested for '+(selectedName||selectedAddress)+'. Wait for Connected before starting a game.';noticeError=false;}
      if(d.type==='disconnection'){notice='Cradle disconnected. Scan and select a device when you want to connect.';noticeError=false;}
      if(d.type==='error'){rotationPending=false;scanning=false;clearTimeout(scanTimer);bleError=d.message||d.error||'BLE operation failed.';notice=bleError;noticeError=true;}
      if(['controller','config','diagnostics','setup'].includes(page))render();
    }catch{}};
    bleSocket.onclose=()=>{rotationPending=false;previewSample=null;previewCentre=null;bleOnline=false;bleState='unavailable';cradleBadge.textContent='Cradle: bridge offline';scanning=false;clearTimeout(scanTimer);if(['controller','config','diagnostics','setup'].includes(page))render();bleTimer=setTimeout(bleConnect,3000);};bleSocket.onerror=()=>{};
  }catch{bleOnline=false;bleTimer=setTimeout(bleConnect,3000);}}
  // Read-only introspection for diagnostics and automated regression checks.
  window.CorzStation={get page(){return page;},get config(){return structuredClone(config);},get selection(){return{selectedName,selectedAddress,bleState,bleOnline};},open:go,key};
  style();render();bleConnect();
  setInterval(()=>{if(page==='controller')updatePreview();},500);
})();
