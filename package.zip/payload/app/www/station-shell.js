/* CORZ Station — package-managed UI. Keeps existing game/NFC/API/power services. */
(() => {
  'use strict';
  const KEY='corz_station_config_v1', STYLES=['performance','console','tron','rebel'];
  let config={style:'performance',games:{}}, storageError='';
  try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))config={...config,...saved,games:saved.games&&typeof saved.games==='object'?saved.games:{}};}catch{storageError='Saved configuration could not be read. Changes will need to be saved again.';}
  if(!STYLES.includes(config.style))config.style='performance';
  let page='home',focusIndex=1,items=[],notice=storageError,noticeError=!!storageError,editGame=null,revision=0;
  let bridgeStatus=null,release=null,updater=null,bleSocket=null,bleTimer=null,bleOnline=false,bleState='unavailable',bleName='',selectedName='',selectedAddress=null,devices=[],scanning=false,scanTimer=null,bleError='',requestId=0;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const title=s=>s.charAt(0).toUpperCase()+s.slice(1);
  const defs={
    plankz:{name:'PLANKZ',fields:[['difficulty','Default difficulty',['easy','medium','hard'],'easy','Players can change this before starting.'],['theme','Game theme',STYLES,'performance','Appearance only; balance scoring is unchanged.']]},
    beepz:{name:'BEEPZ',fields:[['cycles','Cycles',Array.from({length:20},(_,i)=>i+1),3],['reps','Repetitions',Array.from({length:50},(_,i)=>i+1),4],['breakSeconds','Rest between cycles (seconds)',Array.from({length:61},(_,i)=>i*5),30],['hold','Target hold (seconds)',[5,10,15],5],['theme','Game theme',STYLES,'performance']]},
    tenz:{name:'TENZ',fields:[['range','Sensor range (degrees)',Array.from({length:43},(_,i)=>i+3),12],['theme','Game theme',STYLES,'performance']]},
    liftz:{name:'LIFTZ',fields:[['axis','Observed axis',['roll','pitch'],'roll'],['duration','Recording time (seconds)',Array.from({length:30},(_,i)=>i+1),5],['tolerance','Balanced limit (degrees)',[.1,.5,1,1.5,2,2.5,3,4,5,7.5,10,15],2],['theme','Game theme',STYLES,'performance']]},
    timez:{name:'Workout TimeZ',fields:[['work','Work duration (seconds)',[30,60,90,120,150,180],90],['rest','Rest duration (seconds)',[5,10,15,20,25,30,60],10],['rounds','Rounds',[3,6,9,12,18,21,24],12],['theme','Game theme',STYLES,'performance']]}
  };
  function getValue(id,f){const x=config.games[id]?.[f[0]];return f[2].includes(x)?x:(f[0]==='theme'?config.style:f[3]);}
  function save(){try{localStorage.setItem(KEY,JSON.stringify(config));notice='Saved on this Pi. Applies the next time the game opens.';noticeError=false;return true;}catch{notice='Could not save configuration. Check available browser storage.';noticeError=true;return false;}}
  function style(){document.body.dataset.stationStyle=config.style;}
  const root=document.createElement('main');root.id='stationRoot';
  root.innerHTML='<header class="station-top"><div class="station-brand">CORZ<span>STATION</span></div></header><div class="station-titlebar"><div><div id="stationEyebrow" class="station-eyebrow"></div><h1 id="stationTitle"></h1><p id="stationSubtitle"></p></div><button class="station-back" id="stationBack" tabindex="-1">← Back</button></div><section id="stationBody"></section><div id="stationNotice" role="status" aria-live="polite"></div><footer class="station-footer"><div id="stationHints"></div><div class="station-footer-actions" id="stationActions"></div></footer>';
  document.body.append(root);
  const head=root.querySelector('.station-top');for(const id of ['connectivityBar','currentProfileBadge','clock']){const e=document.getElementById(id);if(e)head.append(e);}
  const cradleBadge=document.createElement('span');cradleBadge.id='stationCradle';cradleBadge.textContent='Cradle: checking…';cradleBadge.setAttribute('aria-label','Cradle connection');head.insertBefore(cradleBadge,document.getElementById('currentProfileBadge'));
  const $=id=>document.getElementById(id);
  $('currentProfileBadge').tabIndex=-1;
  $('stationBack').onclick=back;
  function card(label,description,status,symbol,action,extra={}){return{label,description,status,symbol,action,...extra};}
  function go(next,index=0){page=next;focusIndex=index;notice='';noticeError=false;revision++;render();if(['api','diagnostics','updates','setup'].includes(next))refreshStatus();if(next==='controller')sendBle({cmd:'getDevices'});}
  function back(){if(page==='home')return;if(page==='game'){go('programAdmin');return;}if(['config','programs'].includes(page)){go('home',page==='programs'?1:0);return;}go('config');}
  function profile(){openProfileHub();}
  function launch(g){selected=GAMES.indexOf(g);update();launchGame(g);}
  const gameCards=()=>GAMES.filter(g=>g.available&&!['halloffame','calibration'].includes(g.id.toLowerCase())).map(g=>card(g.id==='TimeZ'?'TIMEZ':g.title.replace(' Balance',''),g.desc.replace(' BLE plate or mouse simulation.',''),'Ready to play',({plankz:'▱',beepz:'⌁',tenz:'◎',liftz:'↥',TimeZ:'◷'})[g.id]||'◇',()=>launch(g),{icon:g.icon}));
  function render(){
    style();items=[];let heading='',sub='',eyebrow='CORZ Station',layout='station-grid',note='';
    const controllerSummary=bleOnline?(bleState==='connected'?'Connected · '+(bleName||'CORZ Cradle'):bleState==='connecting'?'Connecting · '+(bleName||selectedName):selectedName?'Waiting · '+selectedName:'Choose a Cradle'):'Bridge unavailable';
    if(page==='home'){
      heading='Your station. Your session.';sub='Select a program to get moving, or open staff configuration.';layout+=' landing';
      items=[card('Configuration','Station connections, game defaults and appearance.','STAFF SETTINGS','⚙',()=>go('config')),card('Select program','Choose your next challenge. Scan your NFC tag for your player profile.','LET’S MOVE','▶',()=>go('programs'))];
    }else if(page==='programs'){
      eyebrow='Select a program';heading='Play programs';sub='Use the remote: Left / Right to choose. Press OK to start.';layout+=' programs';items=gameCards();
    }else if(page==='config'){
      eyebrow='Staff configuration';heading='Configuration';sub='Settings for this station. No desktop or display configuration required.';
      items=[card('Setup check','Live station readiness and selected Cradle.','CHECK STATUS','☑',()=>go('setup')),card('Wi-Fi','Use the existing station network controls.','NETWORK','⌁',()=>{openSettings();}),card('Controller','Choose the numbered CORZ Cradle belonging to this station.',controllerSummary,'♧',()=>go('controller')),card('Program admin','Starting values and a theme for each game.','5 PROGRAMS','☷',()=>go('programAdmin')),card('API connector','OurCorz connection and result-upload status.','EXISTING CONNECTION','↗',()=>go('api')),card('Software update','Installed release and the existing GitHub updater status.','PACKAGE UPDATES','↓',()=>go('updates')),card('Player profile','View the selected NFC player and server statistics.',currentProfile?.display_name||'TAP NFC TAG','○',profile),card('Diagnostics','Cradle bridge, NFC reader and API readiness.','LIVE STATUS','⌕',()=>go('diagnostics')),card('Style','Choose the dashboard design direction.',title(config.style),'◐',()=>go('style'))];
    }else if(page==='programAdmin'){
      eyebrow='Configuration';heading='Program admin';sub='Set the starting values for the next session. Players can still adjust supported settings before a run.';
      items=Object.entries(defs).map(([id,d])=>card(d.name,d.fields.filter(f=>f[0]!=='theme').map(f=>f[1]+': '+getValue(id,f)).join(' · '),title(getValue(id,d.fields.find(f=>f[0]==='theme'))),'◇',()=>{editGame=id;go('game');}));
    }else if(page==='game'){
      const d=defs[editGame];eyebrow='Program admin';heading=d.name;sub='Left / Right changes a value. OK advances it. Saved automatically on this Pi.';layout='station-list';
      items=d.fields.map(f=>card(f[1],f[4]||'Default for new sessions.',String(getValue(editGame,f)),null,()=>changeField(f,1),{change:delta=>changeField(f,delta)}));
    }else if(page==='style'){
      eyebrow='Configuration';heading='Station style';sub='Choose a design direction. Existing game themes stay as configured in Program admin.';
      const desc={performance:'High-contrast dark panels with lime highlights.',console:'Soft violet, clear panels and clean type.',tron:'Cyan light, fine grid and technical typography.',rebel:'Warm orange highlights with bold dark panels.'};
      items=STYLES.map(s=>card(title(s),desc[s],config.style===s?'ACTIVE':'PREVIEW & APPLY','◐',()=>{const old=config.style;config.style=s;if(!save())config.style=old;render();}));
    }else if(page==='controller'){
      eyebrow='Configuration';heading='Connect your Cradle';sub='Turn on your CORZ device, then scan. Select the exact device number for this station.';layout='station-list';
      note='Connection: '+controllerSummary+'\nSaved device: '+(selectedName||selectedAddress||'Automatic discovery (not assigned yet)')+'\nOnce assigned, this station reconnects only to that Cradle—even if other CORZ devices are nearby.';
      items=[card(scanning?'Scanning for CORZ devices…':'Find CORZ devices','Scanning may briefly interrupt a connection. Do this between sessions.',scanning?'SCANNING':'SCAN',null,scan,{disabled:scanning||!bleOnline})];
      for(const d of devices)items.push(card(d.name,d.address,d.address===selectedAddress?'ASSIGNED':'SELECT & CONNECT',null,()=>selectDevice(d),{disabled:scanning}));
      if(!devices.length)note+='\n'+(scanning?'Looking for nearby CORZ_ devices…':'No scan results yet. Press Find CORZ devices.');
      if(bleError)note+='\n'+bleError;
    }else if(page==='api'){
      eyebrow='Configuration';heading='API connector';sub='Uses the existing configured API key. Keys and server endpoints are not changed here.';layout='station-list';
      note='Server: '+(bridgeStatus?.upstream||'Waiting for the local API bridge…')+'\nAPI key: '+(bridgeStatus?bridgeStatus.configured?'Configured':'Not configured':'Checking…')+'\nResult upload support: '+(bridgeStatus?bridgeStatus.scoreWriteSupported?'Available for PLANKZ and BEEPZ':'Unavailable':'Checking…')+'\nPlayer: '+(currentProfile?.display_name||'No player selected — tap a registered NFC tag')+'\nLast upload: '+lastUpload();
      items=[card('Refresh connection status','Reads local bridge status; does not create a score.','READ ONLY',null,refreshStatus),card('Player statistics','Read the current profile and game history.','OPEN',null,profile)];
    }else if(page==='updates'){
      eyebrow='Configuration';heading='Software update';sub='Keep publishing the matching package.zip and update.json to your existing GitHub location.';layout='station-list';
      note='Installed dashboard: '+(release?.version||bridgeStatus?.bridgeBuild||'Checking…')+'\nUpdater: '+(updater?.status||updater?.state||'Status unavailable')+'\n'+(updater?.message||'Updates are checked by your existing updater during station startup.')+(updater?.error?'\nLast updater error: '+updater.error:'')+'\nNo new setup script, desktop setting or service installation is required.';
      items=[card('Refresh status','Read the installed release and updater status.','REFRESH',null,refreshStatus)];
    }else if(page==='diagnostics'||page==='setup'){
      eyebrow='Configuration';heading=page==='setup'?'Station readiness':'Diagnostics';sub='Live connection checks. No calibration, API write or hardware configuration is performed here.';layout='station-list';
      note='BLE bridge: '+(bleOnline?'Online':'Unavailable')+'\nCradle: '+controllerSummary+'\nAssigned Cradle: '+(selectedName||'Not assigned (legacy automatic connection)')+'\nNFC reader: '+(bridgeStatus?.nfc?.readerStatus|| (bridgeStatus?.serialConnected?'Connected':'Not available'))+'\nNFC API lookup: '+(bridgeStatus?.nfc?.lookupRunning?'Running':'Idle')+'\nAPI key: '+(bridgeStatus?bridgeStatus.configured?'Configured':'Missing':'Checking…')+'\nScore upload support: '+(bridgeStatus?.scoreWriteSupported?'Available':'Not available')+'\nInstalled build: '+(release?.version||bridgeStatus?.bridgeBuild||'Checking…');
      items=[card('Refresh checks','Read current station status.','REFRESH',null,refreshStatus),card('Select Cradle','Assign the CORZ device for this station.','CONTROLLER',null,()=>go('controller'))];
    }
    $('stationEyebrow').textContent=eyebrow;$('stationTitle').textContent=heading;$('stationSubtitle').textContent=sub;
    $('stationBack').hidden=page==='home';
    $('stationBody').innerHTML=(note?'<div class="station-note">'+esc(note)+'</div>':'')+'<div class="'+layout+'">'+items.map((c,i)=>'<button type="button" class="station-card" data-item="'+i+'" tabindex="-1" '+(c.disabled?'disabled':'')+'>'+(c.icon?'<img class="station-game-icon" src="'+esc(c.icon)+'" alt="">':c.symbol?'<span class="symbol" aria-hidden="true">'+esc(c.symbol)+'</span>':'')+'<strong>'+esc(c.label)+'</strong><span class="description">'+esc(c.description)+'</span><span class="status">'+esc(c.status)+'</span></button>').join('')+'</div>';
    $('stationActions').innerHTML=page==='programs'?'<button data-extra="hall" tabindex="-1">Hall of Fame</button><button data-extra="profile" tabindex="-1">Player profile</button>':page==='home'?'<button data-extra="profile" tabindex="-1">Player profile</button>':'';
    root.querySelectorAll('[data-item]').forEach(b=>{b.onclick=()=>{focusIndex=Number(b.dataset.item);activate();};});
    root.querySelectorAll('[data-extra]').forEach(b=>{b.onclick=()=>{if(b.dataset.extra==='hall')launch(GAMES.find(g=>g.id==='halloffame'));else profile();};});
    $('stationHints').innerHTML=page==='game'?'<b>↑ ↓</b> Select setting &nbsp; <b>← → / OK</b> Change &nbsp; <b>HOME / BACK</b> Return':'<b>← → ↑ ↓</b> Navigate &nbsp; <b>OK</b> Select &nbsp; <b>HOME / BACK</b> Return';
    if(!bleOnline&&page==='controller'&&!notice){notice='BLE bridge unavailable. Waiting to reconnect…';noticeError=true;}
    $('stationNotice').textContent=notice;$('stationNotice').classList.toggle('error',noticeError);highlight(false);
  }
  function buttons(){return[...$('stationBody').querySelectorAll('[data-item]'),...$('stationActions').querySelectorAll('button')];}
  function highlight(scroll=true){const bs=buttons();focusIndex=Math.max(0,Math.min(focusIndex,bs.length-1));bs.forEach((b,i)=>{b.classList.toggle('selected',i===focusIndex);b.setAttribute('aria-current',i===focusIndex?'true':'false');});if(scroll)bs[focusIndex]?.scrollIntoView({block:'nearest',inline:'nearest'});}
  function activate(){const bs=buttons(),b=bs[focusIndex];if(!b||b.disabled)return;if(b.dataset.item!==undefined)items[Number(b.dataset.item)]?.action();else b.click();}
  function changeField(f,delta){const old=structuredClone(config),arr=f[2],v=getValue(editGame,f);config.games[editGame]={...config.games[editGame],[f[0]]:arr[(arr.indexOf(v)+delta+arr.length)%arr.length]};if(!save())config=old;render();}
  function key(k){if(k==='Backspace'){back();return;}if(k==='Enter'){activate();return;}if(!k.startsWith('Arrow'))return;
    if(page==='game'&&(k==='ArrowLeft'||k==='ArrowRight')){items[focusIndex]?.change?.(k==='ArrowRight'?1:-1);return;}
    const n=buttons().length;if(!n)return;let step=1;if(k==='ArrowUp'||k==='ArrowDown'){const grid=$('stationBody').querySelector('.station-grid');step=grid?getComputedStyle(grid).gridTemplateColumns.split(' ').length:1;}
    if(k==='ArrowLeft'||k==='ArrowUp')step=-step;
    focusIndex=(focusIndex+step+n)%n;highlight();
  }
  const oldInput=handleArcadeInput;
  handleArcadeInput=function(k){if(window.CorzPowerUi?.isOpen()||profileOpen||stgOpen||overlay.style.display==='block'){oldInput(k);return;}key(k);};
  // Existing Wi-Fi remains functional and returns to Configuration, not the old carousel.
  const oldClose=closeSettings;closeSettings=function(){oldClose();go('config',1);};
  const oldOpenGame=openGame;openGame=function(url){document.body.classList.add('station-game-open');oldOpenGame(url);};
  const oldCloseGame=closeGame;closeGame=function(){oldCloseGame();document.body.classList.remove('station-game-open');};
  function lastUpload(){const r=bridgeStatus?.lastResult;if(!r)return'None reported';return r.status||r.message||(r.error?'Error: '+r.error:'See game result screen');}
  async function json(url){const r=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(7000)});if(!r.ok)throw Error('HTTP '+r.status);return r.json();}
  let refreshRunning=false;
  async function refreshStatus(){if(refreshRunning)return;refreshRunning=true;const p=page,rev=revision;let failed=false;
    await Promise.all([json(PROFILE_API+'/status').then(x=>bridgeStatus=x).catch(()=>{bridgeStatus=null;failed=true;}),json('update-release.json').then(x=>release=x).catch(()=>{}),json('http://localhost:8081/api/status').then(x=>updater=x).catch(()=>updater=null)]);
    refreshRunning=false;if(page===p&&revision===rev){notice=failed?'Local API bridge unavailable. Check Diagnostics and the station services.':'Status refreshed. No scores were submitted.';noticeError=failed;render();}
  }
  function sendBle(obj){if(bleSocket?.readyState!==WebSocket.OPEN){bleError='BLE bridge is not connected.';return false;}bleSocket.send(JSON.stringify(obj));return true;}
  function scan(){if(scanning||!bleOnline)return;scanning=true;bleError='';devices=[];notice='Looking for nearby CORZ devices…';noticeError=false;sendBle({cmd:'scanDevices',requestId:++requestId});clearTimeout(scanTimer);scanTimer=setTimeout(()=>{if(scanning){scanning=false;bleError='Scan timed out. Try again or check the BLE service.';if(page==='controller')render();}},20000);render();}
  function selectDevice(d){if(!confirmSelection(d))return;notice='Assigning '+d.name+' and connecting…';noticeError=false;bleError='';sendBle({cmd:'selectDevice',address:d.address,requestId:++requestId});render();}
  // OK on an explicit numbered device is the confirmation; no mouse-only dialog.
  function confirmSelection(d){return typeof d.address==='string'&&devices.some(x=>x.address===d.address);}
  function bleConnect(){clearTimeout(bleTimer);try{
    bleSocket=new WebSocket('ws://localhost:8765');
    bleSocket.onopen=()=>{bleOnline=true;bleError='';sendBle({cmd:'getDevices'});if(page==='controller')render();};
    bleSocket.onmessage=e=>{try{const d=JSON.parse(e.data);if(d.type==='data'){const b=Number(d.battery);cradleBadge.textContent=(bleName||'Cradle')+(Number.isFinite(b)?' · '+Math.max(0,Math.min(100,Math.round(b)))+'%':'');return;}
      if(d.type==='status'){bleState=d.status;bleName=d.deviceName||'';if(d.selectedAddress!==undefined)selectedAddress=d.selectedAddress;if(d.selectedName!==undefined)selectedName=d.selectedName||'';cradleBadge.textContent=bleState==='connected'?(bleName||'Cradle connected'):'Cradle: '+bleState;if(d.selectionError)bleError=d.selectionError;}
      if(d.type==='devices'){devices=Array.isArray(d.devices)?d.devices.filter(x=>typeof x.name==='string'&&x.name.startsWith('CORZ_')&&typeof x.address==='string'):[];if(d.selectedAddress!==undefined)selectedAddress=d.selectedAddress;if(d.selectedName!==undefined)selectedName=d.selectedName||'';if(d.scanning!==undefined)scanning=!!d.scanning;else scanning=false;if(!scanning){clearTimeout(scanTimer);notice=devices.length?'Choose the exact numbered Cradle for this station.':'No advertising CORZ devices found. Wake the device and scan again.';noticeError=false;}}
      if(d.type==='selection'){selectedAddress=d.selectedAddress??d.address??selectedAddress;selectedName=d.selectedName||d.deviceName||d.name||selectedName;notice='Cradle assignment saved. Connecting to '+(selectedName||selectedAddress)+'…';noticeError=false;}
      if(d.type==='error'){scanning=false;clearTimeout(scanTimer);bleError=d.message||d.error||'BLE operation failed.';notice=bleError;noticeError=true;}
      if(['controller','config','diagnostics','setup'].includes(page))render();
    }catch{}};
    bleSocket.onclose=()=>{bleOnline=false;bleState='unavailable';cradleBadge.textContent='Cradle: bridge offline';scanning=false;clearTimeout(scanTimer);if(['controller','config','diagnostics','setup'].includes(page))render();bleTimer=setTimeout(bleConnect,3000);};bleSocket.onerror=()=>{};
  }catch{bleOnline=false;bleTimer=setTimeout(bleConnect,3000);}}
  // Read-only introspection for diagnostics and automated regression checks.
  window.CorzStation={get page(){return page;},get config(){return structuredClone(config);},get selection(){return{selectedName,selectedAddress,bleState,bleOnline};},open:go,key};
  style();render();bleConnect();
})();
