/* Shared Pi/browser-origin neutral calibration. Sensor packets are already rotated
   by the bridge; store an unrotated neutral so changing orientation stays correct.
   Never scans, selects or connects a Bluetooth device. */
(() => {
  'use strict';
  const KEY='corz_cradle_neutral_v1', ROTATION='corz_cradle_rotation_v1';
  const validRotation=r=>[0,90,180,270].includes(r);
  let rotation=0, revision=0, device=null;
  try { const r=JSON.parse(localStorage.getItem(ROTATION));if(validRotation(r))rotation=r; } catch {}
  const delta=(a,b)=>((a-b+540)%360)-180;
  const rotate=(v,r)=>({0:{roll:v.roll,pitch:v.pitch},90:{roll:v.pitch,pitch:-v.roll},180:{roll:-v.roll,pitch:-v.pitch},270:{roll:-v.pitch,pitch:v.roll}}[r]);
  function get() {
    try { const v=JSON.parse(localStorage.getItem(KEY));
      if(v?.version===1&&v.device===device&&Number.isFinite(v.roll)&&Number.isFinite(v.pitch))return {...rotate(v,rotation),noise:Number.isFinite(v.noise)?v.noise:.02};
    } catch {}
    return {roll:0,pitch:0,noise:.02};
  }
  function observe(packet) {
    if(!['status','orientation'].includes(packet?.type))return false;
    let changed=false;
    if(packet.type==='status'&&packet.status==='connected') {
      const next=packet.deviceAddress||packet.selectedAddress||packet.deviceName||null;
      if(next!==device){device=next;changed=true;}
    }
    if(validRotation(packet.rotation)&&packet.rotation!==rotation){rotation=packet.rotation;changed=true;}
    if(!changed)return false;
    revision++;
    try {localStorage.setItem(ROTATION,JSON.stringify(rotation));}catch{}
    return true;
  }
  function measure(samples,startedRevision=revision) {
    if(startedRevision!==revision)throw Error('Orientation changed. Please calibrate again.');
    if(samples.length<20||samples.at(-1).t-samples[0].t<4300||performance.now()-samples.at(-1).t>=600||samples.some((s,i)=>!Number.isFinite(s.t)||!Number.isFinite(s.roll)||!Number.isFinite(s.pitch)||(i&&(s.t<samples[i-1].t||s.t-samples[i-1].t>=600))))throw Error('Not enough continuous, fresh sensor data.');
    const ref=samples[0],mean={};
    for(const k of ['roll','pitch']) {
      mean[k]=ref[k]+samples.reduce((sum,s)=>sum+delta(s[k],ref[k]),0)/samples.length;
      if(samples.some(s=>Math.abs(delta(s[k],mean[k]))>2))throw Error('Movement detected. Leave the Cradle sensor alone and still, then retry.');
    }
    return mean;
  }
  function save(samples,startedRevision=revision,noise) {
    const mean=measure(samples,startedRevision),canonical=rotate(mean,(360-rotation)%360);
    // Write atomically before publishing the new neutral; failed/cancelled samples
    // never replace the previous calibration or any game sensitivity settings.
    const previous=get();
    localStorage.setItem(KEY,JSON.stringify({version:1,...canonical,device,noise:noise??previous.noise,savedAt:new Date().toISOString()}));
    return {...mean,noise:noise??previous.noise};
  }
  window.CorzCalibration={get,observe,measure,save,delta,get rotation(){return rotation;},get revision(){return revision;}};
})();
