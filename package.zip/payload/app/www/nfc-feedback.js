(() => {
  'use strict';
  let signature = '', visibleUntil = 0;
  const $ = id => document.getElementById(id);
  function render(data) {
    const latest = data.latest || {};
    const busy = latest.status === 'loading';
    const ready = latest.status === 'ready';
    const error = latest.status === 'error';
    const summary = $('nfcSummary'), panel = $('nfcFeedback');
    const key = [latest.sequence, latest.status, latest.stage, latest.message].join('|');
    if (key !== signature) {
      signature = key;
      visibleUntil = Date.now() + (error ? 10000 : 6000);
    }
    summary.dataset.state = busy ? 'busy' : error || !data.serialConnected ? 'error' : ready ? 'ready' : 'idle';
    summary.textContent = busy ? (latest.stage === 'queued' ? 'NFC: tag detected' : 'NFC: API loading…')
      : !data.configured ? 'NFC: API key needed'
      : !data.serialConnected ? 'NFC: reader unavailable'
      : error ? 'NFC: lookup failed' : ready ? 'NFC: player loaded' : 'NFC: ready · tap tag';
    summary.title = data.serialError || latest.message || 'Reader connected. Waiting for a tag ID from the reader.';
    panel.hidden = !(busy || ((ready || error) && Date.now() < visibleUntil));
    panel.dataset.state = busy ? 'busy' : error ? 'error' : 'ready';
    if (busy) {
      const api = latest.stage !== 'queued';
      $('nfcFeedbackTitle').textContent = latest.source === 'manual' ? 'PLAYER LOOKUP' : api ? 'TAG DETECTED · API RUNNING' : 'NFC TAG DETECTED';
      const elapsed = Number(api ? latest.apiElapsedMs : latest.elapsedMs) || 0;
      $('nfcFeedbackMessage').textContent = (api ? 'Fetching player from OurCorz… ' : 'Waiting for the current API request… ') + (elapsed / 1000).toFixed(1) + 's';
      $('nfcFeedbackHint').textContent = latest.source === 'manual' ? 'Please wait for the API response.' : 'Tag received. You can remove it now—no need to keep waving it.';
    } else if (ready) {
      $('nfcFeedbackTitle').textContent = 'PLAYER READY';
      $('nfcFeedbackMessage').textContent = data.profile?.display_name || data.profile?.username || 'Player loaded from OurCorz.';
      $('nfcFeedbackHint').textContent = 'API lookup complete.';
    } else if (error) {
      $('nfcFeedbackTitle').textContent = latest.errorCode === 404 ? 'TAG NOT REGISTERED' : 'PLAYER LOOKUP FAILED';
      $('nfcFeedbackMessage').textContent = latest.message || 'Could not load this player.';
      $('nfcFeedbackHint').textContent = latest.source === 'manual' ? 'Check the tag ID and message above before retrying.' : 'Tag was detected. Check the message above before retrying.';
    }
  }
  function unavailable() {
    $('nfcSummary').dataset.state = 'error';
    $('nfcSummary').textContent = 'NFC: service unavailable';
    $('nfcSummary').title = 'The local Pi profile service is not responding.';
    $('nfcFeedback').hidden = true;
  }
  window.CorzNfcFeedback = {render, unavailable};
})();
