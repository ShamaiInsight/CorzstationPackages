/* Shared, deliberate Cradle navigation. Never requests a Bluetooth connection. */
(() => {
 'use strict';
 class CorzEdgeNav {
  constructor({onAction, labels={}}={}) {
   this.duration=2;
   try{const value=JSON.parse(localStorage.getItem('corz_station_config_v1')||'{}').navigation?.edgeHoldSeconds;if([1,1.5,2,2.5,3,4,5,6,8,10].includes(value))this.duration=value;}catch{}
   this.onAction=onAction;this.labels={left:'LEVEL / RECALIBRATE',top:'PLAY AGAIN',bottom:'EXIT',right:'START / STOP',...labels};
   this.armed=false;this.edge='';this.held=0;this.busy=false;
   this.root=document.createElement('div');this.root.className='corz-edge-nav';this.root.hidden=true;
   for(const edge of ['left','top','bottom','right']){const el=document.createElement('div');el.className='corz-edge-label '+edge;el.dataset.edge=edge;el.setAttribute('role','img');this.root.append(el);}
   this.prompt=document.createElement('div');this.prompt.className='corz-edge-prompt';this.prompt.setAttribute('aria-hidden','true');
   this.prompt.innerHTML='<progress class="corz-edge-native-progress" max="2" value="0" aria-label="Hold to activate"></progress><div class="corz-edge-track" aria-hidden="true"><div class="corz-edge-fill"></div><div class="corz-edge-dot"></div></div><div class="corz-edge-content"><strong></strong><span class="corz-edge-countdown" aria-live="polite"></span><small>Keep holding · move away to cancel</small></div>';
   this.prompt.querySelector('progress').max=this.duration;
   // A separate veil lets the fade finish even when the game changes scene.
   document.body.append(this.root,this.prompt);this.setLabels(this.labels);
  }
  setLabels(labels){Object.assign(this.labels,labels);for(const el of this.root.querySelectorAll('[data-edge]'))el.setAttribute('aria-label',this.labels[el.dataset.edge]);}
  // Menus use the same deliberate holds as gameplay; no remote OK is required.
  menuLabels(buttons,index){return {left:'PREVIOUS OPTION',top:'NEXT OPTION',right:buttons[index]?.textContent||'SELECT',bottom:'BACK / EXIT'};}
  menuAction(edge,buttons,index,focus,back){
   if(edge==='bottom'){back();return;}
   if(!buttons.length)return;
   if(edge==='left'||edge==='top'){focus((index+(edge==='left'?buttons.length-1:1))%buttons.length);return;}
   if(edge==='right')return buttons[index]?.click();
  }
  notice(title,copy,seconds=3){
   if(this.noticeTask)return this.noticeTask;
   this.reset();
   const veil=document.createElement('div');veil.className='corz-edge-prompt corz-action-notice visible';veil.setAttribute('role','status');veil.setAttribute('aria-live','polite');
   const content=document.createElement('div');content.className='corz-edge-content';
   const heading=document.createElement('strong'),count=document.createElement('span'),detail=document.createElement('small');
   heading.textContent=title;count.className='corz-edge-countdown';detail.textContent=copy+' No button confirmation needed.';
   content.append(heading,count,detail);veil.append(content);document.body.append(veil);
   const end=performance.now()+seconds*1000;
   this.noticeTask=new Promise(resolve=>{const tick=()=>{const remaining=Math.max(0,Math.ceil((end-performance.now())/1000));count.textContent=String(remaining);if(!remaining){clearInterval(timer);veil.remove();this.noticeTask=null;resolve();}};const timer=setInterval(tick,100);tick();});
   return this.noticeTask;
  }
  hidePrompt(){this.prompt.classList.remove('visible');this.prompt.setAttribute('aria-hidden','true');this.root.classList.remove('holding');}
  reset(){this.armed=false;this.edge='';this.held=0;this.hidePrompt();for(const el of this.root.querySelectorAll('[data-edge]'))el.classList.remove('active');}
  update({x,y,width,height,dt,enabled,fresh}) {
   this.root.hidden=!enabled;
   if(this.noticeTask){this.reset();return true;}
   if(!enabled||!fresh||this.busy||![x,y,width,height,dt].every(Number.isFinite)||width<=0||height<=0||dt<=0||dt>.6){this.reset();return false;}
   const nx=x/width,ny=y/height;
   if(nx>.3&&nx<.7&&ny>.3&&ny<.7)this.armed=true;
   // Deliberate outer-rim holds only: normal game targets may extend to 97%.
   // The 16px minimum keeps a cursor clamped 12px from the screen edge reachable.
   const bandX=Math.max(16,width*.015),bandY=Math.max(16,height*.015);
   const candidates=[];
   // Corners choose the deepest normalized penetration; exact ties favor horizontal.
   if(x<=bandX)candidates.push(['left',1-x/bandX]);if(x>=width-bandX)candidates.push(['right',1-(width-x)/bandX]);
   if(y<=bandY)candidates.push(['top',1-y/bandY]);if(y>=height-bandY)candidates.push(['bottom',1-(height-y)/bandY]);
   candidates.sort((a,b)=>b[1]-a[1]);const edge=candidates[0]?.[0]||'';
   if(!edge){this.edge='';this.held=0;this.hidePrompt();for(const el of this.root.querySelectorAll('[data-edge]'))el.classList.remove('active');return false;}
   if(!this.armed)return true;
   if(this.edge!==edge){this.edge=edge;this.held=0;}
   this.held+=Math.min(dt,.2);this.prompt.classList.add('visible');this.prompt.setAttribute('aria-hidden','false');this.root.classList.add('holding');
   this.prompt.dataset.edge=edge;
   this.prompt.style.setProperty('--edge-progress',String(Math.min(1,this.held/this.duration)));
   this.prompt.querySelector('strong').textContent=this.labels[edge];this.prompt.querySelector('progress').value=this.held;
   this.prompt.querySelector('.corz-edge-countdown').textContent=String(Math.max(0,Math.ceil(this.duration-this.held-1e-8)));
   for(const el of this.root.querySelectorAll('[data-edge]'))el.classList.toggle('active',el.dataset.edge===edge);
   if(this.held>=this.duration-1e-8){this.reset();this.busy=true;Promise.resolve().then(()=>this.onAction?.(edge)).catch(error=>console.error('Cradle action failed',error)).finally(()=>{this.busy=false;this.reset();});}
   return true;
  }
  destroy(){this.root.remove();this.prompt.remove();}
 }
 window.CorzEdgeNav=CorzEdgeNav;
})();
