/* Shared, deliberate Cradle navigation. Never requests a Bluetooth connection. */
(() => {
 'use strict';
 class CorzEdgeNav {
  constructor({onAction, labels={}}={}) {
   this.onAction=onAction;this.labels={left:'LEVEL / RECALIBRATE',top:'PLAY AGAIN',bottom:'EXIT',right:'START / STOP',...labels};
   this.armed=false;this.edge='';this.held=0;this.busy=false;
   this.root=document.createElement('div');this.root.className='corz-edge-nav';this.root.hidden=true;
   for(const edge of ['left','top','bottom','right']){const el=document.createElement('div');el.className='corz-edge-label '+edge;el.dataset.edge=edge;this.root.append(el);}
   this.prompt=document.createElement('div');this.prompt.className='corz-edge-prompt';this.prompt.hidden=true;
   this.prompt.innerHTML='<strong></strong><span>Hold the cursor here</span><progress max="2" value="0" aria-label="Hold to activate"></progress><small></small>';
   this.root.append(this.prompt);document.body.append(this.root);this.setLabels(this.labels);
  }
  setLabels(labels){Object.assign(this.labels,labels);for(const el of this.root.querySelectorAll('[data-edge]'))el.textContent=this.labels[el.dataset.edge];}
  reset(){this.armed=false;this.edge='';this.held=0;this.prompt.hidden=true;for(const el of this.root.querySelectorAll('[data-edge]'))el.classList.remove('active');}
  update({x,y,width,height,dt,enabled,fresh}) {
   this.root.hidden=!enabled;
   if(!enabled||!fresh||this.busy||![x,y,width,height,dt].every(Number.isFinite)||width<=0||height<=0||dt<=0||dt>.6){this.reset();return false;}
   const nx=x/width,ny=y/height;
   if(nx>.3&&nx<.7&&ny>.3&&ny<.7)this.armed=true;
   const candidates=[];
   if(nx<=.09)candidates.push(['left',(.5-nx)/.41]);if(nx>=.91)candidates.push(['right',(nx-.5)/.41]);
   if(ny<=.12)candidates.push(['top',(.5-ny)/.38]);if(ny>=.88)candidates.push(['bottom',(ny-.5)/.38]);
   candidates.sort((a,b)=>b[1]-a[1]);const edge=candidates[0]?.[0]||'';
   if(!edge){this.edge='';this.held=0;this.prompt.hidden=true;for(const el of this.root.querySelectorAll('[data-edge]'))el.classList.remove('active');return false;}
   if(!this.armed)return true;
   if(this.edge!==edge){this.edge=edge;this.held=0;}
   this.held+=Math.min(dt,.2);this.prompt.hidden=false;
   this.prompt.querySelector('strong').textContent=this.labels[edge];this.prompt.querySelector('progress').value=this.held;
   this.prompt.querySelector('small').textContent=Math.max(0,2-this.held).toFixed(1)+'s · Move away to cancel';
   for(const el of this.root.querySelectorAll('[data-edge]'))el.classList.toggle('active',el.dataset.edge===edge);
   if(this.held>=2-1e-8){this.reset();this.busy=true;Promise.resolve().then(()=>this.onAction?.(edge)).catch(error=>console.error('Cradle action failed',error)).finally(()=>{this.busy=false;this.reset();});}
   return true;
  }
  destroy(){this.root.remove();}
 }
 window.CorzEdgeNav=CorzEdgeNav;
})();
