/* Station launch defaults only. Never persist over a player's per-run choices. */
(function () {
  'use strict';
  const themes = ['performance', 'console', 'tron', 'rebel'];
  const oneOf = values => value => values.includes(value);
  const number = (min, max, integer = false) => value =>
    typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max && (!integer || Number.isInteger(value));
  const fields = {
    plankz: { range: number(3, 45), difficulty: oneOf(['easy', 'medium', 'hard']) },
    beepz: { range: number(3, 45), cycles: number(1, 20, true), reps: number(1, 50, true), breakSeconds: number(0, 300, true), hold: oneOf([5, 10, 15]) },
    tenz: { range: number(3, 45) },
    timez: { range: number(3, 45), work: oneOf([30, 60, 90, 120, 150, 180]), rest: oneOf([5, 10, 15, 20, 25, 30, 60]), rounds: oneOf([3, 6, 9, 12, 18, 21, 24]) }
  };
  for(const game of Object.keys(fields))Object.assign(fields[game],{rangeX:number(3,45),rangeY:number(3,45)});
  function get(game) {
    let config = {};
    try {
      const stored = JSON.parse(localStorage.getItem('corz_station_config_v1') || '{}');
      if (stored && typeof stored === 'object' && !Array.isArray(stored)) config = stored;
    } catch (_) { /* Storage can be disabled or contain old/invalid JSON. */ }
    const raw = config.games && typeof config.games === 'object' && config.games[game];
    const values = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
    const result = {};
    for (const [key, valid] of Object.entries(fields[game] || {})) {
      if (Object.prototype.hasOwnProperty.call(values, key) && valid(values[key])) result[key] = values[key];
    }
    result.theme = themes.includes(values.theme) ? values.theme : themes.includes(config.style) ? config.style : 'performance';
    return result;
  }
  function init(game) {
    const defaults = get(game);
    document.documentElement.dataset.corzGame = game;
    document.documentElement.dataset.corzTheme = defaults.theme;
    return defaults;
  }
  window.CorzGameDefaults = Object.freeze({ get, init });
})();
