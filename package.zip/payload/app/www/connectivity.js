/* Local Pi connectivity, not navigator.onLine (localhost works without internet). */
(() => {
  'use strict';
  const api = `http://${location.hostname === '127.0.0.1' ? '127.0.0.1' : 'localhost'}:8082/api/wifi/status`;
  const bar = document.getElementById('connectivityBar');
  let pending = false;

  function render(status) {
    const wifi = document.getElementById('connectivityWifi');
    const internet = document.getElementById('connectivityInternet');
    if (!status) {
      bar.dataset.state = 'unknown';
      wifi.textContent = 'Wi-Fi: status unavailable';
      internet.textContent = 'Internet: unable to check';
      bar.title = 'The local network service is not responding. Check Network Settings or the corz-wifi service.';
      return;
    }
    wifi.textContent = status.wifi_enabled === false ? 'Wi-Fi: OFF'
      : status.mode === 'hotspot' ? 'Wi-Fi: ON · Hotspot'
      : status.connected ? 'Wi-Fi: ON · Connected' : 'Wi-Fi: ON · Not connected';
    if (status.internet === true) {
      bar.dataset.state = 'online';
      internet.textContent = 'Internet: ONLINE';
    } else if (status.internet === false) {
      bar.dataset.state = 'offline';
      internet.textContent = status.connectivity === 'portal'
        ? 'NO INTERNET · Network sign-in required' : 'NO INTERNET';
    } else {
      bar.dataset.state = 'unknown';
      internet.textContent = 'Internet: unable to check';
    }
    bar.title = [wifi.textContent, status.ssid || '', status.ip || '', internet.textContent].filter(Boolean).join(' · ');
  }

  async function refresh() {
    if (pending) return;
    pending = true;
    try {
      const response = await fetch(api, {cache: 'no-store', signal: AbortSignal.timeout(12000)});
      if (!response.ok) throw new Error('Network service unavailable');
      const status = await response.json();
      if (!['client', 'hotspot'].includes(status.mode) || typeof status.connected !== 'boolean'
          || typeof status.wifi_enabled !== 'boolean') throw new Error('Update the network service');
      render(status);
    } catch (_) {
      render(null);
    } finally {
      pending = false;
    }
  }

  window.refreshConnectivity = refresh;
  window.addEventListener('online', refresh);
  window.addEventListener('offline', refresh);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
  setInterval(refresh, 10000);
  refresh();
})();
