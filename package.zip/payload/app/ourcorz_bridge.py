#!/usr/bin/env python3
"""OurCorz API + NFC kiosk bridge. Standard library; pyserial only for NFC."""
from __future__ import annotations
import copy
import json
import logging
import math
import mimetypes
import os
import re
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlsplit, unquote
from urllib.request import Request, HTTPRedirectHandler, build_opener

ROOT = Path(__file__).resolve().parent
BRIDGE_BUILD = '2026.11.05-dashboard.17'
LOG = logging.getLogger('ourcorz')

def load_env(path):
    if not path.exists():
        return
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        name, value = line.split('=', 1)
        if re.fullmatch(r'[A-Z][A-Z0-9_]*', name.strip()):
            os.environ.setdefault(name.strip(), value.strip().strip('\"\''))

class ApiError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def normalise_tag(value):
    """Reader prefix 0:UID, spaced/hyphenated hex UID, or full UUID."""
    text = str(value).strip().rsplit(':', 1)[-1].strip().lower()
    if re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', text):
        return text
    text = text.replace(' ', '').replace('-', '')
    if re.fullmatch(r'[0-9a-f]{4,16}', text):
        return text
    raise ApiError(400, 'TAG ID must be 4–16 hexadecimal characters or a UUID.')

class OurCorzClient:
    def __init__(self, base, api_key, opener=None, clock=time.time):
        self.base = base.rstrip('/')
        parsed = urlsplit(self.base)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.query or parsed.fragment:
            raise ValueError('OURCORZ_API_BASE must be an HTTPS URL without credentials or a query.')
        self.api_key = api_key.strip()
        self.opener, self.clock = opener or build_opener(NoRedirect).open, clock
        self.token, self.expires = None, 0
        self.lock = threading.Lock()

    @property
    def configured(self):
        return bool(self.api_key)

    def _request(self, method, path, body=None, token=None):
        headers = {'Accept': 'application/json'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        data = None
        if body is not None:
            headers['Content-Type'] = 'application/json'
            data = json.dumps(body).encode()
        req = Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with self.opener(req, timeout=12) as response:
                # Never forward a key or bearer to an unexpected redirect target.
                if response.geturl().rstrip('/') != (self.base + path).rstrip('/'):
                    raise ApiError(502, 'Unexpected upstream redirect. Check OURCORZ_API_BASE.')
                payload = json.loads(response.read(2_000_000))
                if not isinstance(payload, dict):
                    raise ValueError('not an object')
                return payload
        except HTTPError as exc:
            exc.close()
            if exc.code == 401:
                raise ApiError(401, 'OurCorz rejected the API key or bearer session.') from None
            if exc.code == 404:
                raise ApiError(404, 'TAG ID not registered in OurCorz (or API route not found).') from None
            raise ApiError(502, 'OurCorz returned HTTP ' + str(exc.code) + '.') from None
        except (URLError, TimeoutError, OSError):
            raise ApiError(502, 'Cannot reach OurCorz. Check the Pi internet connection.') from None
        except (ValueError, UnicodeError):
            raise ApiError(502, 'OurCorz did not return the expected JSON response.') from None

    def get_token(self):
        if not self.configured:
            raise ApiError(503, 'Set OURCORZ_API_KEY in the Pi .env file and restart the bridge.')
        with self.lock:
            if self.token and self.clock() < self.expires - 60:
                return self.token
            result = self._request('POST', '/session', {'apiKey': self.api_key})
            try:
                expires = datetime.fromisoformat(result['expiresAt'].replace('Z', '+00:00')).timestamp()
                token = result['token']
                if not isinstance(token, str) or not token or expires <= self.clock():
                    raise ValueError()
            except (KeyError, TypeError, ValueError):
                raise ApiError(502, 'OurCorz returned an invalid session response.') from None
            self.token, self.expires = token, expires
            return token

    def get(self, path, params=None):
        suffix = '?' + urlencode(params) if params else ''
        for attempt in range(2):
            token = self.get_token()
            try:
                return self._request('GET', path + suffix, token=token)
            except ApiError as exc:
                if exc.status != 401 or attempt:
                    raise
                with self.lock:
                    if self.token == token:
                        self.token, self.expires = None, 0
        raise ApiError(502, 'Session refresh failed.')

    def user(self, tag, game=''):
        params = {'tag_id': normalise_tag(tag)}
        if game:
            params['game'] = game
        result = self.get('/user', params)
        required = ('username', 'tagId', 'sessionsPlayed', 'bestScore', 'totalScore', 'bestAccuracy', 'averageAccuracy', 'totalPlaySeconds')
        if any(k not in result for k in required) or normalise_tag(result['tagId']) != params['tag_id']:
            raise ApiError(502, 'Unexpected profile response from OurCorz.')
        return result

    def hall(self, game=''):
        result = self.get('/halloffame', {'game': game} if game else None)
        if not isinstance(result.get('ranking'), list):
            raise ApiError(502, 'Unexpected Hall of Fame response from OurCorz.')
        return result

    def result(self, payload):
        """Retry only an explicit authentication rejection, never an uncertain write."""
        for attempt in range(2):
            token = self.get_token()
            try:
                response = self._request('POST', '/result', payload, token=token)
                if response.get('success') is False or response.get('error'):
                    raise ApiError(502, 'OurCorz did not accept the game result.')
                return response
            except ApiError as exc:
                if exc.status != 401 or attempt:
                    raise
                with self.lock:
                    if self.token == token:
                        self.token, self.expires = None, 0

class ResultWriter:
    """Bind scores to the captured player and suppress duplicate station requests.

    Completion records live in memory for this bridge process (up to 2048 results).
    There is no durable upload queue and no retry after a timeout/server error.
    """
    def __init__(self, client, selection):
        self.client, self.selection = client, selection
        self.lock = threading.Lock()
        self.completed = {}
        self.latest = None

    def status(self):
        # latest is replaced, never mutated; do not block NFC/status polling during uploads.
        return copy.deepcopy(self.latest)

    def submit(self, body):
        request_id = body.get('result_id')
        if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}', request_id):
            raise ApiError(400, 'A unique result_id is required.')
        expected = normalise_tag(body.get('profile_id', ''))
        game = body.get('game_title')
        if not isinstance(game, str) or not game.strip() or len(game) > 120 or any(ord(c) < 32 for c in game):
            raise ApiError(400, 'game_title must contain 1–120 printable characters.')
        numbers = {}
        for name, lower, upper in [('score', 0, 1e12), ('accuracy', 0, 100), ('duration_seconds', 0, 86400)]:
            value = body.get(name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not lower <= value <= upper:
                raise ApiError(400, 'Invalid ' + name + '.')
            numbers[name] = value
        if numbers['duration_seconds'] != int(numbers['duration_seconds']):
            raise ApiError(400, 'duration_seconds must be a whole number.')
        payload = {'tag_id': expected.upper() if '-' not in expected else expected,
                   'game': game.strip(), 'score': numbers['score'], 'accuracy': numbers['accuracy'],
                   'session_length_seconds': int(numbers['duration_seconds'])}
        fingerprint = json.dumps(payload, sort_keys=True)
        with self.lock:
            if request_id in self.completed:
                saved_fingerprint, outcome = self.completed[request_id]
                if saved_fingerprint != fingerprint:
                    raise ApiError(409, 'This result_id was already used for a different result.')
                if isinstance(outcome, ApiError):
                    raise outcome
                return dict(outcome, duplicate=True)
            snapshot = self.selection.snapshot()
            profile = snapshot['profile']
            if not profile:
                raise ApiError(409, 'No player selected or selection expired. Tap the original tag again.')
            if normalise_tag(profile['tagId']) != expected:
                raise ApiError(409, 'Player changed. Result was not submitted for another player.')
            if profile.get('readOnly'):
                raise ApiError(403, 'The selected profile does not allow score uploads.')
            try:
                # The tag is captured above; a scan during this call cannot change its owner.
                self.client.result(payload)
                outcome = {'ok': True, 'uploaded': True, 'game': payload['game']}
                self.latest = {'status': 'uploaded', 'game': payload['game'], 'completedAt': int(time.time() * 1000)}
            except ApiError as exc:
                outcome = exc
                self.latest = {'status': 'unconfirmed', 'game': payload['game'], 'errorCode': exc.status,
                               'message': exc.message, 'completedAt': int(time.time() * 1000)}
            self.completed[request_id] = (fingerprint, outcome)
            if len(self.completed) > 2048:
                del self.completed[next(iter(self.completed))]
            if isinstance(outcome, ApiError):
                raise outcome
            return outcome

class Selection:
    def __init__(self, client, ttl=900):
        self.client, self.ttl = client, ttl
        self.lock = threading.Lock()
        self.sequence = 0
        self.profile = None
        self.selected_at = 0
        self.latest = None
        self.serial_connected, self.serial_error = False, None
        self.serial_reading = False
        self.last_read_at = self.last_tag_at = None
        self.nfc_running = self.nfc_pending = False
        self.detected_mono = self.api_mono = self.completed_mono = None

    def snapshot(self):
        with self.lock:
            if self.profile and time.monotonic() - self.selected_at > self.ttl:
                self.sequence += 1
                self.profile = None
                self.latest = {'sequence': self.sequence, 'status': 'expired', 'message': 'Tap your tag again.'}
            latest = copy.deepcopy(self.latest)
            if latest and 'detectedAt' in latest:
                end = self.completed_mono if self.completed_mono is not None else time.monotonic()
                latest['elapsedMs'] = max(0, int((end - self.detected_mono) * 1000))
                latest['apiElapsedMs'] = (max(0, int((end - self.api_mono) * 1000))
                    if self.api_mono is not None else None)
            return copy.deepcopy({'sequence': self.sequence, 'profile': self.profile, 'latest': latest,
                'serialConnected': self.serial_connected, 'serialError': self.serial_error,
                'nfc': {'readerStatus': ('disconnected' if not self.serial_connected else
                    'reading' if self.serial_reading else 'not-reading'),
                    'connected': self.serial_connected, 'reading': self.serial_reading,
                    'lastReadAt': self.last_read_at, 'lastTagAt': self.last_tag_at,
                    'lastTagAgeMs': (max(0, int(time.time() * 1000 - self.last_tag_at))
                        if self.last_tag_at is not None else None),
                    'lookupRunning': self.nfc_running, 'pending': self.nfc_pending}})

    def clear(self):
        with self.lock:
            self.sequence += 1
            self.profile = None
            self.latest = {'sequence': self.sequence, 'status': 'signed-out', 'message': 'No player selected.'}

    def resolve(self, raw):
        """Synchronous HTTP interface; NFC uses the same generation-guarded lookup."""
        return self._resolve_generation(raw, self.begin_lookup('manual'))

    def begin_lookup(self, source):
        # Invalidate the former player immediately, including for unknown tags/errors.
        with self.lock:
            self.sequence += 1
            self.profile = None
            self.detected_mono = time.monotonic()
            self.api_mono = self.completed_mono = None
            self.latest = {'sequence': self.sequence, 'status': 'loading', 'source': source,
                'stage': 'queued', 'message': 'Tag detected; lookup queued…',
                'detectedAt': int(time.time() * 1000), 'apiStartedAt': None, 'completedAt': None}
            return self.sequence

    def finish_error(self, generation, exc):
        with self.lock:
            if generation == self.sequence:
                self.profile = None
                self.completed_mono = time.monotonic()
                self.latest.update(status='error', stage='complete', message=exc.message,
                    errorCode=exc.status, completedAt=int(time.time() * 1000))

    def _resolve_generation(self, raw, generation):
        try:
            tag = normalise_tag(raw)
            with self.lock:
                if generation != self.sequence:
                    raise ApiError(409, 'A newer tag scan replaced this lookup.')
                self.api_mono = time.monotonic()
                self.latest.update(stage='api', message='Tag detected; looking up player in OurCorz…',
                    apiStartedAt=int(time.time() * 1000))
            result = self.client.user(tag)
            profile = dict(result, profile_id=tag, display_name=result['username'], readOnly=False)
            with self.lock:
                if generation != self.sequence:
                    raise ApiError(409, 'A newer tag scan replaced this lookup.')
                self.profile, self.selected_at = profile, time.monotonic()
                self.completed_mono = time.monotonic()
                self.latest.update(status='ready', stage='complete', message='Player loaded from OurCorz.',
                    completedAt=int(time.time() * 1000))
            return profile
        except ApiError as exc:
            self.finish_error(generation, exc)
            raise

    def serial_status(self, connected, error=None, reading=False):
        with self.lock:
            self.serial_connected, self.serial_error = connected, error
            self.serial_reading = connected and reading

    def serial_activity(self, tag=False):
        with self.lock:
            if tag:
                self.last_tag_at = int(time.time() * 1000)
            else:
                self.last_read_at = int(time.time() * 1000)


class NFCDispatcher:
    """One API worker, one replaceable pending scan; never block serial on HTTP.

    A continuously reported tag is one presentation (2 seconds of silence re-arms
    it). Only transient upstream errors retry: at most 3 attempts per presentation,
    spaced at least 3 then 6 seconds, and only if the reader still reports the tag.
    No timer resurrects a tag after logout or after another scan/manual lookup.
    """
    def __init__(self, state, stop):
        self.state, self.stop = state, stop
        self.condition = threading.Condition()
        self.pending = None
        self.previous = None
        self.last_seen = self.last_attempt = 0
        self.attempts = 0
        self.generation = None
        self.thread = threading.Thread(target=self.run, daemon=True, name='nfc-api')
        self.thread.start()

    def submit(self, tag):
        self.state.serial_activity(tag=True)
        now = time.monotonic()
        with self.condition:
            if self.stop.is_set():
                return
            same = tag == self.previous and now - self.last_seen < 2
            latest = self.state.snapshot()['latest'] or {}
            in_flight = (tag == self.previous and latest.get('sequence') == self.generation
                and latest.get('status') == 'loading')
            self.previous, self.last_seen = tag, now
            # Even sparse repeat reports must not continually supersede a slow API.
            if in_flight:
                return
            if same:
                if not (latest.get('sequence') == self.generation and
                        latest.get('status') == 'error' and latest.get('errorCode') == 502 and
                        self.attempts < 3 and now - self.last_attempt >= 3 * self.attempts):
                    return
            else:
                self.attempts = 0
            self.attempts += 1
            self.last_attempt = now
            self.generation = self.state.begin_lookup('nfc')
            self.pending = (tag, self.generation)
            with self.state.lock:
                self.state.nfc_pending = True
            self.condition.notify()

    def run(self):
        try:
            while not self.stop.is_set():
                with self.condition:
                    self.condition.wait_for(lambda: self.pending is not None or self.stop.is_set(), timeout=.2)
                    if self.stop.is_set():
                        break
                    if self.pending is None:
                        continue
                    tag, generation = self.pending
                    self.pending = None
                    with self.state.lock:
                        self.state.nfc_pending = False
                        self.state.nfc_running = True
                try:
                    self.state._resolve_generation(tag, generation)
                except ApiError as exc:
                    if exc.status != 409:
                        LOG.warning('NFC lookup failed (HTTP %s)', exc.status)
                except Exception:
                    # Keep reading/retrying even if an upstream response is malformed.
                    self.state.finish_error(generation, ApiError(502, 'NFC lookup failed. Try the tag again.'))
                    LOG.error('Unexpected NFC lookup failure')
                finally:
                    with self.state.lock:
                        self.state.nfc_running = False
        finally:
            with self.state.lock:
                self.state.nfc_pending = False


class SerialLines:
    """Retain fragmented lines; discard an entire oversized line, not its tail."""
    def __init__(self):
        self.pending = ''
        self.discarding = False

    def feed(self, data):
        lines = []
        for char in data.decode('utf-8', errors='replace'):
            if char in '\r\n':
                if self.pending and not self.discarding:
                    lines.append(self.pending)
                self.pending, self.discarding = '', False
            elif not self.discarding:
                self.pending += char
                if len(self.pending) > 256:
                    self.pending, self.discarding = '', True
        return lines

def serial_worker(state, stop):
    try:
        import serial
    except ImportError:
        state.serial_status(False, 'Install pyserial to use the NFC reader.')
        return
    port = os.getenv('NFC_SERIAL_PORT', '/dev/ttyACM0')
    try:
        baud = int(os.getenv('NFC_BAUDRATE', '115200'))
        if baud <= 0:
            raise ValueError()
    except ValueError:
        state.serial_status(False, 'NFC_BAUDRATE must be a positive integer.')
        return
    command = os.getenv('NFC_START_COMMAND', '/p')
    dispatcher = NFCDispatcher(state, stop)
    while not stop.is_set():
        try:
            with serial.Serial(port, baud, timeout=.2, write_timeout=1) as reader:
                state.serial_status(True)
                if command:
                    reader.write((command + '\r').encode())
                state.serial_status(True, reading=True)
                lines = SerialLines()
                while not stop.is_set():
                    data = reader.read(max(1, min(reader.in_waiting, 256)))
                    if data:
                        state.serial_activity()
                    for line in lines.feed(data):
                        try:
                            tag = normalise_tag(line)
                        except ApiError:
                            continue
                        dispatcher.submit(tag)
                state.serial_status(False, 'NFC reading stopped.')
        except (OSError, ValueError, serial.SerialException):
            state.serial_status(False, 'NFC reader unavailable. Check the serial port and permissions.')
            stop.wait(3)

def make_handler(client, selection, web_root, allowed_hosts):
    writer = ResultWriter(client, selection)
    web_root = Path(web_root).resolve()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            # Do not log TAG IDs in request paths, tokens or response bodies.
            pass

        def authorised_origin(self):
            host = self.headers.get('Host', '')
            try:
                hostname = urlsplit('http://' + host).hostname
            except ValueError:
                return False
            if hostname not in allowed_hosts:
                return False
            origin = self.headers.get('Origin')
            if origin and origin not in ('http://' + host, 'https://' + host):
                return False
            return self.headers.get('Sec-Fetch-Site') not in ('cross-site',)

        def send_json(self, payload, code=200):
            data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(data)

        def do_HEAD(self):
            # The dashboard uses HEAD to discover Music/PR_1.mp3 ... PR_20.mp3.
            # Reuse GET's origin/path checks and headers, without sending a body.
            self.do_GET()

        def do_GET(self):
            if not self.authorised_origin():
                return self.send_json({'error': 'Use the dashboard from this bridge origin.'}, 403)
            parsed = urlsplit(self.path)
            query = parse_qs(parsed.query)
            game = query.get('game', [''])[0].strip()
            if len(game) > 120:
                return self.send_json({'error': 'Game name is too long.'}, 400)
            try:
                if parsed.path == '/api/status':
                    return self.send_json(dict(selection.snapshot(), configured=client.configured,
                        upstream=client.base, scoreWriteSupported=True, lastResult=writer.status(), bridgeBuild=BRIDGE_BUILD))
                if parsed.path == '/api/current-user':
                    profile = selection.snapshot()['profile']
                    if not profile:
                        raise ApiError(404, 'No NFC player selected.')
                    return self.send_json(profile)
                if parsed.path == '/api/profile':
                    snapshot = selection.snapshot()
                    if not snapshot['profile']:
                        raise ApiError(404, 'Tap a registered NFC tag first.')
                    result = client.user(snapshot['profile']['tagId'], game)
                    if selection.snapshot()['sequence'] != snapshot['sequence']:
                        raise ApiError(409, 'Player changed during the request. Refresh the profile.')
                    return self.send_json(result)
                if parsed.path == '/api/halloffame':
                    return self.send_json(client.hall(game))
                if parsed.path.startswith('/api/'):
                    raise ApiError(404, 'Unknown local API route.')
                relative = unquote(parsed.path).lstrip('/') or 'index.html'
                path = (web_root / relative).resolve()
                if not path.is_relative_to(web_root) or not path.is_file() or any(part.startswith('.') for part in Path(relative).parts):
                    raise ApiError(404, 'File not found.')
                data = None if self.command == 'HEAD' else path.read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', (mimetypes.guess_type(path.name)[0] or 'application/octet-stream') + ('; charset=utf-8' if path.suffix in ('.html', '.js', '.css') else ''))
                self.send_header('Content-Length', str(len(data) if data is not None else path.stat().st_size))
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.end_headers()
                if data is not None:
                    self.wfile.write(data)
            except ApiError as exc:
                self.send_json({'error': exc.message}, exc.status)

        def do_POST(self):
            if not self.authorised_origin():
                return self.send_json({'error': 'Use the dashboard from this bridge origin.'}, 403)
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 <= length <= 2048:
                    raise ApiError(413, 'Request is too large.')
                if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                    raise ApiError(415, 'Send application/json.')
                body = json.loads(self.rfile.read(length) or b'{}')
                if not isinstance(body, dict):
                    raise ValueError()
                path = urlsplit(self.path).path
                if path == '/api/resolve':
                    return self.send_json(selection.resolve(body.get('tag_id', '')))
                if path == '/api/logout':
                    selection.clear()
                    return self.send_json({'ok': True})
                if path == '/api/game-result':
                    return self.send_json(writer.submit(body))
                raise ApiError(404, 'Unknown local API route.')
            except (ValueError, UnicodeError):
                self.send_json({'error': 'Invalid JSON request.'}, 400)
            except ApiError as exc:
                self.send_json({'error': exc.message}, exc.status)
    return Handler

def main():
    load_env(ROOT / '.env')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # Default redirects are disabled BEFORE sending secrets to a new destination.
    client = OurCorzClient(os.getenv('OURCORZ_API_BASE', 'https://corzconvergence.com/api/public/v1'),
        os.getenv('OURCORZ_API_KEY', ''))
    selection = Selection(client, ttl=int(os.getenv('PLAYER_IDLE_SECONDS', '900')))
    bind, port = os.getenv('BIND_HOST', '127.0.0.1'), int(os.getenv('PORT', '7890'))
    hosts = set(os.getenv('ALLOWED_HOSTS', 'localhost,127.0.0.1,raspberrypi.local').split(','))
    hosts = {host.strip() for host in hosts if host.strip()}
    web_root = Path(os.getenv('WEB_ROOT', str(ROOT / 'www'))).resolve()
    stop = threading.Event()
    if os.getenv('NFC_ENABLED', '1') == '1':
        threading.Thread(target=serial_worker, args=(selection, stop), daemon=True).start()
    else:
        selection.serial_status(False, 'NFC disabled; manual TAG lookup is available.')
    server = ThreadingHTTPServer((bind, port), make_handler(client, selection, web_root, hosts))
    LOG.info('Dashboard: http://%s:%s — API key configured: %s', bind, port, client.configured)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        server.server_close()

if __name__ == '__main__':
    main()
