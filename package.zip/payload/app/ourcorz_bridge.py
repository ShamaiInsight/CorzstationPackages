#!/usr/bin/env python3
"""OurCorz API + NFC kiosk bridge. Standard library; pyserial only for NFC."""
from __future__ import annotations
import copy
import base64
import hashlib
import json
import logging
import math
import mimetypes
import os
import re
import stat
import struct
import tempfile
import threading
import time
import zlib
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlsplit, unquote
from urllib.request import Request, HTTPRedirectHandler, build_opener

ROOT = Path(__file__).resolve().parent
BRIDGE_BUILD = '2026.11.14-dashboard.26'
LOG = logging.getLogger('ourcorz')

def load_env(path):
    if not path.exists():
        return
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        name, value = line.split('=', 1)
        if re.fullmatch(r'[A-Z][A-Z0-9_]*', name.strip()):
            os.environ.setdefault(name.strip(), value.strip().strip('\"\''))

class ApiError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)

class GymLogoStore:
    """Local, bounded USB import. One atomic record keeps image and metadata together.

    No subprocesses, image packages, network calls, or caller-selected paths. The
    updater excludes app/data; the imported logo is not part of a release payload.
    """
    MAX_BYTES = 8 * 1024 * 1024
    MAX_ENTRIES, MAX_DIRS, MAX_CANDIDATES = 512, 64, 32
    MAX_SCAN_BYTES = 32 * 1024 * 1024
    SIGNATURE = b'\x89PNG\r\n\x1a\n'

    def __init__(self, data_dir=None):
        self.path = Path(data_dir or ROOT / 'data') / 'gym-logo.json'
        self.lock = threading.RLock()
        self.record = None
        self.load_error = None
        try:
            # A single JSON document is the transaction boundary. Never trust
            # persisted metadata without verifying its image again on startup.
            with self.path.open('rb') as stream:
                raw = stream.read(self.MAX_BYTES * 2 + 1)
            if len(raw) > self.MAX_BYTES * 2:
                raise ValueError('Saved logo record is too large.')
            record = json.loads(raw)
            image = base64.b64decode(record['image'], validate=True)
            width, height = self.validate_png(image)
            filename = record['filename']
            if not self._valid_filename(filename):
                raise ValueError('Invalid filename.')
            self.record = dict(image=image, filename=filename, width=width, height=height,
                               sha256=hashlib.sha256(image).hexdigest())
        except FileNotFoundError:
            pass
        except (OSError, ValueError, TypeError, KeyError):
            self.load_error = 'The saved gym logo could not be loaded. Reinsert your logo USB to import it again.'

    @classmethod
    def validate_png(cls, data):
        """Verify PNG chunks/CRCs and bounded full pixel-stream decompression.

        Supports standard PNG colour modes, bit depths and Adam7 interlacing.
        Checks scanline filters and reconstructs indexed pixels to reject bad
        palette references. Compressed/decoded size and dimensions are bounded.
        """
        if len(data) > cls.MAX_BYTES:
            raise ValueError('PNG must be no larger than 8 MB.')
        if not data.startswith(cls.SIGNATURE):
            raise ValueError('File is not a PNG image.')
        offset, header, palette, image_parts = 8, None, None, []
        ended = idat = idat_closed = transparency = False
        chunks = 0
        while offset < len(data):
            chunks += 1
            if chunks > 4096:
                raise ValueError('PNG has too many chunks. Export a simpler PNG image.')
            if offset + 12 > len(data):
                raise ValueError('PNG is truncated.')
            size, kind = struct.unpack('>I4s', data[offset:offset + 8])
            end = offset + 12 + size
            if end > len(data) or not re.fullmatch(b'[A-Za-z]{4}', kind) or kind[2] & 32:
                raise ValueError('PNG has an invalid chunk.')
            chunk = data[offset + 8:end - 4]
            crc, = struct.unpack('>I', data[end - 4:end])
            if zlib.crc32(kind + chunk) & 0xffffffff != crc:
                raise ValueError('PNG is damaged (checksum mismatch).')
            if header is None and kind != b'IHDR':
                raise ValueError('PNG header is missing.')
            if kind == b'IHDR':
                if header is not None or size != 13:
                    raise ValueError('PNG header is invalid.')
                width, height, depth, colour, compression, filtering, interlace = struct.unpack('>IIBBBBB', chunk)
                modes = {0: (1, 2, 4, 8, 16), 2: (8, 16), 3: (1, 2, 4, 8), 4: (8, 16), 6: (8, 16)}
                if not 1 <= width <= 1024 or not 1 <= height <= 1024:
                    raise ValueError('PNG dimensions must be at most 1024 × 1024 pixels.')
                if depth not in modes.get(colour, ()) or compression or filtering or interlace not in (0, 1):
                    raise ValueError('PNG uses an unsupported image format.')
                header = (width, height, depth, colour, interlace)
            elif kind in (b'acTL', b'fcTL', b'fdAT'):
                raise ValueError('Animated PNG logos are not supported. Export a still PNG image.')
            elif kind == b'PLTE':
                if palette is not None or idat or transparency or colour in (0, 4) or not size or size % 3 or size > 768:
                    raise ValueError('PNG palette is invalid.')
                palette = size // 3
                if colour == 3 and palette > 2 ** depth:
                    raise ValueError('PNG palette is invalid.')
            elif kind == b'tRNS':
                if transparency or idat or (colour == 3 and (palette is None or not 1 <= size <= palette)) or (colour != 3 and (colour not in (0, 2) or size != (2 if colour == 0 else 6))):
                    raise ValueError('PNG transparency is invalid.')
                transparency = True
            elif kind == b'IDAT':
                if idat_closed or (colour == 3 and palette is None):
                    raise ValueError('PNG image data is invalid.')
                idat = True
                image_parts.append(chunk)
            elif kind == b'IEND':
                if size or not idat or end != len(data):
                    raise ValueError('PNG ending is invalid.')
                ended = True
                break
            elif not kind[0] & 32:
                raise ValueError('PNG has an unsupported critical chunk.')
            if idat and kind != b'IDAT':
                idat_closed = True
            offset = end
        if not ended:
            raise ValueError('PNG is incomplete.')
        channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[colour]
        bits = channels * depth
        passes = [(0, 0, 1, 1)] if not interlace else [(0, 0, 8, 8), (4, 0, 8, 8), (0, 4, 4, 8), (2, 0, 4, 4), (0, 2, 2, 4), (1, 0, 2, 2), (0, 1, 1, 2)]
        rows = []
        for x, y, dx, dy in passes:
            w, h = max(0, (width - x + dx - 1) // dx), max(0, (height - y + dy - 1) // dy)
            if w and h:
                rows.append((w, h, (w * bits + 7) // 8))
        expected = sum(h * (row_bytes + 1) for _, h, row_bytes in rows)
        try:
            decoder = zlib.decompressobj()
            pixels = decoder.decompress(b''.join(image_parts), expected + 1)
            if len(pixels) != expected or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
                raise ValueError('PNG pixel data is incomplete or too large.')
        except zlib.error:
            raise ValueError('PNG compressed image data is damaged.') from None
        pos, bpp = 0, max(1, (bits + 7) // 8)
        for w, h, row_bytes in rows:
            previous = bytearray(row_bytes)
            for _ in range(h):
                method = pixels[pos]
                row = bytearray(pixels[pos + 1:pos + 1 + row_bytes])
                pos += row_bytes + 1
                if method > 4:
                    raise ValueError('PNG scanline filter is invalid.')
                if colour == 3:
                    for i in range(row_bytes):
                        left, above, corner = row[i - bpp] if i >= bpp else 0, previous[i], previous[i - bpp] if i >= bpp else 0
                        if method == 1:
                            predictor = left
                        elif method == 2:
                            predictor = above
                        elif method == 3:
                            predictor = (left + above) // 2
                        elif method == 4:
                            p = left + above - corner
                            distances = (abs(p - left), abs(p - above), abs(p - corner))
                            predictor = (left, above, corner)[distances.index(min(distances))]
                        else:
                            predictor = 0
                        row[i] = (row[i] + predictor) & 255
                    mask = (1 << depth) - 1
                    for i in range(w):
                        if ((row[i * depth // 8] >> (8 - depth - (i * depth % 8))) & mask) >= palette:
                            raise ValueError('PNG contains an invalid palette index.')
                    previous = row
        return width, height

    @staticmethod
    def _valid_filename(name):
        return (isinstance(name, str) and 0 < len(name) <= 255
                and '/' not in name and '\\' not in name
                and not any(ord(c) < 32 or ord(c) == 127 or 0xd800 <= ord(c) <= 0xdfff for c in name))

    @staticmethod
    def _removable(device):
        """Kernel evidence: removable block device OR USB-attached block drive.

        USB SSDs often report removable=0; their sysfs ancestry identifies USB.
        Network/FUSE/loop mounts have neither and are never accepted.
        """
        try:
            node = (Path('/sys/dev/block') / device).resolve(strict=True)
            if not node.is_relative_to('/sys/devices'):
                return False
            for ancestor in (node, *node.parents):
                flag = ancestor / 'removable'
                if flag.is_file() and flag.read_text().strip() == '1':
                    return True
                subsystem = ancestor / 'subsystem'
                if subsystem.is_symlink() and subsystem.resolve().name == 'usb':
                    return True
        except OSError:
            pass
        return False

    @classmethod
    def mounted_media(cls):
        mounts = []
        try:
            # The kernel emits escaped whitespace/backslashes in mountinfo.
            lines = Path('/proc/self/mountinfo').read_text().splitlines()
            for line in lines:
                fields = line.split()
                if len(fields) < 10 or '-' not in fields:
                    continue
                path = re.sub(r'\\([0-7]{3})', lambda m: chr(int(m[1], 8)), fields[4])
                if not re.fullmatch(r'(?:/media/[^/.][^/]*(?:/[^/.][^/]*)?|/run/media/[^/.][^/]*/[^/.][^/]*)', path):
                    continue
                # Exclude bind/subtree mounts; never walk a caller supplied path.
                if fields[3] != '/' or not re.fullmatch(r'\d+:\d+', fields[2]) or not cls._removable(fields[2]):
                    continue
                major, minor = map(int, fields[2].split(':'))
                mounts.append((path, os.makedev(major, minor)))
        except OSError:
            pass
        return sorted(set(mounts))[:16]

    @staticmethod
    def _open_directory(path):
        # Walk every component without following symlinks (including mount parents).
        fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
        try:
            for component in Path(path).parts[1:]:
                next_fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd)
                fd = next_fd
            return fd
        except BaseException:
            os.close(fd)
            raise

    def _status(self, message=None, **extra):
        r = self.record
        url = '/api/gym-logo/image?v=' + r['sha256'] if r else '/corzlogoicon.png'
        result = dict(ok=True, custom=bool(r), status='custom' if r else 'default', url=url, logoUrl=url,
                      filename=r['filename'] if r else None, sourceFilename=r['filename'] if r else None,
                      width=r['width'] if r else None, height=r['height'] if r else None,
                      sha256=r['sha256'] if r else None,
                      message=message or ('Custom gym logo is ready.' if r else 'Using the default CORZ logo.'))
        if self.load_error:
            result['error'] = self.load_error
        result.update(extra)
        return result

    def status(self):
        with self.lock:
            return self._status()

    def image(self):
        with self.lock:
            if not self.record:
                raise ApiError(404, 'No custom gym logo. Use /corzlogoicon.png.')
            return self.record['image']

    def _save(self, record):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {k: v for k, v in record.items() if k != 'image'}
        payload['image'] = base64.b64encode(record['image']).decode('ascii')
        temp = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=self.path.parent,
                                             prefix='.gym-logo-', delete=False) as stream:
                temp = stream.name
                json.dump(payload, stream, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, self.path)
            temp = None
        finally:
            if temp:
                try:
                    os.unlink(temp)
                except OSError:
                    pass
        self.record, self.load_error = record, None

    def scan(self):
        with self.lock:
            counts = dict(entries=0, dirs=0, candidates=0, bytes=0)
            errors = []
            limited = False

            def walk(fd, device, depth=0):
                nonlocal limited
                counts['dirs'] += 1
                if counts['dirs'] > self.MAX_DIRS:
                    limited = True
                    return
                entries = []
                with os.scandir(fd) as iterator:
                    for entry in iterator:
                        counts['entries'] += 1
                        if counts['entries'] > self.MAX_ENTRIES:
                            limited = True
                            return
                        entries.append(entry.name)
                for name in sorted(entries):
                    if limited:
                        return
                    if name.startswith('.'):
                        continue
                    try:
                        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
                        if info.st_dev != device:
                            continue
                        if stat.S_ISDIR(info.st_mode) and depth < 3:
                            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                            try:
                                if os.fstat(child).st_dev == device:
                                    yield from walk(child, device, depth + 1)
                            finally:
                                os.close(child)
                        elif stat.S_ISREG(info.st_mode) and name.startswith('LOGO_') and name.lower().endswith('.png'):
                            counts['candidates'] += 1
                            if counts['candidates'] > self.MAX_CANDIDATES:
                                limited = True
                                return
                            if not self._valid_filename(name):
                                continue
                            if not 0 < info.st_size <= self.MAX_BYTES:
                                errors.append('PNG must be non-empty and no larger than 8 MB.')
                                continue
                            handle = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
                            with os.fdopen(handle, 'rb') as stream:
                                actual = os.fstat(stream.fileno())
                                if not stat.S_ISREG(actual.st_mode) or actual.st_dev != device or not 0 < actual.st_size <= self.MAX_BYTES:
                                    continue
                                if counts['bytes'] + actual.st_size > self.MAX_SCAN_BYTES:
                                    limited = True
                                    return
                                data = stream.read(min(self.MAX_BYTES + 1, self.MAX_SCAN_BYTES - counts['bytes'] + 1))
                                counts['bytes'] += len(data)
                            if counts['bytes'] > self.MAX_SCAN_BYTES:
                                limited = True
                                return
                            try:
                                width, height = self.validate_png(data)
                            except ValueError as exc:
                                errors.append(str(exc))
                                continue
                            yield dict(image=data, filename=name, width=width, height=height,
                                       sha256=hashlib.sha256(data).hexdigest())
                    except OSError:
                        errors.append('USB became unavailable or a logo could not be read. Leave it inserted and try again.')

            try:
                for mount, device in self.mounted_media():
                    if limited:
                        break
                    try:
                        fd = self._open_directory(mount)
                        try:
                            if os.fstat(fd).st_dev != device:
                                continue
                            candidates = walk(fd, device)
                            try:
                                record = next(candidates, None)
                            finally:
                                candidates.close()
                        finally:
                            os.close(fd)
                    except OSError:
                        errors.append('USB became unavailable. Leave it inserted and try again.')
                        continue
                    if record:
                        unchanged = self.record and self.record['sha256'] == record['sha256'] and self.record['filename'] == record['filename']
                        if not unchanged:
                            self._save(record)
                        scan = dict(status='unchanged' if unchanged else 'imported', message='Gym logo already imported.' if unchanged else 'Gym logo imported. You can remove the USB.')
                        return self._status(scan['message'], scan=scan)
                message = errors[0] if errors else ('USB scan limit reached. Put one LOGO_*.png in the USB root folder.' if limited else 'No logo found. Insert a USB containing LOGO_*.png (maximum 1024 × 1024).')
                scan = dict(status='invalid' if errors else ('limit' if limited else 'not_found'), message=message)
                return self._status(message, scan=scan, **({'error': message} if errors or limited else {}))
            except OSError:
                message = 'Could not save the gym logo. Check available storage and try again; your previous logo is unchanged.'
                return self._status(message, error=message, scan=dict(status='error', message=message))


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def normalise_tag(value):
    """Reader prefix 0:UID, spaced/hyphenated hex UID, or full UUID."""
    text = str(value).strip().rsplit(':', 1)[-1].strip().lower()
    if re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', text):
        return text
    text = text.replace(' ', '').replace('-', '')
    if re.fullmatch(r'[0-9a-f]{4,16}', text):
        return text
    raise ApiError(400, 'TAG ID must be 4–16 hexadecimal characters or a UUID.')

class OurCorzClient:
    def __init__(self, base, api_key, opener=None, clock=time.time):
        self.base = base.rstrip('/')
        parsed = urlsplit(self.base)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.query or parsed.fragment:
            raise ValueError('OURCORZ_API_BASE must be an HTTPS URL without credentials or a query.')
        self.api_key = api_key.strip()
        self.opener, self.clock = opener or build_opener(NoRedirect).open, clock
        self.token, self.expires = None, 0
        self.lock = threading.Lock()

    @property
    def configured(self):
        return bool(self.api_key)

    def _request(self, method, path, body=None, token=None):
        headers = {'Accept': 'application/json'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        data = None
        if body is not None:
            headers['Content-Type'] = 'application/json'
            data = json.dumps(body).encode()
        req = Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with self.opener(req, timeout=12) as response:
                # Never forward a key or bearer to an unexpected redirect target.
                if response.geturl().rstrip('/') != (self.base + path).rstrip('/'):
                    raise ApiError(502, 'Unexpected upstream redirect. Check OURCORZ_API_BASE.')
                payload = json.loads(response.read(2_000_000))
                if not isinstance(payload, dict):
                    raise ValueError('not an object')
                return payload
        except HTTPError as exc:
            exc.close()
            if exc.code == 401:
                raise ApiError(401, 'OurCorz rejected the API key or bearer session.') from None
            if exc.code == 404:
                raise ApiError(404, 'TAG ID not registered in OurCorz (or API route not found).') from None
            raise ApiError(502, 'OurCorz returned HTTP ' + str(exc.code) + '.') from None
        except (URLError, TimeoutError, OSError):
            raise ApiError(502, 'Cannot reach OurCorz. Check the Pi internet connection.') from None
        except (ValueError, UnicodeError):
            raise ApiError(502, 'OurCorz did not return the expected JSON response.') from None

    def get_token(self):
        if not self.configured:
            raise ApiError(503, 'Set OURCORZ_API_KEY in the Pi .env file and restart the bridge.')
        with self.lock:
            if self.token and self.clock() < self.expires - 60:
                return self.token
            result = self._request('POST', '/session', {'apiKey': self.api_key})
            try:
                expires = datetime.fromisoformat(result['expiresAt'].replace('Z', '+00:00')).timestamp()
                token = result['token']
                if not isinstance(token, str) or not token or expires <= self.clock():
                    raise ValueError()
            except (KeyError, TypeError, ValueError):
                raise ApiError(502, 'OurCorz returned an invalid session response.') from None
            self.token, self.expires = token, expires
            return token

    def get(self, path, params=None):
        suffix = '?' + urlencode(params) if params else ''
        for attempt in range(2):
            token = self.get_token()
            try:
                return self._request('GET', path + suffix, token=token)
            except ApiError as exc:
                if exc.status != 401 or attempt:
                    raise
                with self.lock:
                    if self.token == token:
                        self.token, self.expires = None, 0
        raise ApiError(502, 'Session refresh failed.')

    def user(self, tag, game=''):
        params = {'tag_id': normalise_tag(tag)}
        if game:
            params['game'] = game
        result = self.get('/user', params)
        required = ('username', 'tagId', 'sessionsPlayed', 'bestScore', 'totalScore', 'bestAccuracy', 'averageAccuracy', 'totalPlaySeconds')
        if any(k not in result for k in required) or normalise_tag(result['tagId']) != params['tag_id']:
            raise ApiError(502, 'Unexpected profile response from OurCorz.')
        return result

    def hall(self, game=''):
        result = self.get('/halloffame', {'game': game} if game else None)
        if not isinstance(result.get('ranking'), list):
            raise ApiError(502, 'Unexpected Hall of Fame response from OurCorz.')
        return result

    def result(self, payload):
        """Retry only an explicit authentication rejection, never an uncertain write."""
        for attempt in range(2):
            token = self.get_token()
            try:
                response = self._request('POST', '/result', payload, token=token)
                if response.get('success') is False or response.get('error'):
                    raise ApiError(502, 'OurCorz did not accept the game result.')
                return response
            except ApiError as exc:
                if exc.status != 401 or attempt:
                    raise
                with self.lock:
                    if self.token == token:
                        self.token, self.expires = None, 0

class ResultWriter:
    """Bind scores to the captured player and suppress duplicate station requests.

    Completion records live in memory for this bridge process (up to 2048 results).
    There is no durable upload queue and no retry after a timeout/server error.
    """
    def __init__(self, client, selection):
        self.client, self.selection = client, selection
        self.lock = threading.Lock()
        self.completed = {}
        self.latest = None

    def status(self):
        # latest is replaced, never mutated; do not block NFC/status polling during uploads.
        return copy.deepcopy(self.latest)

    def submit(self, body):
        request_id = body.get('result_id')
        if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,100}', request_id):
            raise ApiError(400, 'A unique result_id is required.')
        expected = normalise_tag(body.get('profile_id', ''))
        game = body.get('game_title')
        if not isinstance(game, str) or not game.strip() or len(game) > 120 or any(ord(c) < 32 for c in game):
            raise ApiError(400, 'game_title must contain 1–120 printable characters.')
        numbers = {}
        for name, lower, upper in [('score', 0, 1e12), ('accuracy', 0, 100), ('duration_seconds', 0, 86400)]:
            value = body.get(name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not lower <= value <= upper:
                raise ApiError(400, 'Invalid ' + name + '.')
            numbers[name] = value
        if numbers['duration_seconds'] != int(numbers['duration_seconds']):
            raise ApiError(400, 'duration_seconds must be a whole number.')
        payload = {'tag_id': expected.upper() if '-' not in expected else expected,
                   'game': game.strip(), 'score': numbers['score'], 'accuracy': numbers['accuracy'],
                   'session_length_seconds': int(numbers['duration_seconds'])}
        fingerprint = json.dumps(payload, sort_keys=True)
        with self.lock:
            if request_id in self.completed:
                saved_fingerprint, outcome = self.completed[request_id]
                if saved_fingerprint != fingerprint:
                    raise ApiError(409, 'This result_id was already used for a different result.')
                if isinstance(outcome, ApiError):
                    raise outcome
                return dict(outcome, duplicate=True)
            snapshot = self.selection.snapshot()
            profile = snapshot['profile']
            if not profile:
                raise ApiError(409, 'No player selected or selection expired. Tap the original tag again.')
            if normalise_tag(profile['tagId']) != expected:
                raise ApiError(409, 'Player changed. Result was not submitted for another player.')
            if profile.get('readOnly'):
                raise ApiError(403, 'The selected profile does not allow score uploads.')
            try:
                # The tag is captured above; a scan during this call cannot change its owner.
                self.client.result(payload)
                outcome = {'ok': True, 'uploaded': True, 'game': payload['game']}
                self.latest = {'status': 'uploaded', 'game': payload['game'], 'completedAt': int(time.time() * 1000)}
            except ApiError as exc:
                outcome = exc
                self.latest = {'status': 'unconfirmed', 'game': payload['game'], 'errorCode': exc.status,
                               'message': exc.message, 'completedAt': int(time.time() * 1000)}
            self.completed[request_id] = (fingerprint, outcome)
            if len(self.completed) > 2048:
                del self.completed[next(iter(self.completed))]
            if isinstance(outcome, ApiError):
                raise outcome
            return outcome

class Selection:
    def __init__(self, client, ttl=900):
        self.client, self.ttl = client, ttl
        self.lock = threading.Lock()
        self.sequence = 0
        self.profile = None
        self.selected_at = 0
        self.latest = None
        self.serial_connected, self.serial_error = False, None
        self.serial_reading = False
        self.last_read_at = self.last_tag_at = None
        self.nfc_running = self.nfc_pending = False
        self.detected_mono = self.api_mono = self.completed_mono = None

    def snapshot(self):
        with self.lock:
            if self.profile and time.monotonic() - self.selected_at > self.ttl:
                self.sequence += 1
                self.profile = None
                self.latest = {'sequence': self.sequence, 'status': 'expired', 'message': 'Tap your tag again.'}
            latest = copy.deepcopy(self.latest)
            if latest and 'detectedAt' in latest:
                end = self.completed_mono if self.completed_mono is not None else time.monotonic()
                latest['elapsedMs'] = max(0, int((end - self.detected_mono) * 1000))
                latest['apiElapsedMs'] = (max(0, int((end - self.api_mono) * 1000))
                    if self.api_mono is not None else None)
            return copy.deepcopy({'sequence': self.sequence, 'profile': self.profile, 'latest': latest,
                'serialConnected': self.serial_connected, 'serialError': self.serial_error,
                'nfc': {'readerStatus': ('disconnected' if not self.serial_connected else
                    'reading' if self.serial_reading else 'not-reading'),
                    'connected': self.serial_connected, 'reading': self.serial_reading,
                    'lastReadAt': self.last_read_at, 'lastTagAt': self.last_tag_at,
                    'lastTagAgeMs': (max(0, int(time.time() * 1000 - self.last_tag_at))
                        if self.last_tag_at is not None else None),
                    'lookupRunning': self.nfc_running, 'pending': self.nfc_pending}})

    def clear(self):
        with self.lock:
            self.sequence += 1
            self.profile = None
            self.latest = {'sequence': self.sequence, 'status': 'signed-out', 'message': 'No player selected.'}

    def resolve(self, raw):
        """Synchronous HTTP interface; NFC uses the same generation-guarded lookup."""
        return self._resolve_generation(raw, self.begin_lookup('manual'))

    def begin_lookup(self, source):
        # Invalidate the former player immediately, including for unknown tags/errors.
        with self.lock:
            self.sequence += 1
            self.profile = None
            self.detected_mono = time.monotonic()
            self.api_mono = self.completed_mono = None
            self.latest = {'sequence': self.sequence, 'status': 'loading', 'source': source,
                'stage': 'queued', 'message': 'Tag detected; lookup queued…',
                'detectedAt': int(time.time() * 1000), 'apiStartedAt': None, 'completedAt': None}
            return self.sequence

    def finish_error(self, generation, exc):
        with self.lock:
            if generation == self.sequence:
                self.profile = None
                self.completed_mono = time.monotonic()
                self.latest.update(status='error', stage='complete', message=exc.message,
                    errorCode=exc.status, completedAt=int(time.time() * 1000))

    def _resolve_generation(self, raw, generation):
        try:
            tag = normalise_tag(raw)
            with self.lock:
                if generation != self.sequence:
                    raise ApiError(409, 'A newer tag scan replaced this lookup.')
                self.api_mono = time.monotonic()
                self.latest.update(stage='api', message='Tag detected; looking up player in OurCorz…',
                    apiStartedAt=int(time.time() * 1000))
            result = self.client.user(tag)
            profile = dict(result, profile_id=tag, display_name=result['username'], readOnly=False)
            with self.lock:
                if generation != self.sequence:
                    raise ApiError(409, 'A newer tag scan replaced this lookup.')
                self.profile, self.selected_at = profile, time.monotonic()
                self.completed_mono = time.monotonic()
                self.latest.update(status='ready', stage='complete', message='Player loaded from OurCorz.',
                    completedAt=int(time.time() * 1000))
            return profile
        except ApiError as exc:
            self.finish_error(generation, exc)
            raise

    def serial_status(self, connected, error=None, reading=False):
        with self.lock:
            self.serial_connected, self.serial_error = connected, error
            self.serial_reading = connected and reading

    def serial_activity(self, tag=False):
        with self.lock:
            if tag:
                self.last_tag_at = int(time.time() * 1000)
            else:
                self.last_read_at = int(time.time() * 1000)


class NFCDispatcher:
    """One API worker, one replaceable pending scan; never block serial on HTTP.

    A continuously reported tag is one presentation (2 seconds of silence re-arms
    it). Only transient upstream errors retry: at most 3 attempts per presentation,
    spaced at least 3 then 6 seconds, and only if the reader still reports the tag.
    No timer resurrects a tag after logout or after another scan/manual lookup.
    """
    def __init__(self, state, stop):
        self.state, self.stop = state, stop
        self.condition = threading.Condition()
        self.pending = None
        self.previous = None
        self.last_seen = self.last_attempt = 0
        self.attempts = 0
        self.generation = None
        self.thread = threading.Thread(target=self.run, daemon=True, name='nfc-api')
        self.thread.start()

    def submit(self, tag):
        self.state.serial_activity(tag=True)
        now = time.monotonic()
        with self.condition:
            if self.stop.is_set():
                return
            same = tag == self.previous and now - self.last_seen < 2
            latest = self.state.snapshot()['latest'] or {}
            in_flight = (tag == self.previous and latest.get('sequence') == self.generation
                and latest.get('status') == 'loading')
            self.previous, self.last_seen = tag, now
            # Even sparse repeat reports must not continually supersede a slow API.
            if in_flight:
                return
            if same:
                if not (latest.get('sequence') == self.generation and
                        latest.get('status') == 'error' and latest.get('errorCode') == 502 and
                        self.attempts < 3 and now - self.last_attempt >= 3 * self.attempts):
                    return
            else:
                self.attempts = 0
            self.attempts += 1
            self.last_attempt = now
            self.generation = self.state.begin_lookup('nfc')
            self.pending = (tag, self.generation)
            with self.state.lock:
                self.state.nfc_pending = True
            self.condition.notify()

    def run(self):
        try:
            while not self.stop.is_set():
                with self.condition:
                    self.condition.wait_for(lambda: self.pending is not None or self.stop.is_set(), timeout=.2)
                    if self.stop.is_set():
                        break
                    if self.pending is None:
                        continue
                    tag, generation = self.pending
                    self.pending = None
                    with self.state.lock:
                        self.state.nfc_pending = False
                        self.state.nfc_running = True
                try:
                    self.state._resolve_generation(tag, generation)
                except ApiError as exc:
                    if exc.status != 409:
                        LOG.warning('NFC lookup failed (HTTP %s)', exc.status)
                except Exception:
                    # Keep reading/retrying even if an upstream response is malformed.
                    self.state.finish_error(generation, ApiError(502, 'NFC lookup failed. Try the tag again.'))
                    LOG.error('Unexpected NFC lookup failure')
                finally:
                    with self.state.lock:
                        self.state.nfc_running = False
        finally:
            with self.state.lock:
                self.state.nfc_pending = False


class SerialLines:
    """Retain fragmented lines; discard an entire oversized line, not its tail."""
    def __init__(self):
        self.pending = ''
        self.discarding = False

    def feed(self, data):
        lines = []
        for char in data.decode('utf-8', errors='replace'):
            if char in '\r\n':
                if self.pending and not self.discarding:
                    lines.append(self.pending)
                self.pending, self.discarding = '', False
            elif not self.discarding:
                self.pending += char
                if len(self.pending) > 256:
                    self.pending, self.discarding = '', True
        return lines

def serial_worker(state, stop):
    try:
        import serial
    except ImportError:
        state.serial_status(False, 'Install pyserial to use the NFC reader.')
        return
    port = os.getenv('NFC_SERIAL_PORT', '/dev/ttyACM0')
    try:
        baud = int(os.getenv('NFC_BAUDRATE', '115200'))
        if baud <= 0:
            raise ValueError()
    except ValueError:
        state.serial_status(False, 'NFC_BAUDRATE must be a positive integer.')
        return
    command = os.getenv('NFC_START_COMMAND', '/p')
    dispatcher = NFCDispatcher(state, stop)
    while not stop.is_set():
        try:
            with serial.Serial(port, baud, timeout=.2, write_timeout=1) as reader:
                state.serial_status(True)
                if command:
                    reader.write((command + '\r').encode())
                state.serial_status(True, reading=True)
                lines = SerialLines()
                while not stop.is_set():
                    data = reader.read(max(1, min(reader.in_waiting, 256)))
                    if data:
                        state.serial_activity()
                    for line in lines.feed(data):
                        try:
                            tag = normalise_tag(line)
                        except ApiError:
                            continue
                        dispatcher.submit(tag)
                state.serial_status(False, 'NFC reading stopped.')
        except (OSError, ValueError, serial.SerialException):
            state.serial_status(False, 'NFC reader unavailable. Check the serial port and permissions.')
            stop.wait(3)

def make_handler(client, selection, web_root, allowed_hosts, gym_logo=None):
    writer = ResultWriter(client, selection)
    gym_logo = gym_logo if gym_logo is not None else GymLogoStore()
    web_root = Path(web_root).resolve()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            # Do not log TAG IDs in request paths, tokens or response bodies.
            pass

        def authorised_origin(self):
            host = self.headers.get('Host', '')
            try:
                hostname = urlsplit('http://' + host).hostname
            except ValueError:
                return False
            if hostname not in allowed_hosts:
                return False
            origin = self.headers.get('Origin')
            if origin and origin not in ('http://' + host, 'https://' + host):
                return False
            return self.headers.get('Sec-Fetch-Site') not in ('cross-site',)

        def send_json(self, payload, code=200):
            data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(data)

        def do_HEAD(self):
            # The dashboard uses HEAD to discover Music/PR_1.mp3 ... PR_20.mp3.
            # Reuse GET's origin/path checks and headers, without sending a body.
            self.do_GET()

        def do_GET(self):
            if not self.authorised_origin():
                return self.send_json({'error': 'Use the dashboard from this bridge origin.'}, 403)
            parsed = urlsplit(self.path)
            query = parse_qs(parsed.query)
            game = query.get('game', [''])[0].strip()
            if len(game) > 120:
                return self.send_json({'error': 'Game name is too long.'}, 400)
            try:
                if parsed.path == '/api/gym-logo':
                    return self.send_json(gym_logo.status())
                if parsed.path == '/api/gym-logo/image':
                    data = gym_logo.image()
                    self.send_response(200)
                    self.send_header('Content-Type', 'image/png')
                    self.send_header('Content-Length', str(len(data)))
                    self.send_header('Cache-Control', 'no-store')
                    self.send_header('X-Content-Type-Options', 'nosniff')
                    self.end_headers()
                    if self.command != 'HEAD':
                        self.wfile.write(data)
                    return
                if parsed.path == '/api/status':
                    return self.send_json(dict(selection.snapshot(), configured=client.configured,
                        upstream=client.base, scoreWriteSupported=True, lastResult=writer.status(), bridgeBuild=BRIDGE_BUILD))
                if parsed.path == '/api/current-user':
                    profile = selection.snapshot()['profile']
                    if not profile:
                        raise ApiError(404, 'No NFC player selected.')
                    return self.send_json(profile)
                if parsed.path == '/api/profile':
                    snapshot = selection.snapshot()
                    if not snapshot['profile']:
                        raise ApiError(404, 'Tap a registered NFC tag first.')
                    result = client.user(snapshot['profile']['tagId'], game)
                    if selection.snapshot()['sequence'] != snapshot['sequence']:
                        raise ApiError(409, 'Player changed during the request. Refresh the profile.')
                    return self.send_json(result)
                if parsed.path == '/api/halloffame':
                    return self.send_json(client.hall(game))
                if parsed.path.startswith('/api/'):
                    raise ApiError(404, 'Unknown local API route.')
                relative = unquote(parsed.path).lstrip('/') or 'index.html'
                path = (web_root / relative).resolve()
                if not path.is_relative_to(web_root) or not path.is_file() or any(part.startswith('.') for part in Path(relative).parts):
                    raise ApiError(404, 'File not found.')
                data = None if self.command == 'HEAD' else path.read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', (mimetypes.guess_type(path.name)[0] or 'application/octet-stream') + ('; charset=utf-8' if path.suffix in ('.html', '.js', '.css') else ''))
                self.send_header('Content-Length', str(len(data) if data is not None else path.stat().st_size))
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.end_headers()
                if data is not None:
                    self.wfile.write(data)
            except ApiError as exc:
                self.send_json({'error': exc.message}, exc.status)

        def do_POST(self):
            if not self.authorised_origin():
                return self.send_json({'error': 'Use the dashboard from this bridge origin.'}, 403)
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 <= length <= 2048:
                    raise ApiError(413, 'Request is too large.')
                if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                    raise ApiError(415, 'Send application/json.')
                body = json.loads(self.rfile.read(length) or b'{}')
                if not isinstance(body, dict):
                    raise ValueError()
                path = urlsplit(self.path).path
                if path == '/api/gym-logo/scan':
                    if body:
                        raise ApiError(400, 'Send an empty JSON object; USB paths cannot be supplied.')
                    return self.send_json(gym_logo.scan())
                if path == '/api/resolve':
                    return self.send_json(selection.resolve(body.get('tag_id', '')))
                if path == '/api/logout':
                    selection.clear()
                    return self.send_json({'ok': True})
                if path == '/api/game-result':
                    return self.send_json(writer.submit(body))
                raise ApiError(404, 'Unknown local API route.')
            except (ValueError, UnicodeError):
                self.send_json({'error': 'Invalid JSON request.'}, 400)
            except ApiError as exc:
                self.send_json({'error': exc.message}, exc.status)
    return Handler

def main():
    load_env(ROOT / '.env')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # Default redirects are disabled BEFORE sending secrets to a new destination.
    client = OurCorzClient(os.getenv('OURCORZ_API_BASE', 'https://corzconvergence.com/api/public/v1'),
        os.getenv('OURCORZ_API_KEY', ''))
    selection = Selection(client, ttl=int(os.getenv('PLAYER_IDLE_SECONDS', '900')))
    bind, port = os.getenv('BIND_HOST', '127.0.0.1'), int(os.getenv('PORT', '7890'))
    hosts = set(os.getenv('ALLOWED_HOSTS', 'localhost,127.0.0.1,raspberrypi.local').split(','))
    hosts = {host.strip() for host in hosts if host.strip()}
    web_root = Path(os.getenv('WEB_ROOT', str(ROOT / 'www'))).resolve()
    stop = threading.Event()
    if os.getenv('NFC_ENABLED', '1') == '1':
        threading.Thread(target=serial_worker, args=(selection, stop), daemon=True).start()
    else:
        selection.serial_status(False, 'NFC disabled; manual TAG lookup is available.')
    server = ThreadingHTTPServer((bind, port), make_handler(client, selection, web_root, hosts))
    LOG.info('Dashboard: http://%s:%s — API key configured: %s', bind, port, client.configured)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        server.server_close()

if __name__ == '__main__':
    main()
