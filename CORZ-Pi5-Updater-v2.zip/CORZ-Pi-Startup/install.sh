#!/bin/bash
# Run as the desktop user, not with sudo. Uses sudo for system configuration.
set -euo pipefail
[[ $EUID != 0 ]] || { echo 'Run bash install.sh as your desktop user, without sudo.'; exit 1; }
station_user=$(id -un)
station_home=$(getent passwd "$station_user" | cut -d: -f6)
[[ "$station_home" =~ ^/home/[a-zA-Z0-9_-]+$ ]] || { echo 'Expected a normal /home/username account'; exit 1; }
source_dir=$(cd -- "$(dirname -- "$0")" && pwd)
station_dir="$station_home/corz-station"
[[ ! -e "$station_dir" ]] || { echo "$station_dir exists; preserve it and review before reinstalling."; exit 1; }
command -v labwc >/dev/null || { echo 'This installer requires Raspberry Pi OS Desktop using labwc.'; exit 1; }
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip chromium bluez curl network-manager
mkdir -p "$station_dir"
cp -a "$source_dir/app" "$source_dir/runtime" "$station_dir/"
python3 -m venv "$station_dir/venv"
"$station_dir/venv/bin/pip" install -r "$station_dir/app/requirements.txt"
cp "$station_dir/app/.env.example" "$station_dir/app/.env"
chmod 600 "$station_dir/app/.env"
cp "$station_dir/runtime/splash.html" "$station_dir/app/www/splash.html"
# The updater discovers this station; releases cannot override its installation base.
sudo usermod -aG dialout "$station_user"
for service in ourcorz-bridge corz-updater corz-ble corz-hr corz-wifi; do
  if [[ -e /etc/systemd/system/$service.service ]]; then
    sudo cp -a "/etc/systemd/system/$service.service" "$station_dir/$service.service.backup"
  fi
done
sudo tee /etc/systemd/system/ourcorz-bridge.service >/dev/null <<UNIT
[Unit]
Description=CORZ dashboard, OurCorz API and NFC serial reader
Wants=network-online.target
After=network-online.target
StartLimitIntervalSec=0
[Service]
User=$station_user
SupplementaryGroups=dialout
WorkingDirectory=$station_dir/app
ExecStart=$station_dir/venv/bin/python -u $station_dir/app/ourcorz_bridge.py
Restart=always
RestartSec=5
UMask=0077
[Install]
WantedBy=multi-user.target
UNIT
bash "$source_dir/setup-updater.sh"
for pair in corz-ble:bleserver.py corz-hr:hrserver.py corz-wifi:wifi-api.py; do
  service=${pair%%:*}
  script=${pair#*:}
  dependencies=bluetooth.service
  [[ "$service" == corz-wifi ]] && dependencies=NetworkManager.service
  sudo tee "/etc/systemd/system/$service.service" >/dev/null <<UNIT
[Unit]
Description=CORZ $script
Wants=$dependencies
After=$dependencies
StartLimitIntervalSec=0
[Service]
User=$station_user
WorkingDirectory=$station_dir/runtime
ExecStart=$station_dir/venv/bin/python -u $station_dir/runtime/$script
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
UNIT
done
# BlueZ's packaged D-Bus policy commonly permits the bluetooth group.
if getent group bluetooth >/dev/null; then sudo usermod -aG bluetooth "$station_user"; fi
# Needed by the supplied wifi-api.py, which uses sudo nmcli for network changes.
# Validate before installing; restrict run-as to root and command to nmcli.
printf '%s ALL=(root) NOPASSWD: /usr/bin/nmcli\n' "$station_user" > "$station_dir/corz-wifi.sudoers"
sudo visudo -cf "$station_dir/corz-wifi.sudoers"
sudo install -o root -g root -m 0440 "$station_dir/corz-wifi.sudoers" /etc/sudoers.d/corz-wifi
cp "$source_dir/kiosk.sh" "$station_dir/kiosk.sh"
chmod +x "$station_dir/kiosk.sh"
mkdir -p "$station_home/.config/labwc"
autostart="$station_home/.config/labwc/autostart"
if [[ -f "$autostart" ]]; then cp -a "$autostart" "$station_dir/labwc-autostart.backup"; fi
entry="\"$station_dir/kiosk.sh\" >>\"$station_dir/kiosk.log\" 2>&1 &"
touch "$autostart"
grep -Fqx "$entry" "$autostart" || printf '\n%s\n' "$entry" >> "$autostart"
sudo systemctl daemon-reload
printf '\nInstalled, not started. Follow README.md: set API key, check conflicting services, configure desktop auto-login, then enable services. All supplied runtime scripts are included.\n'
