#!/bin/bash
# Called by install.sh and repair-updater.sh, as the actual desktop account.
set -euo pipefail
[[ $EUID != 0 ]] || { echo 'Run without sudo, as your desktop user.'; exit 1; }
station_user=$(id -un)
station_home=$(getent passwd "$station_user" | cut -d: -f6)
[[ "$station_home" =~ ^/home/[a-zA-Z0-9_-]+$ ]] || { echo 'Expected /home/username'; exit 1; }
station_dir="$station_home/corz-station"
source_dir=$(cd -- "$(dirname -- "$0")" && pwd)
[[ -d "$station_dir/runtime" && -d "$station_dir/app" ]] || { echo 'Install the station first.'; exit 1; }
if [[ ! -f "$station_dir/updater.json" ]]; then
  install -m 600 "$source_dir/updater.json.example" "$station_dir/updater.json"
fi
backup_dir="$station_dir/setup-backups/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$backup_dir"
if [[ -f "$station_dir/updater-launcher.py" ]]; then
  cp -a "$station_dir/updater-launcher.py" "$backup_dir/updater-launcher.py"
fi
install -m 644 "$source_dir/updater-launcher.py" "$station_dir/updater-launcher.py"
for existing in /etc/systemd/system/corz-updater.service /etc/sudoers.d/corz-updater; do
  if [[ -f "$existing" ]]; then sudo cp -a "$existing" "$backup_dir/$(basename "$existing")"; fi
done
# Exact commands only. No wildcard, arbitrary units, shell, root updater or root Python.
sudoers=$(mktemp)
unit=$(mktemp)
trap 'rm -f "$sudoers" "$unit"' EXIT
{
  printf '# CORZ updater: restart only the five user-owned station services.\n'
  for service in ourcorz-bridge corz-ble corz-hr corz-wifi; do
    printf '%s ALL=(root) NOPASSWD: /usr/bin/systemctl restart %s.service\n' "$station_user" "$service"
  done
  printf '%s ALL=(root) NOPASSWD: /usr/bin/systemctl --no-block restart corz-updater.service\n' "$station_user"
} > "$sudoers"
sudo visudo -cf "$sudoers"
sudo install -o root -g root -m 0440 "$sudoers" /etc/sudoers.d/corz-updater
cat > "$unit" <<UNIT
[Unit]
Description=CORZ station package updater
Wants=network-online.target ourcorz-bridge.service
After=network-online.target ourcorz-bridge.service
StartLimitIntervalSec=0
[Service]
User=$station_user
WorkingDirectory=$station_dir
Environment=CORZ_STATION_DIR=$station_dir
ExecStart=/usr/bin/python3 -u $station_dir/updater-launcher.py
Restart=always
RestartSec=5
TimeoutStopSec=90
UMask=0022
[Install]
WantedBy=multi-user.target
UNIT
sudo install -o root -g root -m 0644 "$unit" /etc/systemd/system/corz-updater.service
sudo systemctl daemon-reload
printf 'Updater configured for %s (%s). Local updater.json preserved.\n' "$station_user" "$station_dir"
