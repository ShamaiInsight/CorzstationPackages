#!/usr/bin/env python3
"""No root, GitHub, Bluetooth or real systemd needed: all privileged actions mocked."""
from __future__ import annotations
import hashlib
import importlib.util
import io
import json
import os
import stat
import tempfile
import threading
import unittest
import zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('corz_updater', ROOT / 'runtime/updater.py')
updater = importlib.util.module_from_spec(spec)
spec.loader.exec_module(updater)


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass


class UpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.station = self.root / 'corz-home' / 'corz-station'
        self.station.mkdir(parents=True)
        self.patches = [patch.object(updater, 'STATION', self.station),
            patch.object(updater, 'STATE', self.station / '.updates'),
            patch.object(updater, 'CONFIG', self.station / 'updater.json'),
            patch.object(updater, 'VERSION_FILE', self.station / '.corz_version'),
            patch.object(updater, 'MANIFEST_CACHE', self.station / 'corz-manifest.json')]
        for p in self.patches:
            p.start()
        updater._state.update(status='BOOT', version='LOCAL', error='', warning='')

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    def write(self, name, data):
        path = self.station / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data.encode() if isinstance(data, str) else data)
        return path

    def package(self, files=None, version='test.1', prefix='', overrides=None, missing=False, extra=None):
        files = files if files is not None else {'app/www/hello.txt': b'new'}
        manifest = dict(schema=2, version=version,
            files=[{'src': 'payload/' + name, 'dest': name} for name in files],
            bundles=[], delete=[], restart_services=[], servers=[])
        manifest.update(overrides or {})
        out = self.root / 'package.zip'
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(prefix + 'manifest.json', json.dumps(manifest))
            if not missing:
                for name, data in files.items():
                    zf.writestr(prefix + 'payload/' + name, data)
            for name, data in (extra or {}).items():
                zf.writestr(name, data)
        return out

    def apply(self, package):
        return updater.install_package(package, restart=False)

    def test_installs_backend_web_and_music_without_username(self):
        package = self.package({'app/ourcorz_bridge.py': b'BUILD = "new"\n',
            'app/www/index.html': b'<h1>Updated</h1>', 'app/www/Music/test.mp3': b'ID3test'})
        self.apply(package)
        self.assertEqual(updater.current_version(), 'test.1')
        self.assertEqual((self.station / 'app/www/Music/test.mp3').read_bytes(), b'ID3test')
        self.assertEqual((self.station / 'app/ourcorz_bridge.py').read_text(), 'BUILD = "new"\n')

    def test_preserves_env_local_config_and_unlisted_music(self):
        self.write('app/.env', 'KEY=private')
        self.write('updater.json', '{"manifest_url":""}')
        self.write('app/www/Music/my-track.mp3', b'original')
        self.apply(self.package())
        self.assertEqual((self.station / 'app/.env').read_text(), 'KEY=private')
        self.assertEqual((self.station / 'updater.json').read_text(), '{"manifest_url":""}')
        self.assertEqual((self.station / 'app/www/Music/my-track.mp3').read_bytes(), b'original')

    def test_absolute_legacy_base_rejected_before_writes(self):
        for target in ('/home/joelderoche', '/home/corz', '../outside'):
            with self.subTest(target=target), self.assertRaises(ValueError):
                self.apply(self.package(overrides={'install_base': target}))
        self.assertFalse(updater.VERSION_FILE.exists())

    def test_rejects_destinations_outside_station_and_secrets(self):
        paths = ['/home/joelderoche/test', '../escaped', 'app/../../escaped', 'app/.env',
                 'updater.json', '.updates/pending.json', 'venv/lib/x.py',
                 'app/data/players.json', 'app/players.sqlite', 'app/requirements.txt',
                 'app/www/./x', 'app/www//x', 'app\\www\\x']
        for path in paths:
            with self.subTest(path=path), self.assertRaises((ValueError, KeyError)):
                self.apply(self.package({path: b'bad'}))
        self.assertFalse(updater.VERSION_FILE.exists())

    def test_rejects_archive_traversal_even_when_not_in_manifest(self):
        with self.assertRaises(ValueError):
            self.apply(self.package(extra={'../../escape': b'bad'}))

    def test_rejects_zip_symlinks(self):
        package = self.package()
        with zipfile.ZipFile(package, 'a') as zf:
            info = zipfile.ZipInfo('evil-link')
            info.create_system = 3
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            zf.writestr(info, '/etc/passwd')
        with self.assertRaises(ValueError):
            self.apply(package)

    def test_rejects_destination_symlink(self):
        outside = self.root / 'outside'
        outside.mkdir()
        (self.station / 'app').mkdir()
        (self.station / 'app/www').symlink_to(outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.apply(self.package())
        self.assertFalse((outside / 'hello.txt').exists())

    def test_missing_source_is_not_silently_skipped(self):
        with self.assertRaises(ValueError):
            self.apply(self.package(missing=True))
        self.assertFalse(updater.VERSION_FILE.exists())

    def test_invalid_python_does_not_overwrite_old_server(self):
        self.write('app/ourcorz_bridge.py', 'old = True\n')
        with self.assertRaises(SyntaxError):
            self.apply(self.package({'app/ourcorz_bridge.py': b'def broken('}))
        self.assertEqual((self.station / 'app/ourcorz_bridge.py').read_text(), 'old = True\n')

    def test_top_level_return_fails_compilation_before_install(self):
        with self.assertRaises(SyntaxError):
            self.apply(self.package({'runtime/hrserver.py': b'return 1\n'}))

    def test_version_mismatch_rejected_before_install(self):
        with self.assertRaises(ValueError):
            updater.install_package(self.package(), expected_version='other', restart=False)
        self.assertFalse(updater.VERSION_FILE.exists())

    def test_restarts_only_changed_backend(self):
        package = self.package({'runtime/hrserver.py': b'BUILD = 2\n'})
        with patch.object(updater, 'run_service') as restart:
            updater.install_package(package)
        restart.assert_called_once_with('corz-hr.service')

    def test_static_assets_do_not_restart_services(self):
        with patch.object(updater, 'run_service') as restart:
            updater.install_package(self.package())
        restart.assert_not_called()

    def test_unchanged_backend_does_not_restart_on_new_version(self):
        self.write('runtime/hrserver.py', 'BUILD = 2\n')
        with patch.object(updater, 'run_service') as restart:
            updater.install_package(self.package({'runtime/hrserver.py': b'BUILD = 2\n'}))
        restart.assert_not_called()

    def test_self_update_commits_then_requests_nonblocking_restart(self):
        def restart(unit, self_restart=False):
            self.assertEqual(updater.current_version(), 'test.1')
            self.assertFalse((updater.STATE / 'pending.json').exists())
            self.assertEqual(unit, 'corz-updater.service')
            self.assertTrue(self_restart)
        with patch.object(updater, 'run_service', side_effect=restart):
            result = updater.install_package(self.package({'runtime/updater.py': b'BUILD = 2\n'}))
        self.assertEqual(result, ('test.1', True))

    def test_failed_self_restart_preserves_installed_version_and_warns(self):
        with patch.object(updater, 'run_service', side_effect=RuntimeError('not authorized')):
            result = updater.install_package(self.package({'runtime/updater.py': b'BUILD = 2\n'}))
        self.assertEqual(result, ('test.1', False))
        self.assertIn('self-restart failed', updater.get_state()['warning'])

    def test_same_version_never_reinstalls_or_restarts(self):
        package = self.package()
        self.apply(package)
        self.write('app/www/hello.txt', b'local change')
        with patch.object(updater, 'run_service') as restart:
            self.assertEqual(updater.install_package(package), ('test.1', False))
        self.assertEqual((self.station / 'app/www/hello.txt').read_bytes(), b'local change')
        restart.assert_not_called()

    def test_failed_restart_rolls_back_files_deletions_and_version(self):
        self.write('runtime/hrserver.py', 'BUILD = 1\n')
        self.write('app/www/old.txt', 'keep')
        self.write('.corz_version', 'old')
        package = self.package({'runtime/hrserver.py': b'BUILD = 2\n', 'app/www/new.txt': b'new'},
                               overrides={'delete': ['app/www/old.txt']})
        with patch.object(updater, 'run_service', side_effect=[RuntimeError('failed'), None]):
            with self.assertRaisesRegex(RuntimeError, 'previous files restored'):
                updater.install_package(package)
        self.assertEqual((self.station / 'runtime/hrserver.py').read_text(), 'BUILD = 1\n')
        self.assertEqual((self.station / 'app/www/old.txt').read_text(), 'keep')
        self.assertFalse((self.station / 'app/www/new.txt').exists())
        self.assertEqual(updater.current_version(), 'old')

    def test_failed_metadata_commit_restores_old_version(self):
        self.write('app/www/hello.txt', 'old')
        original = updater.atomic_write
        def fail_once(path, data, mode=0o644):
            if path == updater.VERSION_FILE and data == b'test.1':
                raise OSError('simulated disk failure')
            return original(path, data, mode)
        with patch.object(updater, 'atomic_write', side_effect=fail_once), self.assertRaises(RuntimeError):
            self.apply(self.package())
        self.assertEqual((self.station / 'app/www/hello.txt').read_text(), 'old')
        self.assertFalse(updater.VERSION_FILE.exists())

    def test_interrupted_update_recovered_on_next_start(self):
        self.write('app/www/hello.txt', 'old')
        package = self.package({'app/www/hello.txt': b'new', 'app/www/second.txt': b'new'})
        original = updater.atomic_write
        def interrupt(path, data, mode=0o644):
            if path == self.station / 'app/www/second.txt':
                raise KeyboardInterrupt('simulated power interruption')
            return original(path, data, mode)
        with patch.object(updater, 'atomic_write', side_effect=interrupt), self.assertRaises(KeyboardInterrupt):
            self.apply(package)
        self.assertTrue((updater.STATE / 'pending.json').exists())
        updater.recover()
        self.assertEqual((self.station / 'app/www/hello.txt').read_text(), 'old')
        self.assertFalse((updater.STATE / 'pending.json').exists())

    def test_recovery_keeps_journal_if_restored_service_cannot_restart(self):
        self.write('runtime/hrserver.py', 'BUILD = 1\n')
        original = updater.atomic_write
        def interrupt(path, data, mode=0o644):
            if path == updater.VERSION_FILE:
                raise KeyboardInterrupt('interrupted')
            return original(path, data, mode)
        with patch.object(updater, 'atomic_write', side_effect=interrupt), self.assertRaises(KeyboardInterrupt):
            self.apply(self.package({'runtime/hrserver.py': b'BUILD = 2\n'}))
        with patch.object(updater, 'run_service', side_effect=RuntimeError('offline service')):
            with self.assertRaises(RuntimeError):
                updater.recover()
        self.assertTrue((updater.STATE / 'pending.json').exists())
        self.assertEqual((self.station / 'runtime/hrserver.py').read_text(), 'BUILD = 1\n')
        with patch.object(updater, 'run_service'):
            updater.recover()
        self.assertFalse((updater.STATE / 'pending.json').exists())

    def test_recovery_handles_new_target_whose_parent_was_never_created(self):
        original = updater.atomic_write
        def interrupt(path, data, mode=0o644):
            if path == self.station / 'app/www/new-folder/file.txt':
                raise KeyboardInterrupt('interrupted before creating target parent')
            return original(path, data, mode)
        with patch.object(updater, 'atomic_write', side_effect=interrupt), self.assertRaises(KeyboardInterrupt):
            self.apply(self.package({'app/www/new-folder/file.txt': b'new'}))
        updater.recover()
        self.assertFalse((updater.STATE / 'pending.json').exists())

    def test_standard_bundle_keeps_layout_and_local_files(self):
        inner = io.BytesIO()
        with zipfile.ZipFile(inner, 'w') as zf:
            zf.writestr('Build/game.data', b'game')
            zf.writestr('index.html', b'game page')
        self.write('app/www/games/demo/local.txt', 'keep')
        package = self.package(files={}, overrides={'bundles': [
            {'src': 'game.zip', 'dest': 'app/www/games/demo'}]}, extra={'game.zip': inner.getvalue()})
        self.apply(package)
        self.assertEqual((self.station / 'app/www/games/demo/Build/game.data').read_bytes(), b'game')
        self.assertEqual((self.station / 'app/www/games/demo/local.txt').read_text(), 'keep')

    def test_bundle_traversal_rejected(self):
        inner = io.BytesIO()
        with zipfile.ZipFile(inner, 'w') as zf:
            zf.writestr('../../escape', b'bad')
        package = self.package(files={}, overrides={'bundles': [
            {'src': 'game.zip', 'dest': 'app/www/games/demo'}]}, extra={'game.zip': inner.getvalue()})
        with self.assertRaises(ValueError):
            self.apply(package)

    def test_directory_replace_not_allowed(self):
        with self.assertRaises(ValueError):
            self.apply(self.package(overrides={'bundles': [{'src': 'x.zip', 'dest': 'app/www', 'replace': True}]}))

    def test_unapproved_service_is_rejected(self):
        with self.assertRaises(ValueError):
            self.apply(self.package(overrides={'restart_services': ['ssh.service']}))

    def test_arbitrary_game_server_paths_rejected(self):
        with self.assertRaises(ValueError):
            self.apply(self.package(overrides={'servers': [{'path': '/etc', 'port': 9000}]}))

    def test_github_wrapped_zip_supported(self):
        self.apply(self.package(prefix='repo-main/'))
        self.assertEqual(updater.current_version(), 'test.1')

    def test_duplicate_target_rejected(self):
        entries = [{'src': 'payload/app/www/hello.txt', 'dest': 'app/www/hello.txt'}] * 2
        with self.assertRaises(ValueError):
            self.apply(self.package(overrides={'files': entries}))

    def test_core_server_cannot_be_deleted(self):
        with self.assertRaises(ValueError):
            self.apply(self.package(overrides={'delete': ['runtime/hrserver.py']}))

    def test_remote_url_requires_https(self):
        for url in ('http://example.com/x', 'file:///tmp/x', 'https://user:pass@example.com/x'):
            with self.subTest(url=url), self.assertRaises(ValueError):
                updater.check_url(url)
        self.assertEqual(updater.check_url('http://127.0.0.1:9999/update.json'), 'http://127.0.0.1:9999/update.json')

    def test_real_http_download_checksum_install_and_second_boot_skip(self):
        package = self.package()
        data = package.read_bytes()
        release = {'version': 'test.1', 'package_url': 'package.zip',
                   'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)}
        (self.root / 'update.json').write_text(json.dumps(release))
        server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(self.root)))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            self.write('updater.json', json.dumps({'manifest_url': f'http://127.0.0.1:{server.server_port}/update.json'}))
            updater.STATE.mkdir()
            updater.update_worker()
            self.assertEqual(updater.current_version(), 'test.1')
            self.assertEqual(updater.get_state()['status'], 'READY')
            self.assertEqual(updater.get_state()['error'], '')
            with patch.object(updater, 'download') as download:
                updater.update_worker()
            download.assert_not_called()
            release['version'] = 'test.2'
            release['sha256'] = '0' * 64
            (self.root / 'update.json').write_text(json.dumps(release))
            updater.update_worker()
            self.assertIn('SHA-256 mismatch', updater.get_state()['error'])
            self.assertEqual(updater.current_version(), 'test.1')
        finally:
            server.shutdown()
            server.server_close()

    def test_disabled_network_reaches_ready(self):
        self.write('updater.json', '{"manifest_url":""}')
        updater.update_worker()
        self.assertEqual(updater.get_state()['status'], 'READY')

    def test_offline_fallback_retains_error(self):
        with patch.object(updater, 'remote_release', side_effect=OSError('offline')):
            updater.update_worker()
        self.assertEqual(updater.get_state()['status'], 'READY')
        self.assertEqual(updater.get_state()['error'], 'offline')


if __name__ == '__main__':
    unittest.main(verbosity=2)
