import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('corz_launcher', ROOT / 'updater-launcher.py')
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.station = Path(self.temp.name) / 'station'
        self.state = self.station / '.updates'
        self.backup = self.state / 'backups/20261025-1'
        (self.station / 'runtime').mkdir(parents=True)
        (self.backup / 'runtime').mkdir(parents=True)
        self.patches = [patch.object(launcher, 'STATION', self.station),
                        patch.object(launcher, 'STATE', self.state)]
        for p in self.patches:
            p.start()
        self.journal = {'backup': '20261025-1', 'entries': [
            {'name': 'runtime/updater.py', 'existed': True, 'mode': 0o644}],
            'services': ['corz-updater.service']}
        (self.backup / '.corz_version').write_text('old')
        (self.station / '.corz_version').write_text('new')

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    def test_crashing_replacement_restores_previous_updater_and_version(self):
        # A real child process fails with valid Python but a runtime import error.
        (self.station / 'runtime/updater.py').write_text('import corz_missing_test_dependency\n')
        marker = self.station / 'fallback-ran.txt'
        old = f'from pathlib import Path\nPath({str(marker)!r}).write_text("recovered")\n'
        (self.backup / 'runtime/updater.py').write_text(old)
        (self.state / 'trial.json').write_text(json.dumps(self.journal))
        self.assertEqual(launcher.launch(), 0)
        self.assertEqual(marker.read_text(), 'recovered')
        self.assertEqual((self.station / '.corz_version').read_text(), 'old')
        self.assertEqual((self.station / 'runtime/updater.py').read_text(), old)
        self.assertFalse((self.state / 'trial.json').exists())

    def test_successful_trial_does_not_restore_previous_files(self):
        script = f'from pathlib import Path\nPath({str(self.state / "trial.json")!r}).unlink()\n'
        (self.station / 'runtime/updater.py').write_text(script)
        (self.backup / 'runtime/updater.py').write_text('raise RuntimeError("should not run")\n')
        (self.state / 'trial.json').write_text(json.dumps(self.journal))
        self.assertEqual(launcher.launch(), 0)
        self.assertEqual((self.station / '.corz_version').read_text(), 'new')

    def test_trial_rollback_persists_recovery_phase_before_restoration(self):
        (self.station / 'runtime/updater.py').write_text('raise RuntimeError("bad replacement")\n')
        (self.backup / 'runtime/updater.py').write_text('pass\n')
        (self.state / 'trial.json').write_text(json.dumps(self.journal))
        def fail_during_restore(journal):
            self.assertTrue((self.state / 'pending.json').exists())
            raise OSError('simulated interruption during rollback')
        with patch.object(launcher, 'restore', side_effect=fail_during_restore):
            with self.assertRaises(OSError):
                launcher.launch()
        self.assertTrue((self.state / 'pending.json').exists())
        launcher.recover_pending()
        self.assertEqual((self.station / 'runtime/updater.py').read_text(), 'pass\n')
        self.assertEqual((self.station / '.corz_version').read_text(), 'old')
        self.assertFalse((self.state / 'trial.json').exists())
        self.assertFalse((self.state / 'pending.json').exists())

    def test_pending_recovery_restores_before_updater_can_run(self):
        (self.station / 'runtime/updater.py').write_text('raise RuntimeError("broken new updater")\n')
        marker = self.station / 'old-ran.txt'
        (self.backup / 'runtime/updater.py').write_text(
            f'from pathlib import Path\nPath({str(marker)!r}).write_text("old")\n')
        (self.state / 'pending.json').write_text(json.dumps(self.journal))
        self.assertEqual(launcher.launch(), 0)
        self.assertEqual(marker.read_text(), 'old')
        self.assertFalse((self.state / 'pending.json').exists())

    def test_pending_journal_retained_when_recovery_service_restart_fails(self):
        (self.backup / 'runtime/updater.py').write_text('pass\n')
        self.journal['services'].append('corz-hr.service')
        (self.state / 'pending.json').write_text(json.dumps(self.journal))
        with patch.object(launcher.subprocess, 'run', side_effect=RuntimeError('restart failed')):
            with self.assertRaises(RuntimeError):
                launcher.recover_pending()
        self.assertTrue((self.state / 'pending.json').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
