#!/bin/bash
# Repairs an existing ~/corz-station without replacing the app or its secrets.
set -euo pipefail
[[ $EUID != 0 ]] || { echo 'Run bash repair-updater.sh without sudo.'; exit 1; }
[[ $(id -un) == corz ]] || printf 'Using account %s, not a hard-coded account.\n' "$(id -un)"
station_home=$(getent passwd "$(id -un)" | cut -d: -f6)
station_dir="$station_home/corz-station"
source_dir=$(cd -- "$(dirname -- "$0")" && pwd)
[[ -f "$station_dir/runtime/updater.py" && -d "$station_dir/app" ]] || {
  echo 'No existing ~/corz-station found. For a fresh installation use bash install.sh.'; exit 1;
}
[[ -O "$station_dir" && -w "$station_dir/runtime" ]] || {
  echo 'Station is not owned/writable by this account. Check ownership before proceeding.'; exit 1;
}
python3 - "$source_dir/runtime/updater.py" <<'PY'
import pathlib, sys
compile(pathlib.Path(sys.argv[1]).read_bytes(), sys.argv[1], 'exec')
PY
if load_state=$(systemctl show corz-updater.service --property=LoadState --value); then
  :
elif [[ "$load_state" != not-found ]]; then
  echo 'Could not inspect updater unit; no files changed.'; exit 1
fi
if [[ "$load_state" != not-found ]]; then
  sudo systemctl stop corz-updater.service
fi
backup_dir="$station_dir/setup-backups/$(date +%Y%m%d-%H%M%S)-repair-$$"
mkdir -p "$backup_dir"
cp -a "$station_dir/runtime/updater.py" "$backup_dir/updater.py"
install -m 644 "$source_dir/runtime/updater.py" "$station_dir/runtime/updater.py"
bash "$source_dir/setup-updater.sh"
printf '\nRepair complete. App, API keys, music and databases were not changed.\n'
printf 'Publish github-upload/package.zip and update.json first, then run:\n'
printf '  sudo systemctl enable --now corz-updater\n'
printf '  journalctl -u corz-updater -f\n'
