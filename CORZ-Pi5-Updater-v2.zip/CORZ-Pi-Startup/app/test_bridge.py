import io
import json
import http.client
import tempfile
import threading
import unittest
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer
from ourcorz_bridge import ApiError, NoRedirect, OurCorzClient, Selection, normalise_tag, make_handler

BASE = 'https://ourcorz.lovable.app/api/public/v1'
def user(tag='abcd1234', game='all'):
    return dict(username='Test Player', tagId=tag, game=game, sessionsPlayed=2,
        bestScore=90, totalScore=150, bestAccuracy=98, averageAccuracy=85, totalPlaySeconds=120)

class Response:
    def __init__(self, payload, url):
        self.payload, self.url = payload, url
    def __enter__(self):
        return self
    def __exit__(self, *args):
        pass
    def read(self, size):
        return json.dumps(self.payload).encode()
    def geturl(self):
        return self.url

class ClientTests(unittest.TestCase):
    def setUp(self):
        self.now = 1000
        self.calls = []
        self.sessions = 0
        self.fail_once = False
        self.fail_always = False
        def opener(req, timeout):
            self.calls.append(req)
            if req.full_url.endswith('/session'):
                self.sessions += 1
                self.assertEqual(json.loads(req.data), {'apiKey':'test-secret'})
                return Response({'token':'token-'+str(self.sessions), 'expiresAt':datetime.fromtimestamp(self.now+3600,timezone.utc).isoformat()}, req.full_url)
            if self.fail_once or self.fail_always:
                self.fail_once = False
                raise HTTPError(req.full_url,401,'Unauthorized',{},io.BytesIO())
            self.assertEqual(req.get_header('Authorization'),'Bearer token-'+str(self.sessions))
            return Response(user(), req.full_url)
        self.client = OurCorzClient(BASE, 'test-secret', opener=opener, clock=lambda:self.now)

    def test_cache_and_expiry(self):
        self.client.user('ABCD1234')
        self.client.user('ABCD1234')
        self.assertEqual(self.sessions,1)
        self.now += 3550
        self.client.user('ABCD1234')
        self.assertEqual(self.sessions,2)

    def test_401_refresh_once(self):
        self.client.user('ABCD1234')
        self.fail_once=True
        self.client.user('ABCD1234')
        self.assertEqual(self.sessions,2)
        self.fail_always=True
        with self.assertRaises(ApiError) as exc:
            self.client.user('ABCD1234')
        self.assertEqual(exc.exception.status,401)
        self.assertEqual(self.sessions,3)

    def test_query_encoding(self):
        self.client.user('ABCD1234','Light Cycle & more')
        self.assertIn('tag_id=abcd1234&game=Light+Cycle+%26+more',self.calls[-1].full_url)

    def test_missing_key(self):
        self.client.api_key=''
        with self.assertRaises(ApiError) as exc:
            self.client.user('abcd1234')
        self.assertEqual(exc.exception.status,503)
        self.assertEqual(self.calls,[])

    def test_session_shape(self):
        self.client.opener=lambda req,timeout:Response({'token':'x'},req.full_url)
        with self.assertRaises(ApiError) as exc:
            self.client.get_token()
        self.assertEqual(exc.exception.status,502)

    def test_tag_formats(self):
        for raw in ['ABCD1234','0:AB CD 12 34','AB-CD-12-34']:
            self.assertEqual(normalise_tag(raw),'abcd1234')
        self.assertEqual(normalise_tag('AABBCCDD-1234-1234-1234-AABBCCDDEEFF'),'aabbccdd-1234-1234-1234-aabbccddeeff')
        for raw in ['', '123', 'g123', 'a'*17, '<script>']:
            with self.assertRaises(ApiError):
                normalise_tag(raw)

    def test_redirect_rejected(self):
        self.assertIsNone(NoRedirect().redirect_request(None,None,302,'',{},'https://other.test'))

class FakeClient:
    configured=True
    base=BASE
    def user(self,tag,game=''):
        if tag=='deadbeef':
            raise ApiError(404,'Unknown TAG ID')
        return user(tag,game or 'all')
    def hall(self,game=''):
        return {'game':game or 'all','bestScoreChampion':None,'bestAccuracyChampion':None,'ranking':[]}

class StateTests(unittest.TestCase):
    def test_unknown_tag_clears_old_player(self):
        state=Selection(FakeClient())
        state.resolve('abcd1234')
        self.assertTrue(state.snapshot()['profile']['readOnly'])
        with self.assertRaises(ApiError):
            state.resolve('deadbeef')
        self.assertIsNone(state.snapshot()['profile'])
        self.assertEqual(state.snapshot()['latest']['status'],'error')

    def test_expiry_and_clear(self):
        state=Selection(FakeClient(),ttl=-1)
        state.resolve('abcd1234')
        self.assertIsNone(state.snapshot()['profile'])
        state.clear()
        self.assertEqual(state.snapshot()['latest']['status'],'signed-out')

    def test_slow_old_lookup_cannot_replace_new_scan(self):
        start,release=threading.Event(),threading.Event()
        class SlowClient(FakeClient):
            def user(self,tag,game=''):
                if tag=='11112222':
                    start.set(); release.wait(2)
                return user(tag)
        state=Selection(SlowClient());errors=[]
        def old():
            try:state.resolve('11112222')
            except ApiError as e:errors.append(e.status)
        t=threading.Thread(target=old);t.start();self.assertTrue(start.wait(2))
        state.resolve('33334444');release.set();t.join()
        self.assertEqual(state.snapshot()['profile']['tagId'],'33334444')
        self.assertEqual(errors,[409])

class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=Path(tempfile.mkdtemp(dir=Path(__file__).resolve().parent))
        (cls.root/'index.html').write_text('<h1>test dashboard</h1>')
        (cls.root/'.secret').write_text('never serve')
        cls.state=Selection(FakeClient())
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(FakeClient(),cls.state,cls.root,{'127.0.0.1'}))
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.port=cls.server.server_port
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join()
        (cls.root/'index.html').unlink();(cls.root/'.secret').unlink();cls.root.rmdir()
    def request(self,method,path,body=None,headers=None):
        c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        headers=headers or {}
        if body is not None:headers['Content-Type']='application/json';body=json.dumps(body)
        c.request(method,path,body=body,headers=headers);r=c.getresponse();status=r.status;raw=r.read();c.close()
        try:return status,json.loads(raw)
        except ValueError:return status,raw
    def test_flow(self):
        status,p=self.request('POST','/api/resolve',{'tag_id':'0:ABCD1234'})
        self.assertEqual(status,200);self.assertEqual(p['display_name'],'Test Player')
        self.assertEqual(self.request('GET','/api/current-user')[0],200)
        self.assertEqual(self.request('GET','/api/profile?game=Light%20Cycle')[1]['game'],'Light Cycle')
        self.assertEqual(self.request('GET','/api/halloffame?game=Planz')[1]['game'],'Planz')
        self.assertEqual(self.request('GET','/api/halloffame')[1]['game'],'all')
        status,data=self.request('GET','/api/status');self.assertNotIn('token',json.dumps(data));self.assertNotIn('api_key',json.dumps(data))
        self.assertEqual(self.request('POST','/api/game-result',{})[0],501)
        self.request('POST','/api/logout',{})
        self.assertEqual(self.request('GET','/api/current-user')[0],404)
    def test_origin_and_static_boundaries(self):
        self.assertEqual(self.request('GET','/')[0],200)
        self.assertEqual(self.request('GET','/.secret')[0],404)
        self.assertEqual(self.request('GET','/../ourcorz_bridge.py')[0],404)
        self.assertEqual(self.request('POST','/api/resolve',{'tag_id':'abcd1234'},{'Origin':'https://evil.example'})[0],403)
        self.assertEqual(self.request('GET','/api/status',headers={'Host':'evil.example'})[0],403)
        self.assertEqual(self.request('POST','/api/resolve',{'tag_id':'invalid'})[0],400)

if __name__=='__main__':unittest.main(verbosity=2)
