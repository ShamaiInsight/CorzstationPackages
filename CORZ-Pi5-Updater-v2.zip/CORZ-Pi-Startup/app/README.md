# CORZ dashboard — OurCorz API edition

This update removes CORZGAME and FLYZ from the launcher and replaces local member management with registered NFC tag lookup through OurCorz. Hall of Fame supports all games or an exact game name. PLANKZ, BEEPZ, TENZ and LIFTZ are included.

## Install on the Raspberry Pi

Use Python 3.10 or newer. Extract this folder to `/home/pi/CORZ-OurCorz-API` (adjust the username/path for your Pi).

```sh
cd /home/pi/CORZ-OurCorz-API
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
cp .env.example .env
chmod 600 .env
nano .env
```

Set `OURCORZ_API_KEY` to the full key created in the OurCorz web application. The key stays on the Pi; never put it in an HTML file, URL, screenshot or shared archive. The exported database contains key metadata, not a usable API key.

```sh
.venv/bin/python check_api.py
.venv/bin/python ourcorz_bridge.py
```

Open **http://localhost:7890/** on the Pi. Open the dashboard through this service, not by double-clicking an HTML file: the service supplies the API and keeps the key out of the browser. If another profile server already uses port 7890, stop that server first or change `PORT`.

Keep your existing BLE server running at `ws://raspberrypi.local:8765`. This package does not replace it. Existing heart-rate/network services are unchanged.

### Existing dashboard assets

This is an update to your existing dashboard. The supplied baseline did not include its Music folder, all icon files, or the Workout TimeZ/PongZ pages. Preserve those files from your installation: copy the contents of `www` over a **backup copy** of your existing dashboard folder, then set `WEB_ROOT` in `.env` to that folder's absolute path. Alternatively, copy the missing assets/pages into this package's `www`. The four included games and Hall of Fame run from `www` directly.

### NFC reader

Defaults match the example reader: `/dev/ttyACM0`, 115200 baud, `/p` polling command, CR/LF records such as `0:ABCD1234`. Adjust `NFC_SERIAL_PORT` (a stable `/dev/serial/by-id/...` path is preferable), `NFC_BAUDRATE`, and `NFC_START_COMMAND` as needed. Leave the command empty for a reader that emits tags without polling. Set `NFC_ENABLED=0` to test with manual TAG entry only.

Only one program can own the serial port: stop the old NFC application before using this reader worker. Give the service user access to the serial device, typically through the `dialout` group. The Gladstone server integration from the example is not used.

Tap a registered tag or click **TAP NFC TAG**, enter its ID, and choose **Load player**. The panel shows name, score, accuracy, session count and play time. Unknown tags and lookup failures clear the previous selection. Selection expires after 15 minutes, configurable with `PLAYER_IDLE_SECONDS`. **Clear player** signs the station out. Member registration/management stays in the OurCorz web application.

### Access from your Windows computer

For access on a trusted local network, set `BIND_HOST=0.0.0.0`, restart the service, and open **http://raspberrypi.local:7890/**. If using a numeric Pi address, add that address to `ALLOWED_HOSTS`. This exposes the station's profile lookup and shared selected player to that LAN; the default is Pi-local access only. Do not forward this port to the public internet.

### Start automatically

After manual testing succeeds, edit the paths and `User` in `ourcorz-bridge.service.example`, copy it to `/etc/systemd/system/ourcorz-bridge.service`, then run:

```sh
sudo systemctl daemon-reload
sudo systemctl enable --now ourcorz-bridge
journalctl -u ourcorz-bridge -f
```

Restart the service after changing `.env`. Do not run the manual server and service on the same port simultaneously.

## API behavior and limits

The implementation follows the routes in the supplied OurCorz source:

| Request | Purpose |
|---|---|
| `POST /api/public/v1/session` with `{apiKey}` | Open a one-hour bearer session |
| `GET /api/public/v1/user?tag_id=...` | Registered user's aggregate statistics |
| `GET /api/public/v1/user?tag_id=...&game=...` | Statistics for one exact game name |
| `GET /api/public/v1/halloffame` | All-game champions and ranking |
| `GET /api/public/v1/halloffame?game=...` | One game's champions and ranking |

The Pi caches the bearer in memory, refreshes before expiry, and retries once after HTTP 401. The browser uses the Pi's same-origin API; no bearer or API key is sent to browser storage. Profile names are rendered as text. New scans supersede unfinished older lookups.

Game names must match the server exactly. The supplied export uses **Planz** and **Light Cycle**; PLANKZ is not silently renamed. Historical rankings can still be viewed for games removed from the launcher. The export is not imported or bundled.

**The supplied public API has no game-result submission endpoint.** New game results are displayed locally and are not added to the server leaderboard. PLANKZ/BEEPZ explicitly report that limitation instead of reporting a successful save. TENZ/LIFTZ retain their existing local behavior. A public write endpoint and agreed score/accuracy conventions are needed before cloud score upload can be added. In particular, LIFTZ angle error is lower-is-better, unlike the current highest-score ranking.

The user lookup returns username and tag ID, not an internal member UUID. The local compatibility response uses the tag ID as `profile_id` and marks the profile `readOnly`; it does not invent a server member ID.

## Verification and troubleshooting

`check_api.py` opens a real API session and reads Hall of Fame using your `.env`; it prints only success/count or a concise error, never credentials or member details. Optional `--tag YOUR_TAG_ID` also checks a registered tag without printing its profile.

The bridge's automated tests cover token renewal, one-time unauthorized retry, tag parsing, stale lookup races, selection expiry, error clearing, HTTP routes, host/origin boundaries and static-file containment. Browser checks used synthetic data for profile lookup, unknown-tag clearing, Hall of Fame filtering and returning home. Actual authenticated API access and physical NFC hardware remain to be verified on your Pi with your key.

An unauthenticated request from this development machine returned HTTP 403 (edge error 1010); your curl example returned the expected missing-bearer response. If `check_api.py` also returns HTTP 403 on the Pi, check the deployed API's edge access rules with the backend owner. Do not disable TLS verification. A 401 indicates an invalid/revoked key or session; a 404 on a tag can mean an unregistered tag or missing API route. A missing-key message means `.env` is absent, blank, or the service needs restarting.

Run local automated tests with `python3 -m unittest -v test_bridge.py`.
