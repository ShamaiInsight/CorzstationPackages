const fs=require('fs'),vm=require('vm'),assert=require('assert');
let now=0,posts=[],intervals=[],nodes=new Map();
class El {constructor(id=''){this.id=id;this.style={};this.dataset={};this.hidden=false;this.children=[];this.value='';this.textContent='';this.tagName='DIV';this.classList={toggle(){}};}set innerHTML(s){this.html=s;for(const m of s.matchAll(/id="([^"]+)"/g))nodes.set(m[1],new El(m[1]));}get innerHTML(){return this.html;}querySelector(q){return q==='button'?this.children[0]:this;}querySelectorAll(){return this.children;}append(b){this.children.push(b);}focus(){}setAttribute(){}getContext(){return new Proxy({createRadialGradient(){return {addColorStop(){}}}}, {get(t,k){return t[k]||(()=>{});}});}}
const document={getElementById(id){if(!nodes.has(id))nodes.set(id,new El(id));return nodes.get(id);},createElement(){return new El()},querySelectorAll(){return []},addEventListener(){},hidden:false};
const context={document,window:{addEventListener(){}},parent:{postMessage(){}},location:{hostname:'localhost',protocol:'http:',origin:'http://localhost:7890',search:''},localStorage:{getItem(){return null},setItem(){}},performance:{now:()=>now},URLSearchParams,AbortSignal,console,innerWidth:1600,innerHeight:900,devicePixelRatio:1,requestAnimationFrame(){},setTimeout(){},setInterval(fn,ms){intervals.push({fn,ms,next:ms});},WebSocket:class{close(){}},fetch:async(url,opts)=>{if(url.endsWith('current-user'))return {ok:true,json:async()=>({profile_id:'p1',display_name:'Test'})};posts.push(JSON.parse(opts.body));return {ok:true,json:async()=>({ok:true})};}};
context.window.parent=context.parent;
vm.createContext(context);const html=fs.readFileSync(require('path').join(__dirname,'www','plankz.html'),'utf8');const code=html.match(/<script>([\s\S]*)<\/script>/)[1];new vm.Script(code);vm.runInContext(code,context);
const run=s=>vm.runInContext(s,context);
function advance(ms){let end=now+ms;while(true){let n=Math.min(...intervals.map(i=>i.next));if(n>end)break;now=n;for(let i of intervals){if(i.next<=now+.0001){i.next+=i.ms;i.fn();}}}now=end;}
assert.equal(run('settings.ws'),'ws://raspberrypi.local:8765');
run(`ws.onmessage({data:JSON.stringify({type:'data',roll:1.14,pitch:-2.39,bpm:0,battery:43})})`);
assert.equal(run('raw.roll'),1.14);assert.equal(run('raw.pitch'),-2.39);assert(run('fresh()'));
run(`ws.onmessage({data:JSON.stringify({type:'data',roll:null,pitch:0})})`);
assert.equal(run('raw.roll'),1.14);
run(`ws.onmessage({data:JSON.stringify({type:'status',status:'scanning',deviceName:null})})`);
assert(!run('fresh()'));
console.log('PASS Raspberry Pi default, observed live packet format, invalid sample and scanning status');

run("$('wsInput').value='ws://raspberrypi.local:8765';mode='mouse';connectBLE()");
assert.equal(run('mode'),'ble');assert.equal(run('settings.ws'),'ws://raspberrypi.local:8765');
run('ws.onopen()');assert(run('bridgeMessage').includes('WebSocket connected'));
run('ws.onerror()');assert(run('connectionInfo()').includes('Connection failed'));
run("ws.onmessage({data:'null'})");
run("ws.onmessage({data:'broken json'})");assert(run('bridgeMessage').includes('invalid JSON'));
run("ws.onmessage({data:JSON.stringify({type:'data',roll:1.1,pitch:-2.4})})");assert(run('connectionInfo()').includes('BLE live'));
console.log('PASS manual connection from mouse mode, connection feedback and malformed messages');

(async()=>{run("draw()");run("chooseMode('mouse')");advance(300);run('calibrate()');advance(5300);assert.equal(run('state'),'ready');assert(Math.abs(run('offset.roll'))<.01);await run('start()');advance(5600);assert.equal(run('state'),'running');advance(3000);assert(run('score')>2);assert(run('score')<=run('elapsed'));console.log('PASS calibration + countdown + score',run('score'));
run('simLoaded=false');advance(2400);assert.equal(run('state'),'paused');let old=run('score');advance(3000);assert.equal(run('score'),old);console.log('PASS inactivity freezes score');await run('finish()');assert.equal(posts.length,1);assert.equal(posts[0].game_title,'PLANKZ · EASY · SIMULATION');await run('finish()');assert.equal(posts.length,1);console.log('PASS profile save once and simulation separation');
for(const [level,r] of Object.entries({easy:.82,medium:.61,hard:.4})){assert.equal(run(`clamp(1-${r}/radii['${level}'],0,1)`),0);}console.log('PASS difficulty boundaries');
run("intro(); simLoaded=true");await run('start()');advance(5800);run('view={cx:904,cy:441,r:310,w:1600,h:900}; mouse.pitch=20');advance(3200);assert.equal(run('state'),'results');await new Promise(setImmediate);assert.equal(posts.length,2);console.log('PASS top hold finishes');
run('intro()');await run('start()');advance(5800);run("mode='ble'; lastSample=-Infinity");advance(200);assert.equal(run('state'),'paused');console.log('PASS lost data pauses');
run("state='running';runProfile=null");await run('finish()');assert.equal(posts.length,2);console.log('PASS guest no submission');
const beforeReadOnly=posts.length;run("state='running';runProfile={profile_id:'abcd1234',display_name:'Test',readOnly:true};posted=false");await run('finish()');assert.equal(posts.length,beforeReadOnly);console.log('PASS OurCorz read-only result does not submit');
console.log('All behavioral tests passed');})();
