#!/usr/bin/env python3
"""OurCorz API + NFC kiosk bridge. Standard library; pyserial only for NFC."""
from __future__ import annotations
import copy
import json
import logging
import mimetypes
import os
import re
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlsplit, unquote
from urllib.request import Request, HTTPRedirectHandler, build_opener

ROOT = Path(__file__).resolve().parent
BRIDGE_BUILD = 'source-ota2'
LOG = logging.getLogger('ourcorz')

def load_env(path):
    if not path.exists():
        return
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        name, value = line.split('=', 1)
        if re.fullmatch(r'[A-Z][A-Z0-9_]*', name.strip()):
            os.environ.setdefault(name.strip(), value.strip().strip('\"\''))

class ApiError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def normalise_tag(value):
    """Reader prefix 0:UID, spaced/hyphenated hex UID, or full UUID."""
    text = str(value).strip().rsplit(':', 1)[-1].strip().lower()
    if re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', text):
        return text
    text = text.replace(' ', '').replace('-', '')
    if re.fullmatch(r'[0-9a-f]{4,16}', text):
        return text
    raise ApiError(400, 'TAG ID must be 4–16 hexadecimal characters or a UUID.')

class OurCorzClient:
    def __init__(self, base, api_key, opener=None, clock=time.time):
        self.base = base.rstrip('/')
        parsed = urlsplit(self.base)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.query or parsed.fragment:
            raise ValueError('OURCORZ_API_BASE must be an HTTPS URL without credentials or a query.')
        self.api_key = api_key.strip()
        self.opener, self.clock = opener or build_opener(NoRedirect).open, clock
        self.token, self.expires = None, 0
        self.lock = threading.Lock()

    @property
    def configured(self):
        return bool(self.api_key)

    def _request(self, method, path, body=None, token=None):
        headers = {'Accept': 'application/json'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        data = None
        if body is not None:
            headers['Content-Type'] = 'application/json'
            data = json.dumps(body).encode()
        req = Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with self.opener(req, timeout=12) as response:
                # Never forward a key or bearer to an unexpected redirect target.
                if response.geturl().rstrip('/') != (self.base + path).rstrip('/'):
                    raise ApiError(502, 'Unexpected upstream redirect. Check OURCORZ_API_BASE.')
                payload = json.loads(response.read(2_000_000))
                if not isinstance(payload, dict):
                    raise ValueError('not an object')
                return payload
        except HTTPError as exc:
            exc.close()
            if exc.code == 401:
                raise ApiError(401, 'OurCorz rejected the API key or bearer session.') from None
            if exc.code == 404:
                raise ApiError(404, 'TAG ID not registered in OurCorz (or API route not found).') from None
            raise ApiError(502, 'OurCorz returned HTTP ' + str(exc.code) + '.') from None
        except (URLError, TimeoutError, OSError):
            raise ApiError(502, 'Cannot reach OurCorz. Check the Pi internet connection.') from None
        except (ValueError, UnicodeError):
            raise ApiError(502, 'OurCorz did not return the expected JSON response.') from None

    def get_token(self):
        if not self.configured:
            raise ApiError(503, 'Set OURCORZ_API_KEY in the Pi .env file and restart the bridge.')
        with self.lock:
            if self.token and self.clock() < self.expires - 60:
                return self.token
            result = self._request('POST', '/session', {'apiKey': self.api_key})
            try:
                expires = datetime.fromisoformat(result['expiresAt'].replace('Z', '+00:00')).timestamp()
                token = result['token']
                if not isinstance(token, str) or not token or expires <= self.clock():
                    raise ValueError()
            except (KeyError, TypeError, ValueError):
                raise ApiError(502, 'OurCorz returned an invalid session response.') from None
            self.token, self.expires = token, expires
            return token

    def get(self, path, params=None):
        suffix = '?' + urlencode(params) if params else ''
        for attempt in range(2):
            token = self.get_token()
            try:
                return self._request('GET', path + suffix, token=token)
            except ApiError as exc:
                if exc.status != 401 or attempt:
                    raise
                with self.lock:
                    if self.token == token:
                        self.token, self.expires = None, 0
        raise ApiError(502, 'Session refresh failed.')

    def user(self, tag, game=''):
        params = {'tag_id': normalise_tag(tag)}
        if game:
            params['game'] = game
        result = self.get('/user', params)
        required = ('username', 'tagId', 'sessionsPlayed', 'bestScore', 'totalScore', 'bestAccuracy', 'averageAccuracy', 'totalPlaySeconds')
        if any(k not in result for k in required) or normalise_tag(result['tagId']) != params['tag_id']:
            raise ApiError(502, 'Unexpected profile response from OurCorz.')
        return result

    def hall(self, game=''):
        result = self.get('/halloffame', {'game': game} if game else None)
        if not isinstance(result.get('ranking'), list):
            raise ApiError(502, 'Unexpected Hall of Fame response from OurCorz.')
        return result

class Selection:
    def __init__(self, client, ttl=900):
        self.client, self.ttl = client, ttl
        self.lock = threading.Lock()
        self.sequence = 0
        self.profile = None
        self.selected_at = 0
        self.latest = None
        self.serial_connected, self.serial_error = False, None

    def snapshot(self):
        with self.lock:
            if self.profile and time.monotonic() - self.selected_at > self.ttl:
                self.sequence += 1
                self.profile = None
                self.latest = {'sequence': self.sequence, 'status': 'expired', 'message': 'Tap your tag again.'}
            return copy.deepcopy({'sequence': self.sequence, 'profile': self.profile, 'latest': self.latest,
                'serialConnected': self.serial_connected, 'serialError': self.serial_error})

    def clear(self):
        with self.lock:
            self.sequence += 1
            self.profile = None
            self.latest = {'sequence': self.sequence, 'status': 'signed-out', 'message': 'No player selected.'}

    def resolve(self, raw):
        # Invalidate the former player immediately, including for unknown tags/errors.
        with self.lock:
            self.sequence += 1
            generation = self.sequence
            self.profile = None
            self.latest = {'sequence': generation, 'status': 'loading', 'message': 'Looking up the scanned tag…'}
        try:
            tag = normalise_tag(raw)
            result = self.client.user(tag)
            profile = dict(result, profile_id=tag, display_name=result['username'], readOnly=True)
            with self.lock:
                if generation != self.sequence:
                    raise ApiError(409, 'A newer tag scan replaced this lookup.')
                self.profile, self.selected_at = profile, time.monotonic()
                self.latest = {'sequence': generation, 'status': 'ready', 'message': 'Player loaded from OurCorz.'}
            return profile
        except ApiError as exc:
            with self.lock:
                if generation == self.sequence:
                    self.profile = None
                    self.latest = {'sequence': generation, 'status': 'error', 'message': exc.message}
            raise

    def serial_status(self, connected, error=None):
        with self.lock:
            self.serial_connected, self.serial_error = connected, error

def serial_worker(state, stop):
    try:
        import serial
    except ImportError:
        state.serial_status(False, 'Install pyserial to use the NFC reader.')
        return
    port = os.getenv('NFC_SERIAL_PORT', '/dev/ttyACM0')
    baud = int(os.getenv('NFC_BAUDRATE', '115200'))
    command = os.getenv('NFC_START_COMMAND', '/p')
    previous, previous_time = None, 0
    while not stop.is_set():
        try:
            with serial.Serial(port, baud, timeout=1) as reader:
                if command:
                    reader.write((command + '\r').encode())
                state.serial_status(True)
                pending = ''
                while not stop.is_set():
                    pending += reader.read(max(1, min(reader.in_waiting, 256))).decode('utf-8', errors='replace')
                    lines = re.split(r'[\r\n]', pending)
                    pending = lines.pop()
                    if len(pending) > 256:
                        pending = ''
                    for line in lines:
                        try:
                            tag = normalise_tag(line)
                        except ApiError:
                            continue
                        now = time.monotonic()
                        if tag == previous and now - previous_time < 2:
                            continue
                        previous, previous_time = tag, now
                        # A held card can emit continuously. Refresh it at most every 30 s.
                        current = state.snapshot()['profile']
                        if current and current['tagId'] == tag and now - state.selected_at < 30:
                            continue
                        try:
                            state.resolve(tag)
                        except ApiError as exc:
                            LOG.warning('NFC lookup failed (HTTP %s)', exc.status)
        except (OSError, serial.SerialException):
            state.serial_status(False, 'NFC reader unavailable. Check the serial port and permissions.')
            stop.wait(3)

def make_handler(client, selection, web_root, allowed_hosts):
    web_root = Path(web_root).resolve()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            # Do not log TAG IDs in request paths, tokens or response bodies.
            pass

        def authorised_origin(self):
            host = self.headers.get('Host', '')
            try:
                hostname = urlsplit('http://' + host).hostname
            except ValueError:
                return False
            if hostname not in allowed_hosts:
                return False
            origin = self.headers.get('Origin')
            if origin and origin not in ('http://' + host, 'https://' + host):
                return False
            return self.headers.get('Sec-Fetch-Site') not in ('cross-site',)

        def send_json(self, payload, code=200):
            data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if not self.authorised_origin():
                return self.send_json({'error': 'Use the dashboard from this bridge origin.'}, 403)
            parsed = urlsplit(self.path)
            query = parse_qs(parsed.query)
            game = query.get('game', [''])[0].strip()
            if len(game) > 120:
                return self.send_json({'error': 'Game name is too long.'}, 400)
            try:
                if parsed.path == '/api/status':
                    return self.send_json(dict(selection.snapshot(), configured=client.configured,
                        upstream=client.base, scoreWriteSupported=False, bridgeBuild=BRIDGE_BUILD))
                if parsed.path == '/api/current-user':
                    profile = selection.snapshot()['profile']
                    if not profile:
                        raise ApiError(404, 'No NFC player selected.')
                    return self.send_json(profile)
                if parsed.path == '/api/profile':
                    snapshot = selection.snapshot()
                    if not snapshot['profile']:
                        raise ApiError(404, 'Tap a registered NFC tag first.')
                    result = client.user(snapshot['profile']['tagId'], game)
                    if selection.snapshot()['sequence'] != snapshot['sequence']:
                        raise ApiError(409, 'Player changed during the request. Refresh the profile.')
                    return self.send_json(result)
                if parsed.path == '/api/halloffame':
                    return self.send_json(client.hall(game))
                if parsed.path.startswith('/api/'):
                    raise ApiError(404, 'Unknown local API route.')
                relative = unquote(parsed.path).lstrip('/') or 'index.html'
                path = (web_root / relative).resolve()
                if not path.is_relative_to(web_root) or not path.is_file() or any(part.startswith('.') for part in Path(relative).parts):
                    raise ApiError(404, 'File not found.')
                data = path.read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', (mimetypes.guess_type(path.name)[0] or 'application/octet-stream') + ('; charset=utf-8' if path.suffix in ('.html', '.js', '.css') else ''))
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-cache')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.end_headers()
                self.wfile.write(data)
            except ApiError as exc:
                self.send_json({'error': exc.message}, exc.status)

        def do_POST(self):
            if not self.authorised_origin():
                return self.send_json({'error': 'Use the dashboard from this bridge origin.'}, 403)
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 <= length <= 2048:
                    raise ApiError(413, 'Request is too large.')
                if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                    raise ApiError(415, 'Send application/json.')
                body = json.loads(self.rfile.read(length) or b'{}')
                if not isinstance(body, dict):
                    raise ValueError()
                path = urlsplit(self.path).path
                if path == '/api/resolve':
                    return self.send_json(selection.resolve(body.get('tag_id', '')))
                if path == '/api/logout':
                    selection.clear()
                    return self.send_json({'ok': True})
                if path == '/api/game-result':
                    raise ApiError(501, 'OurCorz public v1 has no score-write endpoint. Result was not uploaded.')
                raise ApiError(404, 'Unknown local API route.')
            except (ValueError, UnicodeError):
                self.send_json({'error': 'Invalid JSON request.'}, 400)
            except ApiError as exc:
                self.send_json({'error': exc.message}, exc.status)
    return Handler

def main():
    load_env(ROOT / '.env')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    # Default redirects are disabled BEFORE sending secrets to a new destination.
    client = OurCorzClient(os.getenv('OURCORZ_API_BASE', 'https://ourcorz.lovable.app/api/public/v1'),
        os.getenv('OURCORZ_API_KEY', ''))
    selection = Selection(client, ttl=int(os.getenv('PLAYER_IDLE_SECONDS', '900')))
    bind, port = os.getenv('BIND_HOST', '127.0.0.1'), int(os.getenv('PORT', '7890'))
    hosts = set(os.getenv('ALLOWED_HOSTS', 'localhost,127.0.0.1,raspberrypi.local').split(','))
    hosts = {host.strip() for host in hosts if host.strip()}
    web_root = Path(os.getenv('WEB_ROOT', str(ROOT / 'www'))).resolve()
    stop = threading.Event()
    if os.getenv('NFC_ENABLED', '1') == '1':
        threading.Thread(target=serial_worker, args=(selection, stop), daemon=True).start()
    else:
        selection.serial_status(False, 'NFC disabled; manual TAG lookup is available.')
    server = ThreadingHTTPServer((bind, port), make_handler(client, selection, web_root, hosts))
    LOG.info('Dashboard: http://%s:%s — API key configured: %s', bind, port, client.configured)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        server.server_close()

if __name__ == '__main__':
    main()
