'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'www','beepz.html'),'utf8');
const script=html.match(/<script>([\s\S]*)<\/script>/)[1];new vm.Script(script);
const core=script.slice(script.indexOf('class BeepzSession'),script.indexOf('const $='));
const c={Math};vm.createContext(c);vm.runInContext(core+';globalThis.Session=BeepzSession;',c);
const x=2+4/(3*Math.PI), config={cycles:2,reps:2,hold:5,breakSeconds:3};
let g=new c.Session(config);
assert(g.target(x,0).inside);assert.equal(g.target(x,0).accuracy,1);
for(const point of [[1.99,0],[3.01,0],[2.5,1],[-x,0]])assert(!g.target(...point).inside);
assert(g.target(2.6,0).accuracy<g.target(2.5,0).accuracy);
assert(Math.abs(g.target(3,0).accuracy)<1e-8);
g.step(2,0,0);assert.equal(g.malus,0);assert.equal(g.hold,0);assert.equal(g.gross,0);
g.step(1,x,0);assert.equal(g.gross,1);assert.equal(g.hold,1);
g.step(2,0,0);assert.equal(g.malus,2);assert.equal(g.hold,1);assert.equal(g.net,0);
assert.equal(g.step(4,x,0),'target');assert.equal(g.side,-1);assert.equal(g.gross,5);assert.equal(g.net,3);
g.step(2,0,0);assert.equal(g.malus,2); // New target travel is not penalised.
g.step(5,-x,0);assert.equal(g.rep,2);assert.equal(g.side,1);
g.step(5,x,0);assert.equal(g.step(5,-x,0),'break');assert.equal(g.cycle,2);
const before=[g.gross,g.malus,g.work];g.step(2,0,0);assert.equal(g.phase,'break');assert.deepEqual([g.gross,g.malus,g.work],before);
assert.equal(g.step(1,0,0),'target');assert.equal(g.phase,'work');
for(let n=0;n<4;n++)g.step(5,g.side*x,0);
assert.equal(g.phase,'done');assert.equal(g.completedHolds,8);assert.equal(g.gross,40);assert.equal(g.net,38);
assert(g.average>=0&&g.average<=100);const end=g.gross;g.step(20,x,0);assert.equal(g.gross,end);
for(const hold of [5,10,15]){let t=new c.Session({cycles:1,reps:1,hold,breakSeconds:0});t.step(hold,x,0);t.step(hold,-x,0);assert.equal(t.phase,'done');assert.equal(t.gross,hold*2);}
console.log('PASS geometry, accuracy, hold resumption, malus, repetitions, breaks, all levels and completion');
// Exercise real application functions with a clock, simple DOM and API stub.
let now=0,intervals=[],nodes=new Map(),posts=[];
class El{constructor(){this.style={};this.dataset={};this.children=[];this.value='';this.checked=false;this.hidden=false;this.tagName='DIV';}set innerHTML(s){for(const m of s.matchAll(/id="([^"]+)"/g))nodes.set(m[1],new El());}querySelector(){return this;}querySelectorAll(){return this.children;}append(b){this.children.push(b);}focus(){}setAttribute(){}getContext(){return new Proxy({}, {get:()=>()=>{}});}}
const document={getElementById(id){if(!nodes.has(id))nodes.set(id,new El());return nodes.get(id);},createElement(){return new El()},addEventListener(){},hidden:false};
let user={profile_id:'test',display_name:'Tester'};
const env={document,window:{addEventListener(){}},parent:{postMessage(){}},location:{hostname:'localhost',protocol:'http:',origin:'http://localhost:7890',search:''},URLSearchParams,AbortSignal,performance:{now:()=>now},localStorage:{getItem(){return null},setItem(){}},console,setTimeout(){},setInterval(fn,ms){intervals.push({fn,ms,next:ms})},requestAnimationFrame(){},innerWidth:1600,innerHeight:900,devicePixelRatio:1,WebSocket:class{close(){}},fetch:async(url,o)=>{if(url.endsWith('current-user'))return{ok:!!user,status:401,json:async()=>user};posts.push(JSON.parse(o.body));return{ok:true,json:async()=>({ok:true})};}};
vm.createContext(env);vm.runInContext(script,env);const run=s=>vm.runInContext(s,env);
function advance(ms){const end=now+ms;while(true){const t=Math.min(...intervals.map(i=>i.next));if(t>end)break;now=t;for(const i of intervals)if(i.next<=now+.001){i.next+=i.ms;i.fn();}}now=end;}
assert.equal(run('cfg.ws'),'ws://raspberrypi.local:8765');
run(`ws.onmessage({data:JSON.stringify({type:'data',roll:1.14,pitch:-2.39,bpm:0,battery:43})})`);
assert.equal(run('raw.roll'),1.14);assert.equal(run('raw.pitch'),-2.39);assert(run('fresh()'));
run(`ws.onmessage({data:JSON.stringify({type:'data',roll:null,pitch:0})})`);
assert.equal(run('raw.roll'),1.14);
run(`ws.onmessage({data:JSON.stringify({type:'status',status:'scanning',deviceName:null})})`);
assert(!run('fresh()'));
console.log('PASS Raspberry Pi default, observed live packet format, invalid sample and scanning status');
for(const [w,h] of [[1600,900],[1920,1080],[390,844],[2560,1080]]){
run(`innerWidth=${w};innerHeight=${h};draw()`);
assert(Math.abs(run('2*(view.end+view.r)/innerWidth')-.94)<1e-9);
for(const x of [-4,-3,-2.424,-2,0,2,2.424,3,4]) assert(Math.abs(run(`gameX(boardX(${x}))`)-x)<1e-9);
}
run('innerWidth=1600;innerHeight=900;draw()');
console.log('PASS 94% capsule width and matching pointer/target coordinates at four screen sizes');

run("$('wsUrl').value='ws://raspberrypi.local:8765';mode='mouse';connectBLE()");
assert.equal(run('mode'),'ble');assert.equal(run('cfg.ws'),'ws://raspberrypi.local:8765');
run('ws.onopen()');assert(run('bridgeMessage').includes('WebSocket connected'));
run('ws.onerror()');assert(run('connectionInfo()').includes('Connection failed'));
run("ws.onmessage({data:'null'})");
run("ws.onmessage({data:'broken json'})");assert(run('bridgeMessage').includes('invalid JSON'));
run("ws.onmessage({data:JSON.stringify({type:'data',roll:1.1,pitch:-2.4})})");assert(run('connectionInfo()').includes('BLE live'));
console.log('PASS manual connection from mouse mode, connection feedback and malformed messages');

(async()=>{run("draw()");run("mode='mouse';cfg.cycles=1;cfg.reps=1;cfg.hold=5;cfg.sound=false");advance(300);run('calibrate()');advance(5300);assert.equal(run('state'),'ready');await run('start()');advance(4800);assert.equal(run('state'),'countdown');advance(600);assert.equal(run('state'),'running');run(`mouse.roll=${x}*cfg.range/3`);advance(5800);assert.equal(run('game.side'),-1);run(`mouse.roll=-${x}*cfg.range/3`);advance(5800);assert.equal(run('state'),'results');await new Promise(setImmediate);assert.equal(posts.length,1);assert(posts[0].game_title.includes('SIMULATION'));assert(posts[0].score>8);await run('finish(true)');assert.equal(posts.length,1);
run("state='ready'");await run('start()');advance(5400);run("mode='ble';lastSample=-Infinity");advance(200);assert.equal(run('state'),'paused');const frozen=run('[game.gross,game.malus,game.work,game.hold].join()');advance(3000);assert.equal(run('[game.gross,game.malus,game.work,game.hold].join()'),frozen);
run('runProfile=null');await run('finish(false)');assert.equal(posts.length,1);
const beforeReadOnly=posts.length;run("state='running';runProfile={profile_id:'abcd1234',display_name:'Test',readOnly:true};posted=false");await run('finish(false)');assert.equal(posts.length,beforeReadOnly);console.log('PASS OurCorz read-only result does not submit');
run('draw()');console.log('PASS calibration, 5s countdown, mouse play, single profile submission, stale-data pause, guest result and render path');
})().catch(e=>{console.error(e);process.exitCode=1;});
