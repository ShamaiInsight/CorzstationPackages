#!/usr/bin/env python3
"""Check the deployed read API without printing credentials or profile data."""
import argparse
import os
from ourcorz_bridge import ROOT, ApiError, OurCorzClient, load_env

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tag', help='Optional registered NFC tag to verify')
    args = parser.parse_args()
    load_env(ROOT / '.env')
    try:
        client = OurCorzClient(
            os.getenv('OURCORZ_API_BASE', 'https://ourcorz.lovable.app/api/public/v1'),
            os.getenv('OURCORZ_API_KEY', ''))
        hall = client.hall()
        print('PASS: bearer session and Hall of Fame; ranking rows:', len(hall['ranking']))
        if args.tag:
            client.user(args.tag)
            print('PASS: registered tag profile lookup.')
    except (ApiError, ValueError) as exc:
        print('FAILED:', str(exc))
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
