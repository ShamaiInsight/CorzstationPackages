#!/usr/bin/env python3
"""Build matching package.zip/update.json from this editable startup kit.

python3 tools/build_release.py --version 2026.10.25-test.2 --assets ./my-assets
Asset tree example: my-assets/app/www/Music/PR_1.mp3
Publish the ZIP first and update.json last. Never put .env/API keys in releases.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import re
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def build(version, output, assets=None, package_url='package.zip', restart_services=None):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._+-]{0,99}', version):
        raise ValueError('Use a nonempty version, e.g. 2026.10.25-test.2')
    payload = {}
    for path in sorted((ROOT / 'app' / 'www').rglob('*')):
        if path.is_file() and not any(p.startswith('.') for p in path.relative_to(ROOT).parts):
            payload[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    bridge = (ROOT / 'app/ourcorz_bridge.py').read_text()
    marker = "BRIDGE_BUILD = 'source-ota2'"
    if bridge.count(marker) != 1:
        raise ValueError('Bridge build marker is missing; retain BRIDGE_BUILD when editing the source')
    payload['app/ourcorz_bridge.py'] = bridge.replace(marker, f'BRIDGE_BUILD = {version!r}').encode()
    for path in sorted((ROOT / 'runtime').glob('*')):
        if path.is_file() and path.suffix in ('.py', '.html'):
            payload[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    payload['app/www/splash.html'] = (ROOT / 'runtime/splash.html').read_bytes()
    payload['kiosk.sh'] = (ROOT / 'kiosk.sh').read_bytes()
    payload['app/www/update-release.json'] = json.dumps({'version': version}, indent=2).encode()
    if assets:
        assets = assets.resolve()
        for path in sorted(assets.rglob('*')):
            if path.is_symlink():
                raise ValueError(f'Asset symlinks not allowed: {path}')
            if path.is_file():
                payload[path.relative_to(assets).as_posix()] = path.read_bytes()
    manifest = dict(schema=2, version=version,
        files=[dict(src='payload/' + name, dest=name, mode='0755' if name == 'kiosk.sh' else '0644')
               for name in sorted(payload)], bundles=[], delete=[], restart_services=restart_services or [], servers=[])
    output.mkdir(parents=True, exist_ok=True)
    # Build in a temporary directory so a failed build cannot damage the last release.
    with tempfile.TemporaryDirectory(prefix='corz-release-') as temporary:
        package = Path(temporary) / 'package.zip'
        with zipfile.ZipFile(package, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('manifest.json', json.dumps(manifest, indent=2))
            for name, data in sorted(payload.items()):
                zf.writestr('payload/' + name, data)
        spec = importlib.util.spec_from_file_location('release_validator', ROOT / 'runtime/updater.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.prepare(package, Path(temporary) / 'validation', expected_version=version)
        data = package.read_bytes()
        release = dict(schema=2, version=version, package_url=package_url,
                       sha256=hashlib.sha256(data).hexdigest(), size=len(data))
        (output / 'package.zip').write_bytes(data)
        (output / 'update.json').write_text(json.dumps(release, indent=2) + '\n')
        (output / 'manifest-readable.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'Built {output / "package.zip"} ({len(data):,} bytes; {len(payload)} files)')
    print(f'Version: {version}; SHA-256: {release["sha256"]}')
    return release


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'github-upload')
    parser.add_argument('--assets', type=Path, help='Extra station-relative files, merged without deleting unlisted files')
    parser.add_argument('--package-url', default='package.zip', help='Relative to update.json, or a full HTTPS URL')
    parser.add_argument('--restart-service', action='append', default=[],
                        help='Explicit existing service to restart (for imported runtime helpers)')
    args = parser.parse_args()
    build(args.version, args.output, args.assets, args.package_url, args.restart_service)


if __name__ == '__main__':
    main()
