#!/usr/bin/env python3
"""Generate a quiet, original 4-second diagnostic melody (requires ffmpeg)."""
import math
import subprocess
import tempfile
import wave
from array import array
from pathlib import Path

root = Path(__file__).resolve().parent.parent
out = root / 'app/www/Music/CORZ-update-test.mp3'
out.parent.mkdir(parents=True, exist_ok=True)
rate = 22050
samples = array('h')
for frequency in (261.63, 329.63, 392.00, 523.25, 392.00, 329.63, 293.66, 261.63):
    for i in range(rate // 2):
        t = i / rate
        envelope = min(t / .03, 1) * min((.5 - t) / .1, 1)
        samples.append(int(4000 * max(0, envelope) * math.sin(2 * math.pi * frequency * t)))
with tempfile.TemporaryDirectory() as folder:
    wav = Path(folder) / 'test.wav'
    with wave.open(str(wav), 'wb') as stream:
        stream.setnchannels(1)
        stream.setsampwidth(2)
        stream.setframerate(rate)
        stream.writeframes(samples.tobytes())
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', str(wav),
                    '-codec:a', 'libmp3lame', '-b:a', '64k', str(out)], check=True)
print(out)
