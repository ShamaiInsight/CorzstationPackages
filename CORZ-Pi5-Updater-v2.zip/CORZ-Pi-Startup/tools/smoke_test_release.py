#!/usr/bin/env python3
"""Install generated release in an isolated temporary station and start real HTTP servers.

No sudo/systemd/hardware/external network. Uses --no-restart deliberately;
this test starts/stops the installed Python processes itself.
"""
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def get(url):
    with urllib.request.urlopen(url, timeout=2) as response:
        return response.read()


def wait_json(url, predicate=lambda value: True):
    deadline = time.monotonic() + 12
    while time.monotonic() < deadline:
        try:
            value = json.loads(get(url))
            if predicate(value):
                return value
        except Exception:
            pass
        time.sleep(.1)
    raise AssertionError('Server did not become ready: ' + url)


def main():
    release_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'github-upload'
    release = json.loads((release_dir / 'update.json').read_text())
    package = (release_dir / 'package.zip').resolve()
    assert hashlib.sha256(package.read_bytes()).hexdigest() == release['sha256']
    assert package.stat().st_size == release['size']
    with tempfile.TemporaryDirectory(prefix='corz-release-smoke-') as folder:
        station = Path(folder) / 'home/corz/corz-station'
        (station / 'app').mkdir(parents=True)
        (station / 'app/.env').write_text('LOCAL_KEEP=secret-test-value\n')
        env = dict(os.environ, CORZ_STATION_DIR=str(station), NFC_ENABLED='0')
        apply = subprocess.run([sys.executable, str(ROOT / 'runtime/updater.py'),
                                '--apply', str(package), '--no-restart'], env=env,
                               capture_output=True, text=True)
        assert apply.returncode == 0, apply.stderr + apply.stdout
        assert (station / 'app/.env').read_text() == 'LOCAL_KEEP=secret-test-value\n'
        assert (station / '.corz_version').read_text() == release['version']
        bridge_port, updater_port = free_port(), free_port()
        while bridge_port == updater_port:
            updater_port = free_port()
        (station / 'updater.json').write_text(json.dumps({'manifest_url': '', 'port': updater_port}))
        processes = []
        with (Path(folder) / 'process.log').open('w+') as logs:
            try:
                bridge_env = dict(env, PORT=str(bridge_port))
                processes.append(subprocess.Popen([sys.executable, str(station / 'app/ourcorz_bridge.py')],
                    env=bridge_env, stdout=logs, stderr=logs))
                processes.append(subprocess.Popen([sys.executable, str(station / 'runtime/updater.py')],
                    env=env, stdout=logs, stderr=logs))
                bridge = wait_json(f'http://127.0.0.1:{bridge_port}/api/status')
                status = wait_json(f'http://127.0.0.1:{updater_port}/api/status', lambda v: v['status'] == 'READY')
                assert bridge['bridgeBuild'] == release['version'], bridge
                assert status['version'] == release['version'], status
                assert status['error'] == '', status
                base = f'http://127.0.0.1:{bridge_port}'
                assert b'Did the update land?' in get(base + '/update-test.html')
                audio = get(base + '/Music/CORZ-update-test.mp3')
                assert audio == (station / 'app/www/Music/CORZ-update-test.mp3').read_bytes()
                conflict = subprocess.run([sys.executable, str(station / 'runtime/updater.py'),
                    '--apply', str(package), '--no-restart'], env=env, capture_output=True, text=True)
                assert conflict.returncode == 2 and 'Another updater' in conflict.stderr
                print(json.dumps({'result': 'PASS', 'release': release['version'],
                    'runningBridgeBuild': bridge['bridgeBuild'], 'updaterStatus': status['status'],
                    'musicBytesServed': len(audio), 'localEnvPreserved': True,
                    'concurrentUpdaterBlocked': True, 'hardcodedAccountRequired': False}, indent=2))
            except Exception:
                logs.flush()
                logs.seek(0)
                print(logs.read(), file=sys.stderr)
                raise
            finally:
                for process in processes:
                    process.terminate()
                for process in processes:
                    try:
                        process.wait(timeout=8)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()


if __name__ == '__main__':
    main()
