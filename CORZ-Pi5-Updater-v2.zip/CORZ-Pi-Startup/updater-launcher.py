#!/usr/bin/env python3
"""Stable service launcher/recovery guard. Not an OTA-update target.

Starts updater.py only after recovering an interrupted transaction. Watches
self-update trials and restores the previous files if startup fails or hangs.
Runs as the normal station account; only exact service restarts use sudo.
"""
from __future__ import annotations
import fcntl
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path, PurePosixPath

STATION = Path(os.environ.get('CORZ_STATION_DIR', str(Path(__file__).resolve().parent))).resolve()
STATE = STATION / '.updates'
SERVICES = {'ourcorz-bridge.service', 'corz-ble.service', 'corz-hr.service',
            'corz-wifi.service', 'corz-updater.service'}
TRIAL_TIMEOUT = 90


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def unlink(path):
    path.unlink(missing_ok=True)
    if path.parent.exists():
        sync_dir(path.parent)


def safe_target(name):
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name:
        raise ValueError('Invalid recovery filename')
    parts = PurePosixPath(name).parts
    if name.startswith('/') or any(p in ('', '.', '..') for p in name.split('/')):
        raise ValueError('Invalid recovery path')
    if parts[0] not in ('app', 'runtime', 'kiosk.sh'):
        raise ValueError('Recovery target outside station code')
    path = STATION / name
    if not path.resolve().is_relative_to(STATION):
        raise ValueError('Recovery target escapes station')
    for item in (path, *path.parents):
        if item == STATION.parent:
            break
        if item.is_symlink():
            raise ValueError('Symlink recovery target refused')
    return path


def write(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.corz-recover-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fchmod(stream.fileno(), mode)
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        for parent in path.parents:
            sync_dir(parent)
            if parent == STATION:
                break
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def restore(journal):
    stamp = journal['backup']
    if not isinstance(stamp, str) or not re.fullmatch(r'[0-9-]+', stamp):
        raise ValueError('Invalid backup identifier')
    backup = STATE / 'backups' / stamp
    for entry in reversed(journal['entries']):
        dst = safe_target(entry['name'])
        if entry['existed']:
            write(dst, (backup / entry['name']).read_bytes(), entry['mode'])
        else:
            unlink(dst)
    for name in ('.corz_version', 'corz-manifest.json'):
        old = backup / name
        if old.exists():
            write(STATION / name, old.read_bytes())
        else:
            unlink(STATION / name)
    # Keep the journal until all restored services have restarted successfully.
    for unit in journal.get('services', []):
        if unit not in SERVICES:
            raise ValueError('Invalid recovery service')
        if unit != 'corz-updater.service':
            subprocess.run(['/usr/bin/sudo', '-n', '/usr/bin/systemctl', 'restart', unit],
                           timeout=40, check=True)
            time.sleep(1)
            subprocess.run(['/usr/bin/systemctl', 'is-active', '--quiet', unit], timeout=10, check=True)


def recover_pending():
    path = STATE / 'pending.json'
    if path.exists():
        print('[corz-launcher] Restoring interrupted update before running updater.py', flush=True)
        restore(json.loads(path.read_text()))
        unlink(STATE / 'trial.json')
        unlink(path)


def launch():
    recover_pending()
    trial = STATE / 'trial.json'
    pending_trial = trial.exists()
    child = subprocess.Popen([sys.executable, '-u', str(STATION / 'runtime/updater.py')])
    if not pending_trial:
        return child.wait()
    deadline = time.monotonic() + TRIAL_TIMEOUT
    while child.poll() is None and trial.exists() and time.monotonic() < deadline:
        time.sleep(.2)
    if not trial.exists():
        return child.wait()
    print('[corz-launcher] Updater trial failed; restoring previous release', flush=True)
    if child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait()
    # Persist the rollback phase before touching live files. If restoration or
    # its service restarts are interrupted, next start must finish recovery,
    # not launch/confirm a partially restored candidate as a successful trial.
    write(STATE / 'pending.json', trial.read_bytes())
    recover_pending()
    # Do not immediately download the same failed release in this fallback boot.
    # The previous updater can start normally with update checks disabled once.
    env = dict(os.environ, CORZ_SKIP_UPDATE_ONCE='1')
    fallback = subprocess.Popen([sys.executable, '-u', str(STATION / 'runtime/updater.py')], env=env)
    return fallback.wait()


def main():
    STATE.mkdir(parents=True, exist_ok=True)
    with (STATE / 'launcher.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return launch()


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print(f'[corz-launcher] Recovery/startup failed: {exc}', file=sys.stderr, flush=True)
        sys.exit(1)
